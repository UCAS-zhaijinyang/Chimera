def mean_values(a,b):
    return (a+b)/2
