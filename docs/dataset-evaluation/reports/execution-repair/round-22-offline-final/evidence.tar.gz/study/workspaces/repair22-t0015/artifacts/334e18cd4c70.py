def compute(a, b):
    return min(a, b)
