def compute(a, b):
    return max(a, b)
