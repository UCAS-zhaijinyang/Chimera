from helper import mean_values
def compute(a,b):
    return mean_values(a,b)
