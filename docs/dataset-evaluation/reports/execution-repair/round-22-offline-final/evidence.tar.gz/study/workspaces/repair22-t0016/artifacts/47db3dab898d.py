import unittest
class TestCompute(unittest.TestCase):
    def test_mean(self):
        import sys
        sys.path.insert(0,"src")
        from main import compute
        self.assertEqual(compute(2,3),2.5)
