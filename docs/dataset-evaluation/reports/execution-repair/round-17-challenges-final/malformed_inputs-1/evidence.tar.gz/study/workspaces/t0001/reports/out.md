[
  {
    "group": "W1",
    "count": 3
  },
  {
    "group": "W2",
    "count": 5
  }
]