{
  "path": "shared/out.md",
  "source": "74d692432213"
}