{
  "path": "shared/out.md",
  "source": "baf0aacfcfcd"
}