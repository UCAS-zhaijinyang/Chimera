# textstats

Small, self-contained text statistics utilities (standard library only).

## API

- `word_count(text)` — number of whitespace-separated tokens.
- `char_count(text, *, ignore_whitespace=False)` — character count.
- `top_words(text, n=3)` — `n` most frequent lowercased words, ties broken alphabetically.
- `summarize(text)` — dict with `words`, `chars`, `unique_words`.

## Usage

```python
from textstats import summarize, top_words

top_words("the quick the fox", 2)  # [('the', 2), ('fox', 1)]
summarize("a b b")                 # {'words': 3, 'chars': 5, 'unique_words': 2}
```

## Tests

```bash
python -m unittest discover -s tests -v
```
