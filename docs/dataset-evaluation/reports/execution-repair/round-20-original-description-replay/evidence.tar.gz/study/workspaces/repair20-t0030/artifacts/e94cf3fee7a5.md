# Design Document — Small Python Feature (Fixture Variation 5)

## 1. Objective
Implement a small, self-contained Python feature with unit tests, a successful test run, a build step, and a prepared pull request for simulated review.

## 2. Feature Selection
To keep the feature small, self-contained, and testable, implement a **text statistics / word-frequency utility** module.

### Public API (`src/textstats.py`)
- `normalize(text: str) -> str`
  - Lowercases text, strips punctuation, collapses whitespace.
- `word_frequencies(text: str) -> dict[str, int]`
  - Returns a mapping of normalized word -> count, sorted by descending count then alphabetically.
- `top_words(text: str, n: int = 5) -> list[tuple[str, int]]`
  - Returns the top `n` (word, count) pairs.
- `summarize(text: str) -> dict`
  - Returns `{"characters": int, "words": int, "unique_words": int, "top_words": list}`.

### Edge cases
- Empty string / whitespace-only input -> empty results, zero counts.
- Punctuation-only input -> no words.
- `n <= 0` in `top_words` -> empty list.
- `n` greater than number of unique words -> all words returned.
- Unicode letters preserved; case-insensitive counting.

## 3. Module Layout
```
src/textstats.py        # feature implementation
tests/test_textstats.py # unit tests (unittest)
reports/design.md       # this design document
reports/build_report.md # build evidence
reports/pr.md           # pull request record
```

## 4. Testing Strategy
- Use the standard library `unittest` framework (no external dependencies).
- Cover: normalization, frequency ordering, top-N behavior, summarize output, and all listed edge cases.
- Run with: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m unittest discover -s tests -v`

## 5. Build Strategy
- No third-party packaging required. Build = byte-compile the source and tests to verify syntax/importability:
  `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall src tests`
- Record build output in `reports/build_report.md`.

## 6. Review Preparation
- Create `reports/pr.md` containing: summary, files changed, test evidence, and acceptance-criteria checklist.

## 7. Acceptance Criteria Mapping
| Criterion | Evidence |
|---|---|
| Feature module under src/ | `src/textstats.py` |
| Tests exist and pass | `tests/test_textstats.py`, test run output |
| Build completes | `reports/build_report.md` |
| PR prepared | `reports/pr.md` |
