"""Minimal build script for the textstats feature.

Validates that the source module imports cleanly, byte-compiles all Python
files under ``src/`` and ``tests/``, and writes a build report to
``reports/build_report.json``.
"""

from __future__ import annotations

import json
import os
import py_compile
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
TESTS = os.path.join(ROOT, "tests")
REPORTS = os.path.join(ROOT, "reports")


def _iter_py_files(*dirs: str):
    for directory in dirs:
        for dirpath, _dirnames, filenames in os.walk(directory):
            for name in sorted(filenames):
                if name.endswith(".py"):
                    yield os.path.join(dirpath, name)


def main() -> int:
    os.makedirs(REPORTS, exist_ok=True)

    sys.path.insert(0, SRC)
    import textstats  # noqa: F401

    compiled = []
    for path in _iter_py_files(SRC, TESTS):
        py_compile.compile(path, doraise=True)
        compiled.append(os.path.relpath(path, ROOT))

    report = {
        "status": "ok",
        "module": "textstats",
        "exports": list(textstats.__all__),
        "compiled_files": compiled,
        "compiled_count": len(compiled),
    }

    report_path = os.path.join(REPORTS, "build_report.json")
    with open(report_path, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
        fh.write("\n")

    print("Build OK")
    print(f"Compiled {len(compiled)} file(s)")
    print(f"Report written to {os.path.relpath(report_path, ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
