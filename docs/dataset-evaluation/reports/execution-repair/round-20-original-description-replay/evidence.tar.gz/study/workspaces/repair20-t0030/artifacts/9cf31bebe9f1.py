"""Small text statistics utilities.

Public API:
    normalize(text) -> str
    word_frequencies(text) -> dict[str, int]
    top_words(text, n=5) -> list[tuple[str, int]]
    summarize(text) -> dict
"""

from __future__ import annotations

import re
import unicodedata

__all__ = ["normalize", "word_frequencies", "top_words", "summarize"]

_WORD_RE = re.compile(r"[^\W\d_]+", re.UNICODE)


def normalize(text: str) -> str:
    """Lowercase ``text``, strip punctuation, and collapse whitespace.

    Only unicode letters are kept as word characters; digits and
    punctuation are treated as separators.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    lowered = unicodedata.normalize("NFKC", text).lower()
    words = _WORD_RE.findall(lowered)
    return " ".join(words)


def word_frequencies(text: str) -> dict[str, int]:
    """Return a mapping of normalized word -> count.

    Ordering is by descending count, then alphabetically for ties.
    """
    normalized = normalize(text)
    if not normalized:
        return {}
    counts: dict[str, int] = {}
    for word in normalized.split(" "):
        counts[word] = counts.get(word, 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])))


def top_words(text: str, n: int = 5) -> list[tuple[str, int]]:
    """Return the top ``n`` (word, count) pairs.

    ``n <= 0`` yields an empty list; ``n`` larger than the number of
    unique words yields all words.
    """
    if not isinstance(n, int):
        raise TypeError("n must be an int")
    if n <= 0:
        return []
    return list(word_frequencies(text).items())[:n]


def summarize(text: str) -> dict:
    """Return a summary dict for ``text``.

    Keys: ``characters``, ``words``, ``unique_words``, ``top_words``.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    normalized = normalize(text)
    words = normalized.split(" ") if normalized else []
    freqs = word_frequencies(text)
    return {
        "characters": len(text),
        "words": len(words),
        "unique_words": len(freqs),
        "top_words": list(freqs.items())[:5],
    }
