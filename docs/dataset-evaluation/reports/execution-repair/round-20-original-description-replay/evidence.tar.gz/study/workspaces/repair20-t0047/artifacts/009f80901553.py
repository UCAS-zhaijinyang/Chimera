"""Small, self-contained text statistics utilities.

This module provides deterministic helpers for counting words and characters
and for computing the most frequent words in a piece of text. It depends only
on the Python standard library.

Public API:
    word_count(text) -> int
    char_count(text, *, ignore_whitespace=False) -> int
    top_words(text, n=3) -> list[tuple[str, int]]
    summarize(text) -> dict
"""

from __future__ import annotations

from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Empty or whitespace-only input returns ``0``.
    """
    return len(text.split())


def char_count(text: str, *, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in ``text``.

    When ``ignore_whitespace`` is true, whitespace characters are excluded.
    """
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent lowercased words as ``(word, count)``.

    Words are whitespace-separated tokens folded to lowercase. Results are
    sorted by descending count and then alphabetically, so ties are broken
    deterministically. ``n <= 0`` returns an empty list.
    """
    if n <= 0:
        return []
    counts = Counter(token.lower() for token in text.split())
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return a summary dict with word, character, and unique-word counts."""
    tokens = [token.lower() for token in text.split()]
    return {
        "words": len(tokens),
        "chars": len(text),
        "unique_words": len(set(tokens)),
    }
