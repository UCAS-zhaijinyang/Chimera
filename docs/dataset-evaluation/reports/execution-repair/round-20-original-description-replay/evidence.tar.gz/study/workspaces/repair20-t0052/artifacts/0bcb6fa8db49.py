"""Small calculator module used by the bug-fix workflow fixture."""


def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def divide(a, b):
    """Return a / b.

    Bug (fixture variation 3): the original implementation used integer
    floor division (``a // b``), which silently truncated fractional
    results, e.g. ``divide(7, 2)`` returned ``3`` instead of ``3.5``.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b
