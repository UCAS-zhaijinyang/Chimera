# textstats

Small self-contained text statistics utilities.

## API

```python
from textstats import word_frequencies, top_words, summarize

word_frequencies("Hello, world! Hello.")  # {'hello': 2, 'world': 1}
top_words("b b b a a c", 2)               # [('b', 3), ('a', 2)]
summarize("one two two")                  # {'characters': 11, 'words': 3, 'unique_words': 2}
```

## Tests

```bash
python -m unittest discover -s tests -v
```
