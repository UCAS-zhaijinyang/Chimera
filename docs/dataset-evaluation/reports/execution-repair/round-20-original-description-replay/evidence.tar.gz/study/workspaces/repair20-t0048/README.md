# textstats

Small, dependency-free text statistics utilities.

## API

- `word_count(text)` — number of whitespace-separated words.
- `unique_word_count(text)` — number of distinct case-insensitive words.
- `char_count(text, include_spaces=True)` — character count.
- `most_common_word(text)` — most frequent lowercase word (ties by first appearance).
- `summarize(text)` — dict of aggregate statistics.

## Usage

```python
from textstats import summarize

summarize("the cat the dog")
# {'word_count': 4, 'unique_word_count': 3, 'char_count': 15,
#  'char_count_no_spaces': 12, 'most_common_word': 'the'}
```

## Tests

```bash
python -m unittest discover -s tests -v
```
