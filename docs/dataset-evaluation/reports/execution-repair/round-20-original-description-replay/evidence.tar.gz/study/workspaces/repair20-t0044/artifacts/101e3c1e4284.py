"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import (  # noqa: E402
    normalize_text,
    summarize,
    top_words,
    word_frequencies,
)


class NormalizeTextTests(unittest.TestCase):
    def test_lowercases(self):
        self.assertEqual(normalize_text("Hello WORLD"), "hello world")

    def test_strips_punctuation(self):
        self.assertEqual(normalize_text("Hello, world!"), "hello world")

    def test_collapses_whitespace(self):
        self.assertEqual(normalize_text("a   b\t\nc"), "a b c")

    def test_strips_leading_trailing(self):
        self.assertEqual(normalize_text("  spaced  "), "spaced")

    def test_keeps_apostrophes(self):
        self.assertEqual(normalize_text("Don't stop"), "don't stop")

    def test_empty_string(self):
        self.assertEqual(normalize_text(""), "")

    def test_punctuation_only(self):
        self.assertEqual(normalize_text("!!! ... ???"), "")


class WordFrequenciesTests(unittest.TestCase):
    def test_counts(self):
        self.assertEqual(
            word_frequencies("the cat the dog the"),
            {"the": 3, "cat": 1, "dog": 1},
        )

    def test_ordering_by_count_then_alpha(self):
        result = word_frequencies("b a b a c")
        self.assertEqual(list(result.items()), [("a", 2), ("b", 2), ("c", 1)])

    def test_empty(self):
        self.assertEqual(word_frequencies(""), {})

    def test_punctuation_only(self):
        self.assertEqual(word_frequencies("..."), {})


class TopWordsTests(unittest.TestCase):
    def test_default_limit(self):
        text = "a b c d e f g"
        self.assertEqual(len(top_words(text)), 5)

    def test_custom_limit(self):
        self.assertEqual(top_words("a a b b c", 2), [("a", 2), ("b", 2)])

    def test_zero_or_negative(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -3), [])

    def test_limit_larger_than_vocabulary(self):
        self.assertEqual(top_words("a b", 10), [("a", 1), ("b", 1)])

    def test_empty_text(self):
        self.assertEqual(top_words(""), [])


class SummarizeTests(unittest.TestCase):
    def test_basic_summary(self):
        text = "the cat the dog"
        result = summarize(text)
        self.assertEqual(result["characters"], len(text))
        self.assertEqual(result["words"], 4)
        self.assertEqual(result["unique_words"], 3)
        self.assertEqual(result["top_words"][0], ("the", 2))

    def test_empty_summary(self):
        result = summarize("")
        self.assertEqual(
            result,
            {"characters": 0, "words": 0, "unique_words": 0, "top_words": []},
        )

    def test_consistency_with_helpers(self):
        text = "One two two three three three"
        result = summarize(text)
        self.assertEqual(result["words"], sum(word_frequencies(text).values()))
        self.assertEqual(result["unique_words"], len(word_frequencies(text)))


if __name__ == "__main__":
    unittest.main()
