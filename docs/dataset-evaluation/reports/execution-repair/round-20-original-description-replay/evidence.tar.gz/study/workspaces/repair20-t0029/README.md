# textstats

A tiny, dependency-free text statistics utility.

## API

```python
from textstats import word_count, char_count, top_words, summarize

word_count("hello world")            # 2
char_count("a b", ignore_whitespace=True)  # 2
top_words("b b a", 2)                # [("b", 2), ("a", 1)]
summarize("one two two")             # {"words": 3, "chars": 11, "unique_words": 2}
```

## Tests

```
/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m unittest discover -s tests -v
```

## Build

```
/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m build
```
