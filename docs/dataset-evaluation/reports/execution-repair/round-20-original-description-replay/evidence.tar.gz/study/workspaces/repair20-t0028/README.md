# stats-util

Small descriptive statistics utilities (fixture variation 3).

## Usage

```python
from stats_util import mean, median, mode, summary

mean([1, 2, 3, 4])      # 2.5
median([4, 1, 3, 2])    # 2.5
mode([5, 5, 2, 2, 9])   # 2  (ties break to the smallest value)
summary([1, 2, 2, 3])   # {'count': 4, 'min': 1, 'max': 3, ...}
```

All functions raise `ValueError` on empty input.

## Tests

```
python -m unittest discover -s tests -v
```
