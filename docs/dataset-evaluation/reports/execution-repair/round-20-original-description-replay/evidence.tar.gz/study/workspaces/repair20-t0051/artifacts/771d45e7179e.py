"""Small arithmetic helpers used by the study fixture."""


def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def multiply(a, b):
    return a * b


def divide(a, b):
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b


def average(values):
    """Return the arithmetic mean of a non-empty sequence of numbers."""
    if not values:
        raise ValueError("average() requires at least one value")
    return sum(values) / len(values)


def percentage(part, whole):
    """Return ``part`` as a percentage of ``whole``."""
    if whole == 0:
        raise ZeroDivisionError("percentage() requires a non-zero whole")
    return part / whole * 100
