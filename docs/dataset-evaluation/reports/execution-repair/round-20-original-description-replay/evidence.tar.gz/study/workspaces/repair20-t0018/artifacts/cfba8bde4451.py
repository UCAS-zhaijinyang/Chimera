"""Tests for src/calculator.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from calculator import add, average, divide, multiply, subtract  # noqa: E402


def test_add():
    assert add(2, 3) == 5


def test_subtract():
    assert subtract(5, 3) == 2


def test_multiply():
    assert multiply(4, 3) == 12


def test_divide():
    assert divide(10, 4) == 2.5


def test_divide_by_zero_raises():
    with pytest.raises(ZeroDivisionError):
        divide(1, 0)


def test_average_of_values():
    assert average([1, 2, 3, 4]) == 2.5


def test_average_single_value():
    assert average([7]) == 7


def test_average_empty_raises():
    with pytest.raises(ValueError):
        average([])
