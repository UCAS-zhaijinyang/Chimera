"""Small text statistics utilities.

Standard-library-only helpers for computing basic statistics over a string.
"""

from __future__ import annotations

from typing import Dict, Optional


def _words(text: str) -> list[str]:
    """Split text into lowercase words on arbitrary whitespace."""
    return [w.lower() for w in text.split()]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated words in ``text``."""
    return len(text.split())


def unique_word_count(text: str) -> int:
    """Return the number of distinct case-insensitive words in ``text``."""
    return len(set(_words(text)))


def char_count(text: str, include_spaces: bool = True) -> int:
    """Return the character count of ``text``.

    When ``include_spaces`` is False, whitespace characters are excluded.
    """
    if include_spaces:
        return len(text)
    return sum(1 for ch in text if not ch.isspace())


def most_common_word(text: str) -> Optional[str]:
    """Return the most frequent lowercase word, or ``None`` if there are none.

    Ties are broken by first appearance in the text.
    """
    words = _words(text)
    if not words:
        return None
    counts: Dict[str, int] = {}
    for word in words:
        counts[word] = counts.get(word, 0) + 1
    best = words[0]
    for word in words:
        if counts[word] > counts[best]:
            best = word
    return best


def summarize(text: str) -> Dict[str, object]:
    """Return a dictionary of aggregate statistics for ``text``."""
    return {
        "word_count": word_count(text),
        "unique_word_count": unique_word_count(text),
        "char_count": char_count(text),
        "char_count_no_spaces": char_count(text, include_spaces=False),
        "most_common_word": most_common_word(text),
    }
