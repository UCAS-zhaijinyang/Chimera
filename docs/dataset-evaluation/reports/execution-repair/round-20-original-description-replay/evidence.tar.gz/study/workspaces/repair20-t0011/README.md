# statkit

Small, dependency-free streaming descriptive statistics utilities.

## Feature

`RunningStats` accumulates count, mean, population variance, sample variance,
min and max in a single pass using Welford's numerically stable algorithm.

```python
from statkit import RunningStats

rs = RunningStats().extend([2, 4, 4, 4, 5, 5, 7, 9])
rs.mean        # 5.0
rs.variance    # 4.0
rs.summary()   # dict with all six statistics
```

A module-level `mean(values)` helper is also provided.

## Tests

```bash
python -m unittest discover -s tests -v
```

## Build

```bash
python -m build
# fallback:
python -m pip wheel . -w dist
```
