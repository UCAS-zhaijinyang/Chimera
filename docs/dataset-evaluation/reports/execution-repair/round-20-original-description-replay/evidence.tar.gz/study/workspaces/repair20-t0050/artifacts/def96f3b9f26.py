"""Small arithmetic helpers used by the reporting layer."""


def add(a, b):
    """Return the sum of ``a`` and ``b``."""
    return a + b


def divide(a, b):
    """Return ``a`` divided by ``b``.

    Raises:
        ZeroDivisionError: if ``b`` is zero.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b


def average(values):
    """Return the arithmetic mean of ``values``.

    The previous implementation divided by ``len(values) - 1``, which
    produced a wrong result for every non-empty input and raised
    ``ZeroDivisionError`` for single-element inputs.
    """
    values = list(values)
    if not values:
        raise ValueError("average() requires at least one value")
    return sum(values) / len(values)
