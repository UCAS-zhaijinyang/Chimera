"""Tests covering the fixed ``average`` behavior in src/calculator.py."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from calculator import add, average  # noqa: E402


def test_add() -> None:
    assert add(2, 3) == 5


def test_average_basic() -> None:
    assert average([1, 2, 3, 4]) == 2.5


def test_average_empty_returns_zero() -> None:
    # Regression: previously raised ZeroDivisionError.
    assert average([]) == 0.0


def test_average_true_division() -> None:
    # Regression: previously could truncate to an int.
    assert average([1, 2]) == 1.5


def test_average_accepts_iterable() -> None:
    assert average(x for x in (2, 4, 6)) == 4.0
