"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_frequency, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_normal_sentence(self):
        self.assertEqual(word_count("hello world"), 2)

    def test_multiple_whitespace_collapses(self):
        self.assertEqual(word_count("  a\t b\n c  "), 3)

    def test_empty_string(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n "), 0)


class CharFrequencyTests(unittest.TestCase):
    def test_counts_and_ignores_whitespace(self):
        self.assertEqual(char_frequency("aab b"), {"a": 2, "b": 2})

    def test_preserves_first_appearance_order(self):
        self.assertEqual(list(char_frequency("cba cab").keys()), ["c", "b", "a"])

    def test_empty_string(self):
        self.assertEqual(char_frequency(""), {})


class TopWordsTests(unittest.TestCase):
    def test_ordering_by_count_then_alpha(self):
        result = top_words("b a b c a b", n=3)
        self.assertEqual(result, [("b", 3), ("a", 2), ("c", 1)])

    def test_tie_break_alphabetical(self):
        result = top_words("z y x", n=3)
        self.assertEqual(result, [("x", 1), ("y", 1), ("z", 1)])

    def test_case_insensitive_aggregation(self):
        result = top_words("Hello hello HELLO world", n=2)
        self.assertEqual(result, [("hello", 3), ("world", 1)])

    def test_n_larger_than_distinct_words(self):
        result = top_words("one two", n=10)
        self.assertEqual(result, [("one", 1), ("two", 1)])

    def test_n_zero_returns_empty(self):
        self.assertEqual(top_words("anything here", n=0), [])

    def test_n_negative_returns_empty(self):
        self.assertEqual(top_words("anything here", n=-5), [])

    def test_default_n_is_three(self):
        result = top_words("a b c d e")
        self.assertEqual(len(result), 3)


if __name__ == "__main__":
    unittest.main()
