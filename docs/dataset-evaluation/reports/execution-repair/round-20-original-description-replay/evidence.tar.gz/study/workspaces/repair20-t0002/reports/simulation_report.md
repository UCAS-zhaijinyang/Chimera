# Simulation Data Report

Source: simulation data (fixture variation 1)
Evidence level: simulation_only
Business status: not_measured

## Transformed Data (grouped by week)

| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Summary

- Total count across weeks: 8
- Weeks covered: 2 (W1, W2)
- Highest count: W2 (5)
- Lowest count: W1 (3)

## Notes

This report is based on simulated data only. Values are not measured business
results and should be treated as illustrative.
