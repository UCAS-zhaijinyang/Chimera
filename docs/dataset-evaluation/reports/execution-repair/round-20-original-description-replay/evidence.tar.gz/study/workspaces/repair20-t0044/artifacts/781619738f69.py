"""Small text statistics utilities.

This module provides a compact, dependency-free set of helpers for
normalizing text and computing simple word statistics.

Public API:
    normalize_text(text) -> str
    word_frequencies(text) -> dict[str, int]
    top_words(text, n=5) -> list[tuple[str, int]]
    summarize(text) -> dict
"""

from __future__ import annotations

import re
from collections import Counter

__all__ = ["normalize_text", "word_frequencies", "top_words", "summarize"]

_WORD_RE = re.compile(r"[a-z0-9']+")
_WHITESPACE_RE = re.compile(r"\s+")


def normalize_text(text: str) -> str:
    """Return a normalized form of ``text``.

    Normalization lowercases the input, removes punctuation (keeping
    alphanumeric characters and apostrophes), and collapses runs of
    whitespace into single spaces. The result is stripped of leading and
    trailing whitespace.

    Args:
        text: Arbitrary input string.

    Returns:
        The normalized string. Returns ``""`` for empty or non-word input.
    """
    if not text:
        return ""
    lowered = text.lower()
    words = _WORD_RE.findall(lowered)
    return " ".join(words)


def word_frequencies(text: str) -> dict[str, int]:
    """Count occurrences of each word in ``text``.

    Words are extracted using :func:`normalize_text`. The returned mapping
    is ordered by descending count, then alphabetically for ties.

    Args:
        text: Arbitrary input string.

    Returns:
        A dict mapping word -> count. Empty for input with no words.
    """
    normalized = normalize_text(text)
    if not normalized:
        return {}
    counts = Counter(normalized.split(" "))
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return dict(ordered)


def top_words(text: str, n: int = 5) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words in ``text``.

    Args:
        text: Arbitrary input string.
        n: Maximum number of results to return. Values ``<= 0`` yield an
            empty list.

    Returns:
        A list of ``(word, count)`` tuples ordered by descending count,
        then alphabetically for ties.
    """
    if n <= 0:
        return []
    return list(word_frequencies(text).items())[:n]


def summarize(text: str) -> dict:
    """Return a summary of simple statistics for ``text``.

    Args:
        text: Arbitrary input string.

    Returns:
        A dict with keys ``characters`` (length of the original text),
        ``words`` (number of words), ``unique_words`` (number of distinct
        words), and ``top_words`` (the five most frequent words).
    """
    frequencies = word_frequencies(text)
    return {
        "characters": len(text),
        "words": sum(frequencies.values()),
        "unique_words": len(frequencies),
        "top_words": top_words(text, 5),
    }
