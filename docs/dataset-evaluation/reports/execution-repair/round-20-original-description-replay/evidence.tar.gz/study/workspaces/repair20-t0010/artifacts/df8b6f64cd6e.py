"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import summarize, top_words, word_frequencies  # noqa: E402


class WordFrequenciesTests(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(word_frequencies(""), {})

    def test_case_insensitive(self):
        self.assertEqual(word_frequencies("The the THE"), {"the": 3})

    def test_punctuation_stripped(self):
        self.assertEqual(
            word_frequencies("Hello, world! Hello."),
            {"hello": 2, "world": 1},
        )

    def test_apostrophe_preserved(self):
        self.assertEqual(word_frequencies("Don't don't"), {"don't": 2})

    def test_numbers_counted(self):
        self.assertEqual(word_frequencies("a1 a1 b2"), {"a1": 2, "b2": 1})


class TopWordsTests(unittest.TestCase):
    def test_ordering_by_count(self):
        text = "b b b a a c"
        self.assertEqual(top_words(text, 2), [("b", 3), ("a", 2)])

    def test_tie_break_alphabetical(self):
        text = "b a c"
        self.assertEqual(top_words(text, 3), [("a", 1), ("b", 1), ("c", 1)])

    def test_n_larger_than_vocabulary(self):
        self.assertEqual(top_words("a b", 10), [("a", 1), ("b", 1)])

    def test_non_positive_n(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -3), [])

    def test_default_n(self):
        text = " ".join(f"w{i}" for i in range(10))
        self.assertEqual(len(top_words(text)), 5)


class SummarizeTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(
            summarize(""),
            {"characters": 0, "words": 0, "unique_words": 0},
        )

    def test_basic(self):
        result = summarize("one two two")
        self.assertEqual(result["characters"], len("one two two"))
        self.assertEqual(result["words"], 3)
        self.assertEqual(result["unique_words"], 2)


if __name__ == "__main__":
    unittest.main()
