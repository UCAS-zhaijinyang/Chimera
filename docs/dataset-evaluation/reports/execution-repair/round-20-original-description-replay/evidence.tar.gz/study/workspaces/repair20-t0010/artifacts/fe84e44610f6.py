"""Small self-contained text statistics utilities.

Public API:
    word_frequencies(text) -> dict[str, int]
    top_words(text, n=5) -> list[tuple[str, int]]
    summarize(text) -> dict
"""

from __future__ import annotations

import re
from collections import Counter

_WORD_RE = re.compile(r"[a-z0-9']+")


def _tokens(text: str) -> list[str]:
    """Lowercase the text and extract word tokens."""
    if not text:
        return []
    return _WORD_RE.findall(text.lower())


def word_frequencies(text: str) -> dict[str, int]:
    """Return a mapping of word token -> occurrence count.

    Tokens are lowercased; punctuation is stripped except for apostrophes
    appearing inside words (e.g. ``don't``).
    """
    return dict(Counter(_tokens(text)))


def top_words(text: str, n: int = 5) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words.

    Sorted by count descending, then alphabetically ascending for
    deterministic tie-breaking. If ``n`` exceeds the vocabulary size, all
    words are returned. A non-positive ``n`` yields an empty list.
    """
    if n <= 0:
        return []
    counts = Counter(_tokens(text))
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return basic statistics about ``text``.

    Keys: ``characters`` (raw length), ``words`` (token count),
    ``unique_words`` (distinct token count).
    """
    tokens = _tokens(text)
    return {
        "characters": len(text) if text else 0,
        "words": len(tokens),
        "unique_words": len(set(tokens)),
    }
