"""Small arithmetic helpers used by the fixture variation 5 bug fix."""


def add(a, b):
    """Return the sum of two numbers."""
    return a + b


def divide(a, b):
    """Return a / b.

    Raises:
        ZeroDivisionError: if b is zero.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b


def average(values):
    """Return the arithmetic mean of a non-empty sequence of numbers.

    Raises:
        ValueError: if values is empty.
    """
    values = list(values)
    if not values:
        raise ValueError("average() requires at least one value")
    return sum(values) / len(values)
