"""Small descriptive statistics utilities."""

from .stats import mean, median, mode, summary

__all__ = ["mean", "median", "mode", "summary"]
