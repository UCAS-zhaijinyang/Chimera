"""Word frequency counter utility.

Standard-library-only helpers for counting word occurrences in text and
reporting the most frequent words.
"""

from __future__ import annotations

import sys


def _normalize(token: str) -> str:
    """Lowercase ``token`` and strip surrounding non-alphanumeric characters."""
    token = token.lower()
    start = 0
    end = len(token)
    while start < end and not token[start].isalnum():
        start += 1
    while end > start and not token[end - 1].isalnum():
        end -= 1
    return token[start:end]


def word_frequencies(text: str) -> dict[str, int]:
    """Return a mapping of normalized word -> occurrence count.

    Tokens are split on whitespace, lowercased, and stripped of surrounding
    punctuation. Tokens that are empty after normalization are ignored.
    """
    counts: dict[str, int] = {}
    for raw in text.split():
        word = _normalize(raw)
        if not word:
            continue
        counts[word] = counts.get(word, 0) + 1
    return counts


def top_words(text: str, n: int = 5) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` tuples.

    Results are sorted by descending count, then alphabetically for ties.
    Raises ``ValueError`` if ``n`` is negative.
    """
    if n < 0:
        raise ValueError("n must be non-negative")
    counts = word_frequencies(text)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: read text from stdin and print top words."""
    argv = sys.argv[1:] if argv is None else argv
    n = 5
    if argv:
        try:
            n = int(argv[0])
        except ValueError:
            print(f"invalid n: {argv[0]!r}", file=sys.stderr)
            return 2
    text = sys.stdin.read()
    for word, count in top_words(text, n):
        print(f"{word} {count}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
