"""Tests for src/calculator.py (fixture variation 2)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from calculator import add, divide, subtract  # noqa: E402


class CalculatorTests(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(2, 3), 5)

    def test_subtract(self):
        self.assertEqual(subtract(5, 3), 2)

    def test_divide_returns_float(self):
        # Regression: floor division used to truncate 7 / 2 to 3.
        self.assertEqual(divide(7, 2), 3.5)

    def test_divide_exact(self):
        self.assertEqual(divide(6, 3), 2.0)

    def test_divide_by_zero(self):
        with self.assertRaises(ZeroDivisionError):
            divide(1, 0)


if __name__ == "__main__":
    unittest.main()
