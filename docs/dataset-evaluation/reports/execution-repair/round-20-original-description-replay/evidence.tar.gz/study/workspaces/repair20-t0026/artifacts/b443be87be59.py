"""Small text statistics utilities.

This module provides a tiny, dependency-free set of helpers for computing
basic statistics over text: word counts, character counts, the most frequent
words, and a combined summary.

All functions are pure and operate on ``str`` input.
"""

from __future__ import annotations

import re
from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]

_WORD_RE = re.compile(r"[a-z0-9']+")


def word_count(text: str) -> int:
    """Return the number of whitespace-separated words in ``text``.

    Empty or whitespace-only input returns ``0``.

    >>> word_count("hello world")
    2
    >>> word_count("   ")
    0
    """
    if not text:
        return 0
    return len(text.split())


def char_count(text: str, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in ``text``.

    When ``ignore_whitespace`` is ``True``, whitespace characters are excluded
    from the count.

    >>> char_count("a b")
    3
    >>> char_count("a b", ignore_whitespace=True)
    2
    """
    if not text:
        return 0
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words in ``text``.

    Words are matched case-insensitively and punctuation is stripped. Results
    are sorted by descending count, then alphabetically for ties.

    Raises:
        ValueError: if ``n`` is less than 1.

    >>> top_words("b a b", n=2)
    [('b', 2), ('a', 1)]
    """
    if n < 1:
        raise ValueError("n must be >= 1")
    tokens = _WORD_RE.findall(text.lower()) if text else []
    counts = Counter(tokens)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return a summary dict with word, character, and unique-word counts.

    >>> summarize("a b a")
    {'words': 3, 'chars': 5, 'unique_words': 2}
    """
    tokens = _WORD_RE.findall(text.lower()) if text else []
    return {
        "words": word_count(text),
        "chars": char_count(text),
        "unique_words": len(set(tokens)),
    }
