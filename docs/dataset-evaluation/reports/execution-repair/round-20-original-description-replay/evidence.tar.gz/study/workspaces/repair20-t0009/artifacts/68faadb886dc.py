"""Test package for the stats feature."""
