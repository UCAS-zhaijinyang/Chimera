"""Unit tests for the textstats feature module."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_normal_sentence(self):
        self.assertEqual(word_count("the quick brown fox"), 4)

    def test_empty_string(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n  "), 0)


class CharCountTests(unittest.TestCase):
    def test_default_counts_all(self):
        self.assertEqual(char_count("a b"), 3)

    def test_ignore_whitespace(self):
        self.assertEqual(char_count("a b\nc", ignore_whitespace=True), 3)

    def test_empty(self):
        self.assertEqual(char_count(""), 0)
        self.assertEqual(char_count("", ignore_whitespace=True), 0)


class TopWordsTests(unittest.TestCase):
    def test_ordering_descending(self):
        text = "b b b a a c"
        self.assertEqual(top_words(text, 2), [("b", 3), ("a", 2)])

    def test_tie_break_alphabetical(self):
        text = "beta alpha beta alpha gamma"
        self.assertEqual(top_words(text, 3), [("alpha", 2), ("beta", 2), ("gamma", 1)])

    def test_n_non_positive(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -5), [])

    def test_n_larger_than_unique(self):
        self.assertEqual(top_words("a b", 10), [("a", 1), ("b", 1)])

    def test_punctuation_stripped(self):
        text = "Hello, hello! HELLO. world"
        self.assertEqual(top_words(text, 1), [("hello", 3)])

    def test_punctuation_only_tokens_ignored(self):
        self.assertEqual(top_words("... --- !!!", 5), [])


class SummarizeTests(unittest.TestCase):
    def test_keys_and_values(self):
        text = "one two two three three three"
        result = summarize(text)
        self.assertEqual(
            set(result.keys()), {"words", "chars", "unique_words", "top_words"}
        )
        self.assertEqual(result["words"], 6)
        self.assertEqual(result["chars"], len(text))
        self.assertEqual(result["unique_words"], 3)
        self.assertEqual(result["top_words"][0], ("three", 3))

    def test_empty(self):
        result = summarize("")
        self.assertEqual(result["words"], 0)
        self.assertEqual(result["chars"], 0)
        self.assertEqual(result["unique_words"], 0)
        self.assertEqual(result["top_words"], [])


if __name__ == "__main__":
    unittest.main()
