"""Tests for the stringstats module."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stringstats import char_frequency, most_common_char, word_count  # noqa: E402


class TestWordCount:
    def test_simple_sentence(self):
        assert word_count("hello world") == 2

    def test_multiple_spaces(self):
        assert word_count("  hello   world  ") == 2

    def test_tabs_and_newlines(self):
        assert word_count("a\tb\nc\rd") == 4

    def test_empty_string(self):
        assert word_count("") == 0

    def test_whitespace_only(self):
        assert word_count("   \t\n  ") == 0

    def test_unicode_whitespace(self):
        assert word_count("a\u00a0b") == 2


class TestCharFrequency:
    def test_basic(self):
        assert char_frequency("aab") == {"a": 2, "b": 1}

    def test_case_insensitive(self):
        assert char_frequency("AaA") == {"a": 3}

    def test_whitespace_excluded(self):
        assert char_frequency("a b\tc\n") == {"a": 1, "b": 1, "c": 1}

    def test_punctuation_included(self):
        assert char_frequency("hi!!") == {"h": 1, "i": 1, "!": 2}

    def test_empty(self):
        assert char_frequency("") == {}

    def test_whitespace_only(self):
        assert char_frequency("   ") == {}

    def test_insertion_order_first_appearance(self):
        assert list(char_frequency("cba").keys()) == ["c", "b", "a"]

    def test_sum_matches_non_whitespace_count(self):
        text = "The quick brown fox!"
        assert sum(char_frequency(text).values()) == sum(
            1 for ch in text if not ch.isspace()
        )


class TestMostCommonChar:
    def test_clear_winner(self):
        assert most_common_char("aaabbc") == "a"

    def test_tie_first_appearance(self):
        assert most_common_char("abba") == "a"

    def test_tie_first_appearance_reversed(self):
        assert most_common_char("baab") == "b"

    def test_case_insensitive(self):
        assert most_common_char("AaaB") == "a"

    def test_whitespace_ignored(self):
        assert most_common_char("  x   x  y ") == "x"

    def test_empty(self):
        assert most_common_char("") is None

    def test_whitespace_only(self):
        assert most_common_char(" \t\n ") is None

    def test_single_char(self):
        assert most_common_char("z") == "z"


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
