"""Unit tests for src/slug_utils.py (stdlib unittest only)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from slug_utils import slugify, truncate_slug  # noqa: E402


class SlugifyTests(unittest.TestCase):
    def test_basic_phrase(self):
        self.assertEqual(slugify("Hello World"), "hello-world")

    def test_punctuation(self):
        self.assertEqual(slugify("Hello, World!!"), "hello-world")

    def test_mixed_separators(self):
        self.assertEqual(slugify("a  --  b"), "a-b")

    def test_leading_and_trailing_separators(self):
        self.assertEqual(slugify("  --Hello--  "), "hello")

    def test_empty_input(self):
        self.assertEqual(slugify(""), "")

    def test_whitespace_only(self):
        self.assertEqual(slugify("   \t\n "), "")

    def test_non_alphanumeric_only(self):
        self.assertEqual(slugify("!!!"), "")

    def test_digits_preserved(self):
        self.assertEqual(slugify("Version 2.0"), "version-2-0")

    def test_non_ascii_treated_as_separator(self):
        self.assertEqual(slugify("caf\u00e9 au lait"), "caf-au-lait")

    def test_underscores_and_slashes(self):
        self.assertEqual(slugify("a_b/c"), "a-b-c")

    def test_type_error_on_non_string(self):
        with self.assertRaises(TypeError):
            slugify(123)


class TruncateSlugTests(unittest.TestCase):
    def test_shorter_than_max_unchanged(self):
        self.assertEqual(truncate_slug("hello", 10), "hello")

    def test_exact_length_unchanged(self):
        self.assertEqual(truncate_slug("hello", 5), "hello")

    def test_boundary_cut(self):
        self.assertEqual(truncate_slug("hello-world-foo", 8), "hello")

    def test_no_boundary_hard_cut(self):
        self.assertEqual(truncate_slug("abcdefghij", 4), "abcd")

    def test_max_length_zero(self):
        self.assertEqual(truncate_slug("hello", 0), "")

    def test_negative_max_length_raises(self):
        with self.assertRaises(ValueError):
            truncate_slug("hello", -1)

    def test_non_int_max_length_raises(self):
        with self.assertRaises(TypeError):
            truncate_slug("hello", "5")

    def test_leading_hyphen_window_hard_cut(self):
        # window starts with a hyphen -> cut index 0 is not > 0, hard cut
        self.assertEqual(truncate_slug("-abcdef", 3), "-ab")

    def test_invariant_never_exceeds_max_length(self):
        slug = slugify("The Quick Brown Fox Jumps Over The Lazy Dog")
        for n in range(0, len(slug) + 5):
            self.assertLessEqual(len(truncate_slug(slug, n)), n)


if __name__ == "__main__":
    unittest.main()
