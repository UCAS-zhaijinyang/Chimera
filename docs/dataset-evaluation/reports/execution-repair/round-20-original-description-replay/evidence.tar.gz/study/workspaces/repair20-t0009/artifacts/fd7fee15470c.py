"""Unit tests for src/stats.py (fixture variation 2)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stats import mean, median, stdev, summarize  # noqa: E402


class MeanTests(unittest.TestCase):
    def test_mean_known(self):
        self.assertAlmostEqual(mean([1, 2, 3, 4]), 2.5)

    def test_mean_single(self):
        self.assertEqual(mean([7]), 7.0)

    def test_mean_empty_raises(self):
        with self.assertRaises(ValueError):
            mean([])


class MedianTests(unittest.TestCase):
    def test_median_odd(self):
        self.assertEqual(median([3, 1, 2]), 2)

    def test_median_even(self):
        self.assertEqual(median([4, 1, 3, 2]), 2.5)

    def test_median_unsorted_input(self):
        self.assertEqual(median([9, -1, 5]), 5)

    def test_median_empty_raises(self):
        with self.assertRaises(ValueError):
            median([])


class StdevTests(unittest.TestCase):
    def test_stdev_known(self):
        # sample stdev of [2, 4, 4, 4, 5, 5, 7, 9] == 2.138089935299395
        self.assertAlmostEqual(stdev([2, 4, 4, 4, 5, 5, 7, 9]), 2.138089935299395)

    def test_stdev_two_values(self):
        self.assertAlmostEqual(stdev([1, 3]), 2 ** 0.5)

    def test_stdev_single_raises(self):
        with self.assertRaises(ValueError):
            stdev([1])

    def test_stdev_empty_raises(self):
        with self.assertRaises(ValueError):
            stdev([])


class SummarizeTests(unittest.TestCase):
    def test_summarize_keys_and_values(self):
        result = summarize([1, 2, 3, 4])
        self.assertEqual(set(result), {"count", "mean", "median", "stdev"})
        self.assertEqual(result["count"], 4)
        self.assertAlmostEqual(result["mean"], 2.5)
        self.assertAlmostEqual(result["median"], 2.5)
        self.assertAlmostEqual(result["stdev"], stdev([1, 2, 3, 4]))

    def test_summarize_single_value(self):
        result = summarize([5])
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["stdev"], 0.0)

    def test_summarize_empty_raises(self):
        with self.assertRaises(ValueError):
            summarize([])


class ImmutabilityTests(unittest.TestCase):
    def test_inputs_not_mutated(self):
        data = [3, 1, 2]
        snapshot = list(data)
        mean(data)
        median(data)
        stdev(data)
        summarize(data)
        self.assertEqual(data, snapshot)


if __name__ == "__main__":
    unittest.main()
