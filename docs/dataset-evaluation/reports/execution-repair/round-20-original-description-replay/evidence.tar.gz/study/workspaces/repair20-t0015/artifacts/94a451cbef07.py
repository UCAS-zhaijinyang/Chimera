"""Small calculator module used by the bug-fix workflow fixture."""


def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def divide(a, b):
    """Return a / b.

    Bug (variation 2): the original implementation used integer floor
    division (`a // b`), which silently truncated fractional results.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b
