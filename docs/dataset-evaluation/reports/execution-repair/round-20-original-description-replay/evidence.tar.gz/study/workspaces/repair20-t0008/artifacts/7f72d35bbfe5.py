"""Small string statistics utilities.

Pure, dependency-free helpers for counting words and characters in text.
"""

from __future__ import annotations

__all__ = ["word_count", "char_frequency", "most_common_char"]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated words in ``text``.

    Empty or whitespace-only input yields ``0``.
    """
    return len(text.split())


def char_frequency(text: str) -> dict[str, int]:
    """Return frequency of each non-whitespace character, lowercased.

    Keys are lowercased characters in order of first appearance.
    Whitespace characters are ignored. Empty/whitespace-only input -> ``{}``.
    """
    counts: dict[str, int] = {}
    for ch in text.lower():
        if ch.isspace():
            continue
        counts[ch] = counts.get(ch, 0) + 1
    return counts


def most_common_char(text: str) -> str | None:
    """Return the most frequent non-whitespace character, lowercased.

    Ties are broken by first appearance. Returns ``None`` when there are no
    non-whitespace characters.
    """
    counts = char_frequency(text)
    if not counts:
        return None
    best_char = None
    best_count = -1
    for ch, count in counts.items():
        if count > best_count:
            best_char = ch
            best_count = count
    return best_char
