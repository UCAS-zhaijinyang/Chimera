"""Small text statistics utilities.

This module provides a self-contained set of helpers for computing simple
statistics over text: word counts, character frequencies, and the most
frequent words.

All functions are pure and depend only on the Python standard library.
"""

from __future__ import annotations

__all__ = ["word_count", "char_frequency", "top_words"]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Empty or whitespace-only input returns ``0``.

    >>> word_count("hello world")
    2
    >>> word_count("   ")
    0
    """
    if not text:
        return 0
    return len(text.split())


def char_frequency(text: str) -> dict[str, int]:
    """Return a mapping of non-whitespace characters to their counts.

    Whitespace characters are ignored. Keys are ordered by first appearance
    in ``text`` (dict insertion order).

    >>> char_frequency("aab b")
    {'a': 2, 'b': 2}
    """
    counts: dict[str, int] = {}
    for ch in text:
        if ch.isspace():
            continue
        counts[ch] = counts.get(ch, 0) + 1
    return counts


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` pairs.

    Words are compared case-insensitively and returned lowercased. Results are
    sorted by descending count, then alphabetically for ties. If ``n <= 0`` an
    empty list is returned. If fewer than ``n`` distinct words exist, all of
    them are returned.

    >>> top_words("b a b c a b", n=2)
    [('b', 3), ('a', 2)]
    >>> top_words("anything", n=0)
    []
    """
    if n <= 0:
        return []

    counts: dict[str, int] = {}
    for token in text.split():
        key = token.lower()
        counts[key] = counts.get(key, 0) + 1

    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]
