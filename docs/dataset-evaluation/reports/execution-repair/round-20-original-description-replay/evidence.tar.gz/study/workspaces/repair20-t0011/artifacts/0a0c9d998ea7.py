"""statkit — small streaming descriptive statistics utilities.

Provides :class:`RunningStats`, a single-pass accumulator computing count,
mean, population variance, sample variance, min and max using Welford's
numerically stable algorithm.

Example
-------
>>> rs = RunningStats().extend([2, 4, 4, 4, 5, 5, 7, 9])
>>> rs.mean
5.0
>>> rs.variance
4.0
"""

from __future__ import annotations

import math
from typing import Iterable

__all__ = ["StatisticsError", "RunningStats", "mean"]


class StatisticsError(ValueError):
    """Raised when a statistic is requested from insufficient data."""


def _check_number(value: object) -> float:
    """Validate and coerce *value* to float.

    ``bool`` is explicitly rejected even though it is an ``int`` subclass,
    because treating ``True``/``False`` as 1/0 is almost always a bug.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"expected a real number, got {type(value).__name__!r}")
    result = float(value)
    if math.isnan(result):
        raise ValueError("NaN is not a supported input value")
    return result


class RunningStats:
    """Accumulate descriptive statistics in a single pass.

    All properties raise :class:`StatisticsError` when there is not enough
    data to compute them.
    """

    __slots__ = ("_count", "_mean", "_m2", "_min", "_max")

    def __init__(self) -> None:
        self._count = 0
        self._mean = 0.0
        self._m2 = 0.0
        self._min = math.inf
        self._max = -math.inf

    # -- mutation ---------------------------------------------------------
    def push(self, value: float) -> "RunningStats":
        """Add a single observation and return ``self`` for chaining."""
        x = _check_number(value)
        self._count += 1
        delta = x - self._mean
        self._mean += delta / self._count
        self._m2 += delta * (x - self._mean)
        if x < self._min:
            self._min = x
        if x > self._max:
            self._max = x
        return self

    def extend(self, values: Iterable[float]) -> "RunningStats":
        """Add every observation from *values* and return ``self``."""
        for value in values:
            self.push(value)
        return self

    # -- read-only properties --------------------------------------------
    @property
    def count(self) -> int:
        """Number of observations pushed so far."""
        return self._count

    @property
    def mean(self) -> float:
        """Arithmetic mean of the observations."""
        if self._count == 0:
            raise StatisticsError("mean requires at least one data point")
        return self._mean

    @property
    def variance(self) -> float:
        """Population variance (denominator ``n``)."""
        if self._count == 0:
            raise StatisticsError("variance requires at least one data point")
        return self._m2 / self._count

    @property
    def sample_variance(self) -> float:
        """Unbiased sample variance (denominator ``n - 1``)."""
        if self._count < 2:
            raise StatisticsError(
                "sample variance requires at least two data points"
            )
        return self._m2 / (self._count - 1)

    @property
    def min(self) -> float:
        """Smallest observation seen."""
        if self._count == 0:
            raise StatisticsError("min requires at least one data point")
        return self._min

    @property
    def max(self) -> float:
        """Largest observation seen."""
        if self._count == 0:
            raise StatisticsError("max requires at least one data point")
        return self._max

    # -- aggregate --------------------------------------------------------
    def summary(self) -> dict:
        """Return all statistics as a plain ``dict``."""
        return {
            "count": self._count,
            "mean": self.mean,
            "variance": self.variance,
            "sample_variance": self.sample_variance,
            "min": self.min,
            "max": self.max,
        }

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"RunningStats(count={self._count})"


def mean(values: Iterable[float]) -> float:
    """Return the arithmetic mean of *values*.

    Raises :class:`StatisticsError` if *values* is empty.
    """
    return RunningStats().extend(values).mean
