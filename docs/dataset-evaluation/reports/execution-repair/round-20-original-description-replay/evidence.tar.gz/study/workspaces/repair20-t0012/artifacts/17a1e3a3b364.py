"""textstats — a tiny, dependency-free text statistics utility.

Public API:
    word_count(text) -> int
    char_count(text, *, ignore_whitespace=False) -> int
    top_words(text, n=3) -> list[tuple[str, int]]
    summarize(text) -> dict
"""

from __future__ import annotations

from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]

__version__ = "0.1.0"


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Empty or whitespace-only input returns 0.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return len(text.split())


def char_count(text: str, *, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in ``text``.

    When ``ignore_whitespace`` is True, whitespace characters are excluded.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` pairs.

    Matching is case-insensitive. Results are sorted by count descending,
    then by word ascending for deterministic output. Raises ``ValueError``
    if ``n`` is negative.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    if n < 0:
        raise ValueError("n must be non-negative")
    if n == 0:
        return []
    counts = Counter(token.lower() for token in text.split())
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return a summary dict with word, character and unique-word counts."""
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    tokens = text.split()
    return {
        "words": len(tokens),
        "chars": len(text),
        "unique_words": len({token.lower() for token in tokens}),
    }
