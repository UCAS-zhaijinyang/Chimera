# Simulation Data Report — Fixture Variation 3

## Source
- Query: simulation data fixture variation 3
- Evidence level: simulation_only
- Business status: not_measured

## Transformed Data (grouped by week)
| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Summary
- Total count across weeks: 8
- Weeks observed: 2 (W1, W2)
- Highest week: W2 with 5

## Notes
This report is based on simulated fixture data only. Values are not measured
business results and should not be treated as production metrics.
