"""Tests for the wordfreq utility module."""

import os
import subprocess
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from wordfreq import top_words, word_frequencies  # noqa: E402


def test_basic_counting_and_lowercasing():
    assert word_frequencies("The the THE cat") == {"the": 3, "cat": 1}


def test_punctuation_stripping():
    assert word_frequencies("Hello, world!") == {"hello": 1, "world": 1}


def test_punctuation_only_tokens_ignored():
    assert word_frequencies("... --- !!!") == {}


def test_empty_and_whitespace_input():
    assert word_frequencies("") == {}
    assert word_frequencies("   \n\t  ") == {}
    assert top_words("") == []


def test_top_words_default_and_explicit_n():
    text = "a b b c c c d d d d"
    assert top_words(text) == [("d", 4), ("c", 3), ("b", 2), ("a", 1)]
    assert top_words(text, 2) == [("d", 4), ("c", 3)]


def test_tie_breaking_is_alphabetical():
    text = "banana apple cherry"
    assert top_words(text) == [("apple", 1), ("banana", 1), ("cherry", 1)]


def test_n_zero_returns_empty_list():
    assert top_words("a b c", 0) == []


def test_n_larger_than_distinct_words():
    assert top_words("a b", 10) == [("a", 1), ("b", 1)]


def test_negative_n_raises_value_error():
    with pytest.raises(ValueError):
        top_words("a b c", -1)


def test_cli_smoke():
    src = os.path.join(os.path.dirname(__file__), "..", "src")
    proc = subprocess.run(
        [sys.executable, os.path.join(src, "wordfreq.py"), "2"],
        input="one two two three three three",
        capture_output=True,
        text=True,
        check=True,
    )
    assert proc.stdout.splitlines() == ["three 3", "two 2"]
