"""Tests for src/calculator.py covering the fixed average() behaviour."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from calculator import add, average, flatten  # noqa: E402


class CalculatorTests(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(2, 3), 5)
        self.assertEqual(add(2.5, 0.5), 3.0)

    def test_average_basic(self):
        self.assertEqual(average([1, 2, 3]), 2.0)
        self.assertEqual(average([10]), 10.0)

    def test_average_empty_raises_value_error(self):
        with self.assertRaises(ValueError):
            average([])

    def test_average_empty_does_not_raise_zero_division(self):
        try:
            average([])
        except ZeroDivisionError:  # pragma: no cover - regression guard
            self.fail("average([]) must not raise ZeroDivisionError")
        except ValueError:
            pass

    def test_flatten(self):
        self.assertEqual(flatten([[1, 2], [3], []]), [1, 2, 3])


if __name__ == "__main__":
    unittest.main()
