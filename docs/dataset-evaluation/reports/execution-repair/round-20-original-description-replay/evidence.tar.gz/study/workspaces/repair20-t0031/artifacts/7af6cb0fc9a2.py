"""Small calculator utilities used by the repair fixture.

The bug in the original fixture: ``average`` divided by the length of the
input list without guarding against an empty list, raising ZeroDivisionError
instead of returning a well-defined value. It also used integer division
semantics implicitly for some inputs. The fix below returns ``0.0`` for an
empty input and always performs true division.
"""

from __future__ import annotations

from typing import Iterable


def add(a: float, b: float) -> float:
    """Return the sum of ``a`` and ``b``."""
    return a + b


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` rather than raising ``ZeroDivisionError``.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)
