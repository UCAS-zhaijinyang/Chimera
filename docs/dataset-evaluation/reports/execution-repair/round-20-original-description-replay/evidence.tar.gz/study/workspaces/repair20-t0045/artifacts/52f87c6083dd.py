"""Small text statistics utilities.

Public API:
    word_frequencies(text) -> dict[str, int]
    top_words(text, n=3) -> list[tuple[str, int]]
    unique_word_count(text) -> int
"""

from __future__ import annotations

import string

__all__ = ["word_frequencies", "top_words", "unique_word_count"]

_PUNCT = string.punctuation


def _tokenize(text: str) -> list[str]:
    """Lowercase, split on whitespace, strip edge punctuation, drop empties."""
    tokens: list[str] = []
    for raw in text.split():
        token = raw.strip(_PUNCT).lower()
        if token:
            tokens.append(token)
    return tokens


def word_frequencies(text: str) -> dict[str, int]:
    """Return a mapping of normalized word -> occurrence count."""
    counts: dict[str, int] = {}
    for token in _tokenize(text):
        counts[token] = counts.get(token, 0) + 1
    return counts


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` tuples.

    Sorted by descending count, then alphabetically for deterministic ties.
    Raises ``ValueError`` if ``n`` is negative.
    """
    if n < 0:
        raise ValueError("n must be non-negative")
    counts = word_frequencies(text)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def unique_word_count(text: str) -> int:
    """Return the number of distinct normalized words in ``text``."""
    return len(word_frequencies(text))
