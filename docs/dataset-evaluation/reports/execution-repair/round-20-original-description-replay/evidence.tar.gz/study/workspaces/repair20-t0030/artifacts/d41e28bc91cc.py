"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import normalize, summarize, top_words, word_frequencies  # noqa: E402


class TestNormalize(unittest.TestCase):
    def test_lowercases_and_strips_punctuation(self):
        self.assertEqual(normalize("Hello, World!"), "hello world")

    def test_collapses_whitespace(self):
        self.assertEqual(normalize("  a\t b\n\nc  "), "a b c")

    def test_digits_are_separators(self):
        self.assertEqual(normalize("abc123def"), "abc def")

    def test_empty_and_whitespace(self):
        self.assertEqual(normalize(""), "")
        self.assertEqual(normalize("   \t\n"), "")

    def test_punctuation_only(self):
        self.assertEqual(normalize("!!! ... ???"), "")

    def test_unicode_letters_preserved(self):
        self.assertEqual(normalize("Café ÜBER"), "café über")

    def test_type_error(self):
        with self.assertRaises(TypeError):
            normalize(None)


class TestWordFrequencies(unittest.TestCase):
    def test_counts(self):
        self.assertEqual(
            word_frequencies("the cat the dog the"),
            {"the": 3, "cat": 1, "dog": 1},
        )

    def test_ordering_by_count_then_alpha(self):
        result = word_frequencies("b a b a c")
        self.assertEqual(list(result.items()), [("a", 2), ("b", 2), ("c", 1)])

    def test_empty(self):
        self.assertEqual(word_frequencies(""), {})
        self.assertEqual(word_frequencies("   "), {})

    def test_case_insensitive(self):
        self.assertEqual(word_frequencies("Dog dog DOG"), {"dog": 3})


class TestTopWords(unittest.TestCase):
    def test_default_n(self):
        text = "a b c d e f g"
        self.assertEqual(len(top_words(text)), 5)

    def test_n_zero_or_negative(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -3), [])

    def test_n_larger_than_unique(self):
        self.assertEqual(top_words("a b", 10), [("a", 1), ("b", 1)])

    def test_type_error(self):
        with self.assertRaises(TypeError):
            top_words("a b", "2")


class TestSummarize(unittest.TestCase):
    def test_basic(self):
        result = summarize("the cat the dog")
        self.assertEqual(result["characters"], len("the cat the dog"))
        self.assertEqual(result["words"], 4)
        self.assertEqual(result["unique_words"], 3)
        self.assertEqual(result["top_words"][0], ("the", 2))

    def test_empty(self):
        result = summarize("")
        self.assertEqual(result["characters"], 0)
        self.assertEqual(result["words"], 0)
        self.assertEqual(result["unique_words"], 0)
        self.assertEqual(result["top_words"], [])

    def test_type_error(self):
        with self.assertRaises(TypeError):
            summarize(123)


if __name__ == "__main__":
    unittest.main()
