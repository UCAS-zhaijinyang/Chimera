"""Small statistics helpers (fixture variation 2).

Pure-stdlib implementation of mean/median/stdev/summarize.
"""

from __future__ import annotations

from typing import Sequence

__all__ = ["mean", "median", "stdev", "summarize"]


def _as_list(values: Sequence[float]) -> list:
    """Return a shallow copy so callers' inputs are never mutated."""
    return list(values)


def mean(values: Sequence[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = _as_list(values)
    if not data:
        raise ValueError("mean() requires at least one value")
    return sum(data) / len(data)


def median(values: Sequence[float]) -> float:
    """Return the median of ``values``.

    For even-length input the two middle values are averaged.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = sorted(_as_list(values))
    if not data:
        raise ValueError("median() requires at least one value")
    n = len(data)
    mid = n // 2
    if n % 2 == 1:
        return data[mid]
    return (data[mid - 1] + data[mid]) / 2


def stdev(values: Sequence[float]) -> float:
    """Return the sample standard deviation (n-1 denominator).

    Raises:
        ValueError: if fewer than two values are supplied.
    """
    data = _as_list(values)
    if len(data) < 2:
        raise ValueError("stdev() requires at least two values")
    m = mean(data)
    variance = sum((x - m) ** 2 for x in data) / (len(data) - 1)
    return variance ** 0.5


def summarize(values: Sequence[float]) -> dict:
    """Return count/mean/median/stdev for ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = _as_list(values)
    if not data:
        raise ValueError("summarize() requires at least one value")
    return {
        "count": len(data),
        "mean": mean(data),
        "median": median(data),
        "stdev": stdev(data) if len(data) >= 2 else 0.0,
    }
