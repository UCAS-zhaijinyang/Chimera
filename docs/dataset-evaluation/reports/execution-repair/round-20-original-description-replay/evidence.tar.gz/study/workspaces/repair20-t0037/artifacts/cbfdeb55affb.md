# Simulation Data Report

Source: simulation data (fixture variation 0)
Evidence level: simulation_only — business_status: not_measured

## Transformed data (grouped by week)

| Week | Count |
| ---- | ----- |
| W1   | 3     |
| W2   | 5     |

## Summary

- Total count across weeks: 8
- Weeks covered: 2 (W1, W2)
- Highest week: W2 with 5

## Notes

This report is based on simulated fixture data only. Values are not measured
business results and should not be used for decision-making.
