"""Small arithmetic helpers used by the reporting layer."""


def add(a, b):
    """Return the sum of two numbers."""
    return a + b


def subtract(a, b):
    """Return the difference of two numbers."""
    return a - b


def multiply(a, b):
    """Return the product of two numbers."""
    return a * b


def divide(a, b):
    """Return the quotient of two numbers.

    Raises:
        ZeroDivisionError: if ``b`` is zero.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b


def average(values):
    """Return the arithmetic mean of a non-empty sequence of numbers.

    Raises:
        ValueError: if ``values`` is empty.
    """
    values = list(values)
    if not values:
        raise ValueError("average() requires at least one value")
    total = 0
    for value in values:
        total = add(total, value)
    return divide(total, len(values))
