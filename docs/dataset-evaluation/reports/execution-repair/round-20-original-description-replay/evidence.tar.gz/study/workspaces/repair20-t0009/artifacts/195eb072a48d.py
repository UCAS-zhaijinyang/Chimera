"""Build/check script: compile sources and run the unittest suite.

Usage:
    python build.py

Exits 0 on success, non-zero on any failure.
"""

import compileall
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
TESTS = os.path.join(ROOT, "tests")


def main() -> int:
    print("[build] compiling sources under src/ ...")
    if not compileall.compile_dir(SRC, quiet=1):
        print("[build] FAILED: compilation error")
        return 1

    print("[build] running unit tests ...")
    loader = unittest.TestLoader()
    suite = loader.discover(start_dir=TESTS, pattern="test_*.py", top_level_dir=ROOT)
    result = unittest.TextTestRunner(verbosity=2).run(suite)

    if result.wasSuccessful():
        print("[build] OK: %d tests passed" % result.testsRun)
        return 0
    print("[build] FAILED: %d failures, %d errors"
          % (len(result.failures), len(result.errors)))
    return 1


if __name__ == "__main__":
    sys.exit(main())
