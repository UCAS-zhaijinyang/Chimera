"""Build/verification script for the textstats feature.

Steps:
1. Import src/textstats.py and assert the public API is present.
2. Run the unit test suite via unittest discovery.
3. Exit non-zero on any failure with a clear summary.
"""

import os
import sys
import unittest

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
TESTS = os.path.join(ROOT, "tests")

sys.path.insert(0, SRC)


def check_api() -> None:
    import textstats

    for name in ("word_frequencies", "top_words", "unique_word_count"):
        assert hasattr(textstats, name), f"missing public API: {name}"
    assert textstats.word_frequencies("a a b") == {"a": 2, "b": 1}
    assert textstats.top_words("a a b", 1) == [("a", 2)]
    assert textstats.unique_word_count("a a b") == 2
    print("[build] API check passed")


def run_tests() -> int:
    loader = unittest.TestLoader()
    suite = loader.discover(TESTS, pattern="test_*.py")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    return 0 if result.wasSuccessful() else 1


def main() -> int:
    check_api()
    code = run_tests()
    if code == 0:
        print("[build] SUCCESS: all checks passed")
    else:
        print("[build] FAILURE: test suite reported failures")
    return code


if __name__ == "__main__":
    sys.exit(main())
