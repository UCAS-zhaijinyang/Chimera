"""Public API for the ``textstats`` feature."""

from __future__ import annotations

from .core import char_count, summarize, top_words, word_count

__all__ = ["word_count", "char_count", "top_words", "summarize"]
__version__ = "0.1.0"
