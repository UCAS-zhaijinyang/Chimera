# Simulation Data Report — Fixture Variation 5

## Source
- Query: simulation data fixture variation 5
- Evidence level: simulation_only
- Business status: not_measured

## Raw Data
| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Transformed Data (grouped by week)
| Group | Count |
|-------|-------|
| W1    | 3     |
| W2    | 5     |

## Summary
- Total count across weeks: 8
- Weeks observed: 2 (W1, W2)
- Trend: count increased from 3 in W1 to 5 in W2 (+2, +66.7%)

## Notes
This report is based on simulated fixture data only. Values are not measured
business results and should not be used for operational decisions.
