"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_normal(self):
        self.assertEqual(word_count("the quick brown fox"), 4)

    def test_empty(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n  "), 0)

    def test_multiple_spaces(self):
        self.assertEqual(word_count("a   b\tc\nd"), 4)


class CharCountTests(unittest.TestCase):
    def test_with_whitespace(self):
        self.assertEqual(char_count("a b"), 3)

    def test_ignore_whitespace(self):
        self.assertEqual(char_count("a b\tc", ignore_whitespace=True), 3)

    def test_empty(self):
        self.assertEqual(char_count(""), 0)
        self.assertEqual(char_count("", ignore_whitespace=True), 0)


class TopWordsTests(unittest.TestCase):
    def test_ordering(self):
        text = "b a a c c c"
        self.assertEqual(top_words(text, 2), [("c", 3), ("a", 2)])

    def test_tie_break_alphabetical(self):
        text = "b a"
        self.assertEqual(top_words(text, 2), [("a", 1), ("b", 1)])

    def test_case_folding(self):
        text = "The the THE cat"
        self.assertEqual(top_words(text, 1), [("the", 3)])

    def test_n_non_positive(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -5), [])

    def test_n_larger_than_vocab(self):
        self.assertEqual(top_words("a b", 10), [("a", 1), ("b", 1)])

    def test_empty_text(self):
        self.assertEqual(top_words("", 3), [])


class SummarizeTests(unittest.TestCase):
    def test_consistency(self):
        text = "One two two three"
        result = summarize(text)
        self.assertEqual(result["words"], 4)
        self.assertEqual(result["chars"], len(text))
        self.assertEqual(result["unique_words"], 3)

    def test_empty(self):
        self.assertEqual(
            summarize(""), {"words": 0, "chars": 0, "unique_words": 0}
        )


if __name__ == "__main__":
    unittest.main()
