"""Unit tests for :mod:`stringstats`."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stringstats import summarize  # noqa: E402


class SummarizeTests(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(
            summarize(""),
            {"chars": 0, "words": 0, "lines": 0, "unique_words": 0},
        )

    def test_single_line(self):
        result = summarize("hello world hello")
        self.assertEqual(result["chars"], 17)
        self.assertEqual(result["words"], 3)
        self.assertEqual(result["lines"], 1)
        self.assertEqual(result["unique_words"], 2)

    def test_multi_line(self):
        text = "alpha beta\ngamma delta\n"
        result = summarize(text)
        self.assertEqual(result["lines"], 2)
        self.assertEqual(result["words"], 4)
        self.assertEqual(result["unique_words"], 4)

    def test_case_insensitive_unique_words(self):
        self.assertEqual(summarize("The the THE")["unique_words"], 1)

    def test_non_string_raises_type_error(self):
        with self.assertRaises(TypeError):
            summarize(123)


if __name__ == "__main__":
    unittest.main()
