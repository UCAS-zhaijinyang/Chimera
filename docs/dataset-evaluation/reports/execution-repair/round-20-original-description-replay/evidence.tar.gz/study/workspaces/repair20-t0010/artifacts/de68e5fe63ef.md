# Design Document — Small Python Feature (fixture variation 3)

## 1. Feature Selection
Implement a small, self-contained utility: a **text statistics / word frequency** module.

Module: `src/textstats.py`

Public API:
- `word_frequencies(text: str) -> dict[str, int]`
  - Normalizes text to lowercase, extracts word tokens matching `[a-z0-9']+`,
    and returns a mapping of token -> count.
- `top_words(text: str, n: int = 5) -> list[tuple[str, int]]`
  - Returns the `n` most frequent words, sorted by count descending then
    alphabetically ascending for deterministic ties.
- `summarize(text: str) -> dict`
  - Returns `{"characters": int, "words": int, "unique_words": int}`.

## 2. Rationale
- Self-contained, no third-party dependencies, deterministic output.
- Easy to unit test with clear edge cases (empty string, punctuation,
  case-insensitivity, tie-breaking, `n` larger than vocabulary).

## 3. Files
- `src/textstats.py` — feature implementation.
- `tests/test_textstats.py` — unit tests (pytest-style, also runnable via unittest).
- `pyproject.toml` — minimal packaging metadata for build.

## 4. Test Plan
- Empty input returns empty structures / zero counts.
- Case-insensitive counting.
- Punctuation stripped; apostrophes preserved inside words.
- Tie-breaking is alphabetical.
- `top_words` with `n` > vocabulary returns all words.
- `summarize` counts characters, words, unique words correctly.

## 5. Build Plan
- Use `python -m build` if available; otherwise fall back to
  `python -m pip wheel . --no-deps -w dist` or `python -m compileall src`.
- Build evidence captured under `dist/` or `reports/`.

## 6. Review Plan
- Prepare a pull request record summarizing changes, tests, and build result
  for simulated approval.
