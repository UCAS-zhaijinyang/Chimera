"""Small string statistics utility.

Provides :func:`summarize`, which returns basic statistics about a text
string: character count, word count, line count and unique word count.
"""

from __future__ import annotations

__all__ = ["summarize"]


def summarize(text: str) -> dict:
    """Return basic statistics for ``text``.

    Parameters
    ----------
    text:
        The string to summarize. Must be a ``str``.

    Returns
    -------
    dict
        A mapping with the keys ``chars``, ``words``, ``lines`` and
        ``unique_words``.

    Raises
    ------
    TypeError
        If ``text`` is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")

    tokens = text.split()
    return {
        "chars": len(text),
        "words": len(tokens),
        "lines": len(text.splitlines()),
        "unique_words": len({token.lower() for token in tokens}),
    }
