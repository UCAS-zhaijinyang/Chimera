#!/bin/sh
# Minimal build/verification step: run the unit test suite with the provided interpreter.
set -eu

PY=/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python

echo "== build: running unit tests =="
"$PY" -m unittest discover -s tests -p 'test_*.py' -v
echo "== build: OK =="
