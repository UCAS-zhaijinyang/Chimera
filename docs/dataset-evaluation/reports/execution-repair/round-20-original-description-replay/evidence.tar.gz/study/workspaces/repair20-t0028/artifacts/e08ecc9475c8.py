import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stats_util import mean, median, mode, summary  # noqa: E402


class MeanTests(unittest.TestCase):
    def test_mean_known_values(self):
        self.assertEqual(mean([1, 2, 3, 4]), 2.5)

    def test_mean_single_value(self):
        self.assertEqual(mean([7]), 7)

    def test_mean_empty_raises(self):
        with self.assertRaises(ValueError):
            mean([])


class MedianTests(unittest.TestCase):
    def test_median_odd_length(self):
        self.assertEqual(median([3, 1, 2]), 2)

    def test_median_even_length(self):
        self.assertEqual(median([4, 1, 3, 2]), 2.5)

    def test_median_empty_raises(self):
        with self.assertRaises(ValueError):
            median([])


class ModeTests(unittest.TestCase):
    def test_mode_single(self):
        self.assertEqual(mode([1, 2, 2, 3]), 2)

    def test_mode_tie_break_smallest(self):
        self.assertEqual(mode([5, 5, 2, 2, 9]), 2)

    def test_mode_empty_raises(self):
        with self.assertRaises(ValueError):
            mode([])


class SummaryTests(unittest.TestCase):
    def test_summary_keys_and_values(self):
        result = summary([1, 2, 2, 3])
        self.assertEqual(result["count"], 4)
        self.assertEqual(result["min"], 1)
        self.assertEqual(result["max"], 3)
        self.assertEqual(result["mean"], 2.0)
        self.assertEqual(result["median"], 2.0)
        self.assertEqual(result["mode"], 2)

    def test_summary_empty_raises(self):
        with self.assertRaises(ValueError):
            summary([])


if __name__ == "__main__":
    unittest.main()
