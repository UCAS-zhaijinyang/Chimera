"""Small text statistics utility.

Self-contained feature module providing word/character counts and
word-frequency summaries. No third-party dependencies.
"""

from __future__ import annotations

import string
from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]

_PUNCT = string.punctuation


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``."""
    return len(text.split())


def char_count(text: str, *, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in ``text``.

    When ``ignore_whitespace`` is true, whitespace characters are excluded.
    """
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def _normalize(token: str) -> str:
    """Lowercase ``token`` and strip surrounding punctuation."""
    return token.lower().strip(_PUNCT)


def _frequencies(text: str) -> Counter:
    """Build a frequency counter of normalized tokens."""
    counter: Counter = Counter()
    for token in text.split():
        normalized = _normalize(token)
        if normalized:
            counter[normalized] += 1
    return counter


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` pairs.

    Ordering is by descending count, then ascending alphabetically.
    ``n <= 0`` yields an empty list; ``n`` larger than the number of
    unique words yields all unique words.
    """
    if n <= 0:
        return []
    counter = _frequencies(text)
    ordered = sorted(counter.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return a summary dict for ``text``.

    Keys: ``words``, ``chars``, ``unique_words``, ``top_words``.
    """
    counter = _frequencies(text)
    return {
        "words": word_count(text),
        "chars": char_count(text),
        "unique_words": len(counter),
        "top_words": top_words(text),
    }
