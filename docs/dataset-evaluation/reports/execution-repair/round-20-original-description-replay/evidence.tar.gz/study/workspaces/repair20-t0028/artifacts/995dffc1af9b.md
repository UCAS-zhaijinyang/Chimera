# Design: Small Python Feature (fixture variation 3)

## Goal
Implement a small, self-contained Python feature with tests, a passing test run, a build, and a prepared pull request for simulated review.

## Feature
A `stats` utility module providing simple descriptive statistics over a sequence of numbers:

- `mean(values)` -> arithmetic mean; raises `ValueError` on empty input.
- `median(values)` -> median; raises `ValueError` on empty input.
- `mode(values)` -> most common value; ties resolved by smallest value; raises `ValueError` on empty input.
- `summary(values)` -> dict with `count`, `min`, `max`, `mean`, `median`, `mode`.

## Layout
```
src/
  stats_util/
    __init__.py
    stats.py
tests/
  test_stats.py
pyproject.toml
```

## Design decisions
- Pure standard library, no third-party runtime dependencies.
- Deterministic behavior; explicit `ValueError` for empty input.
- `mode` tie-break: smallest value wins (documented and tested).
- Package importable as `stats_util` with `src` on `sys.path` (or installed via build).

## Test plan
- `mean` of known values; empty raises `ValueError`.
- `median` odd and even length; empty raises `ValueError`.
- `mode` single mode and tie-break; empty raises `ValueError`.
- `summary` keys and values consistent with individual functions.

## Build plan
- `pyproject.toml` with setuptools backend; build sdist/wheel via `python -m build` (fallback: `pip wheel .`).

## Review plan
- Open a pull request record summarizing changes, tests, and build evidence for simulated approval.
