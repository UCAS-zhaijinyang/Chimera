"""Core implementation of the ``textstats`` feature.

A tiny, dependency-free text statistics utility.
"""

from __future__ import annotations

from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Empty or whitespace-only input yields ``0``.
    """
    if not text:
        return 0
    return len(text.split())


def char_count(text: str, *, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in ``text``.

    When ``ignore_whitespace`` is true, whitespace characters are excluded.
    """
    if not text:
        return 0
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent lowercased words.

    Ordering is by descending count, then alphabetically for ties.
    ``n <= 0`` returns an empty list.
    """
    if n <= 0 or not text:
        return []
    counts = Counter(token.lower() for token in text.split())
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return a small summary dict for ``text``."""
    tokens = text.split() if text else []
    return {
        "words": len(tokens),
        "chars": len(text) if text else 0,
        "unique_words": len({token.lower() for token in tokens}),
    }
