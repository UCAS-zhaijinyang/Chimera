"""Small dependency-free string utilities for URL-friendly slugs.

Public API:
    slugify(text) -> str
    truncate_slug(slug, max_length) -> str
"""

import re

__all__ = ["slugify", "truncate_slug"]

_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def slugify(text):
    """Convert arbitrary text into a URL-friendly slug.

    Rules:
      * lowercases the input
      * strips leading/trailing whitespace
      * replaces any run of non-alphanumeric characters with a single hyphen
      * removes leading/trailing hyphens
      * returns "" for empty or whitespace-only input

    Non-ASCII characters are treated as separators (no transliteration).
    """
    if not isinstance(text, str):
        raise TypeError("slugify() expects a str, got %r" % type(text).__name__)

    slug = text.strip().lower()
    slug = _NON_ALNUM.sub("-", slug)
    slug = slug.strip("-")
    return slug


def truncate_slug(slug, max_length):
    """Truncate ``slug`` to at most ``max_length`` characters.

    When a hyphen boundary exists inside the allowed window, the slug is cut
    at that boundary (the hyphen itself is dropped). Otherwise a hard cut is
    performed. The result never exceeds ``max_length`` characters.
    """
    if not isinstance(max_length, int) or isinstance(max_length, bool):
        raise TypeError("max_length must be an int")
    if max_length < 0:
        raise ValueError("max_length must be non-negative")

    if max_length == 0:
        return ""
    if len(slug) <= max_length:
        return slug

    window = slug[:max_length]
    cut = window.rfind("-")
    if cut > 0:
        return window[:cut]
    return window
