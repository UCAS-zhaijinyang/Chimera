"""Unit tests for src/textstats.py.

Runnable with pytest or ``python -m unittest discover``.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_normal_sentence(self):
        self.assertEqual(word_count("hello world"), 2)

    def test_empty_string(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n "), 0)

    def test_multiple_spaces(self):
        self.assertEqual(word_count("a   b    c"), 3)


class CharCountTests(unittest.TestCase):
    def test_counts_all_characters(self):
        self.assertEqual(char_count("a b"), 3)

    def test_ignore_whitespace(self):
        self.assertEqual(char_count("a b", ignore_whitespace=True), 2)

    def test_empty_string(self):
        self.assertEqual(char_count(""), 0)


class TopWordsTests(unittest.TestCase):
    def test_frequency_ordering(self):
        self.assertEqual(top_words("b a b c b a", n=2), [("b", 3), ("a", 2)])

    def test_tie_break_alphabetical(self):
        self.assertEqual(top_words("b a c", n=3), [("a", 1), ("b", 1), ("c", 1)])

    def test_case_insensitive(self):
        self.assertEqual(top_words("Hello hello HELLO", n=1), [("hello", 3)])

    def test_punctuation_stripped(self):
        self.assertEqual(top_words("hi, hi! hi?", n=1), [("hi", 3)])

    def test_default_n(self):
        self.assertEqual(len(top_words("a b c d e")), 3)

    def test_invalid_n_raises(self):
        with self.assertRaises(ValueError):
            top_words("a b", n=0)


class SummarizeTests(unittest.TestCase):
    def test_known_sample(self):
        self.assertEqual(
            summarize("a b a"),
            {"words": 3, "chars": 5, "unique_words": 2},
        )

    def test_empty(self):
        self.assertEqual(
            summarize(""),
            {"words": 0, "chars": 0, "unique_words": 0},
        )


if __name__ == "__main__":
    unittest.main()
