# textstats

Small, self-contained text statistics utility (fixture variation 3).

## API

```python
from textstats import word_count, char_count, top_words, summarize

word_count("the quick brown fox")            # 4
char_count("a b", ignore_whitespace=True)    # 2
top_words("b b a", 2)                        # [("b", 2), ("a", 1)]
summarize("one two two")                     # {"words": 3, "chars": 11, ...}
```

## Tests

```bash
python -m unittest discover -s tests -v
```

## Build

```bash
python -m build
```
