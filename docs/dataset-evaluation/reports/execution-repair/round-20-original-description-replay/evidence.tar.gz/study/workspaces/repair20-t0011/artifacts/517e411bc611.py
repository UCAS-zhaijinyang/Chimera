"""Unit tests for :mod:`statkit`."""

import math
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from statkit import RunningStats, StatisticsError, mean  # noqa: E402


class EmptyStateTests(unittest.TestCase):
    def test_count_is_zero(self):
        self.assertEqual(RunningStats().count, 0)

    def test_mean_raises(self):
        with self.assertRaises(StatisticsError):
            RunningStats().mean

    def test_variance_raises(self):
        with self.assertRaises(StatisticsError):
            RunningStats().variance

    def test_sample_variance_raises(self):
        with self.assertRaises(StatisticsError):
            RunningStats().sample_variance

    def test_min_max_raise(self):
        rs = RunningStats()
        with self.assertRaises(StatisticsError):
            rs.min
        with self.assertRaises(StatisticsError):
            rs.max

    def test_statistics_error_is_value_error(self):
        self.assertTrue(issubclass(StatisticsError, ValueError))


class SingleElementTests(unittest.TestCase):
    def setUp(self):
        self.rs = RunningStats().push(7)

    def test_count(self):
        self.assertEqual(self.rs.count, 1)

    def test_mean(self):
        self.assertEqual(self.rs.mean, 7.0)

    def test_variance_is_zero(self):
        self.assertEqual(self.rs.variance, 0.0)

    def test_sample_variance_raises(self):
        with self.assertRaises(StatisticsError):
            self.rs.sample_variance

    def test_min_max(self):
        self.assertEqual(self.rs.min, 7.0)
        self.assertEqual(self.rs.max, 7.0)


class KnownDatasetTests(unittest.TestCase):
    DATA = [2, 4, 4, 4, 5, 5, 7, 9]

    def setUp(self):
        self.rs = RunningStats().extend(self.DATA)

    def test_count(self):
        self.assertEqual(self.rs.count, 8)

    def test_mean(self):
        self.assertAlmostEqual(self.rs.mean, 5.0, places=12)

    def test_population_variance(self):
        self.assertAlmostEqual(self.rs.variance, 4.0, places=12)

    def test_sample_variance(self):
        # 32 / 7
        self.assertAlmostEqual(self.rs.sample_variance, 32.0 / 7.0, places=12)

    def test_min_max(self):
        self.assertEqual(self.rs.min, 2.0)
        self.assertEqual(self.rs.max, 9.0)

    def test_summary_keys_and_values(self):
        s = self.rs.summary()
        self.assertEqual(
            set(s),
            {"count", "mean", "variance", "sample_variance", "min", "max"},
        )
        self.assertEqual(s["count"], 8)
        self.assertAlmostEqual(s["mean"], 5.0, places=12)
        self.assertAlmostEqual(s["variance"], 4.0, places=12)
        self.assertEqual(s["min"], 2.0)
        self.assertEqual(s["max"], 9.0)


class ChainingAndIterableTests(unittest.TestCase):
    def test_push_returns_self(self):
        rs = RunningStats()
        self.assertIs(rs.push(1), rs)

    def test_extend_returns_self(self):
        rs = RunningStats()
        self.assertIs(rs.extend([1, 2]), rs)

    def test_extend_accepts_generator(self):
        rs = RunningStats().extend(x for x in range(1, 6))
        self.assertEqual(rs.count, 5)
        self.assertAlmostEqual(rs.mean, 3.0, places=12)

    def test_chained_calls(self):
        rs = RunningStats().push(1).push(2).push(3)
        self.assertEqual(rs.count, 3)
        self.assertAlmostEqual(rs.mean, 2.0, places=12)

    def test_extend_empty_iterable_is_noop(self):
        rs = RunningStats().extend([])
        self.assertEqual(rs.count, 0)


class InputValidationTests(unittest.TestCase):
    def test_string_rejected(self):
        with self.assertRaises(TypeError):
            RunningStats().push("3")

    def test_none_rejected(self):
        with self.assertRaises(TypeError):
            RunningStats().push(None)

    def test_bool_rejected(self):
        with self.assertRaises(TypeError):
            RunningStats().push(True)

    def test_nan_rejected(self):
        with self.assertRaises(ValueError):
            RunningStats().push(float("nan"))

    def test_int_accepted(self):
        self.assertEqual(RunningStats().push(3).mean, 3.0)

    def test_float_accepted(self):
        self.assertEqual(RunningStats().push(3.5).mean, 3.5)


class NumericalStabilityTests(unittest.TestCase):
    def test_large_offset(self):
        base = 1e9
        data = [base + d for d in (4, 7, 13, 16)]
        rs = RunningStats().extend(data)
        self.assertAlmostEqual(rs.mean, base + 10.0, places=6)
        # population variance of [4,7,13,16] is 22.5
        self.assertAlmostEqual(rs.variance, 22.5, places=6)

    def test_matches_naive_computation(self):
        data = [0.1] * 1000
        rs = RunningStats().extend(data)
        self.assertAlmostEqual(rs.mean, 0.1, places=12)
        self.assertAlmostEqual(rs.variance, 0.0, places=12)


class ModuleLevelMeanTests(unittest.TestCase):
    def test_mean_helper(self):
        self.assertAlmostEqual(mean([1, 2, 3, 4]), 2.5, places=12)

    def test_mean_helper_empty_raises(self):
        with self.assertRaises(StatisticsError):
            mean([])

    def test_mean_helper_generator(self):
        self.assertAlmostEqual(mean(x * 2 for x in range(5)), 4.0, places=12)


if __name__ == "__main__":
    unittest.main()
