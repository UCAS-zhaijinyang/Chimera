"""Unit tests for the textstats feature."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n  "), 0)

    def test_single_word(self):
        self.assertEqual(word_count("hello"), 1)

    def test_multiple_words(self):
        self.assertEqual(word_count("the quick brown fox"), 4)

    def test_non_str_raises(self):
        with self.assertRaises(TypeError):
            word_count(123)


class CharCountTests(unittest.TestCase):
    def test_default_counts_all(self):
        self.assertEqual(char_count("a b"), 3)

    def test_ignore_whitespace(self):
        self.assertEqual(char_count("a b\tc\n", ignore_whitespace=True), 3)

    def test_empty(self):
        self.assertEqual(char_count(""), 0)
        self.assertEqual(char_count("", ignore_whitespace=True), 0)


class TopWordsTests(unittest.TestCase):
    def test_frequency_order(self):
        text = "a b a c a b"
        self.assertEqual(top_words(text, 2), [("a", 3), ("b", 2)])

    def test_case_insensitive(self):
        self.assertEqual(top_words("The the THE cat", 1), [("the", 3)])

    def test_tie_break_alphabetical(self):
        self.assertEqual(top_words("b a c", 3), [("a", 1), ("b", 1), ("c", 1)])

    def test_n_limits_results(self):
        self.assertEqual(len(top_words("a b c d", 2)), 2)

    def test_n_zero(self):
        self.assertEqual(top_words("a b c", 0), [])

    def test_negative_n_raises(self):
        with self.assertRaises(ValueError):
            top_words("a b c", -1)

    def test_empty_text(self):
        self.assertEqual(top_words("", 3), [])


class SummarizeTests(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(
            summarize("the cat the dog"),
            {"words": 4, "chars": 16, "unique_words": 3},
        )

    def test_empty(self):
        self.assertEqual(
            summarize(""), {"words": 0, "chars": 0, "unique_words": 0}
        )

    def test_consistency_with_helpers(self):
        text = "One two two three three three"
        summary = summarize(text)
        self.assertEqual(summary["words"], word_count(text))
        self.assertEqual(summary["chars"], char_count(text))


if __name__ == "__main__":
    unittest.main()
