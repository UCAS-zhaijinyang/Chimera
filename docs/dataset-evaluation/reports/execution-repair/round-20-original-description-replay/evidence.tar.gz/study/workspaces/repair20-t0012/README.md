# textstats

A tiny, dependency-free text statistics utility.

## API

```python
from textstats import word_count, char_count, top_words, summarize

word_count("the quick brown fox")            # 4
char_count("a b\tc\n", ignore_whitespace=True)  # 3
top_words("a b a c a b", 2)                  # [('a', 3), ('b', 2)]
summarize("the cat the dog")                 # {'words': 4, 'chars': 16, 'unique_words': 3}
```

## Behavior notes

- Tokenization is whitespace-based (`str.split()`).
- Word frequency matching is case-insensitive; punctuation is retained as part of a token.
- `top_words` sorts by count descending, then word ascending (deterministic).
- `top_words(text, n)` raises `ValueError` for negative `n`.

## Development

```bash
python -m pytest -q          # or: python -m unittest discover -s tests
python -m build              # produces dist/*.whl and dist/*.tar.gz
```
