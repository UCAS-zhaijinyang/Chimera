"""Descriptive statistics helpers.

All functions accept any non-empty iterable of numbers and raise
``ValueError`` for empty input.
"""

from __future__ import annotations

from collections import Counter
from typing import Iterable, List


def _as_list(values: Iterable[float]) -> List[float]:
    data = list(values)
    if not data:
        raise ValueError("values must not be empty")
    return data


def mean(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``."""
    data = _as_list(values)
    return sum(data) / len(data)


def median(values: Iterable[float]) -> float:
    """Return the median of ``values``."""
    data = sorted(_as_list(values))
    n = len(data)
    mid = n // 2
    if n % 2 == 1:
        return data[mid]
    return (data[mid - 1] + data[mid]) / 2


def mode(values: Iterable[float]) -> float:
    """Return the most common value.

    Ties are broken by choosing the smallest value.
    """
    data = _as_list(values)
    counts = Counter(data)
    best = max(counts.values())
    return min(value for value, count in counts.items() if count == best)


def summary(values: Iterable[float]) -> dict:
    """Return a dict of descriptive statistics for ``values``."""
    data = _as_list(values)
    return {
        "count": len(data),
        "min": min(data),
        "max": max(data),
        "mean": mean(data),
        "median": median(data),
        "mode": mode(data),
    }
