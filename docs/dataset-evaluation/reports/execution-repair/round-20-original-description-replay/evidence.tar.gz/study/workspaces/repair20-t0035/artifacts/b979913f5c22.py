"""Small calculator module used by the bug-fix workflow fixture.

The bug: ``average`` divided by the number of *values* instead of the number
of *items*, so passing an empty list raised ``ZeroDivisionError`` and passing
a list of lists produced a wrong result.
"""

from __future__ import annotations

from typing import Iterable, List, Sequence, Union

Number = Union[int, float]


def add(a: Number, b: Number) -> Number:
    """Return the sum of ``a`` and ``b``."""
    return a + b


def average(values: Sequence[Number]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    if not values:
        raise ValueError("average() requires at least one value")
    return sum(values) / len(values)


def flatten(items: Iterable[Iterable[Number]]) -> List[Number]:
    """Flatten one level of nesting into a list of numbers."""
    return [value for group in items for value in group]
