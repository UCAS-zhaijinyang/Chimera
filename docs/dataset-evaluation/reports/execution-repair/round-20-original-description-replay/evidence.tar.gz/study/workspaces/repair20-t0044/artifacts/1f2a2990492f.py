"""Build/verification script for the textstats feature.

Steps:
1. Byte-compile ``src/`` and ``tests/`` via ``compileall``.
2. Run the unittest suite over ``tests/``.
3. Exit non-zero on any failure.
"""

import compileall
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "src")
TESTS = os.path.join(ROOT, "tests")


def compile_sources() -> bool:
    print("[build] byte-compiling sources...")
    ok = True
    for target in (SRC, TESTS):
        if not compileall.compile_dir(target, quiet=1):
            ok = False
    print("[build] compile:", "OK" if ok else "FAILED")
    return ok


def run_tests() -> bool:
    print("[build] running test suite...")
    sys.path.insert(0, SRC)
    loader = unittest.TestLoader()
    suite = loader.discover(TESTS, pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    ok = result.wasSuccessful()
    print("[build] tests:", "OK" if ok else "FAILED")
    return ok


def main() -> int:
    compiled = compile_sources()
    tested = run_tests()
    if compiled and tested:
        print("[build] BUILD SUCCESS")
        return 0
    print("[build] BUILD FAILURE")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
