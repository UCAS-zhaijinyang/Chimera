"""Unit tests for the ``textstats`` feature."""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n  "), 0)

    def test_basic(self):
        self.assertEqual(word_count("hello world"), 2)

    def test_collapses_runs(self):
        self.assertEqual(word_count("  a   b \n c "), 3)


class CharCountTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(char_count(""), 0)

    def test_basic(self):
        self.assertEqual(char_count("abc"), 3)

    def test_ignore_whitespace(self):
        self.assertEqual(char_count("a b\tc\n", ignore_whitespace=True), 3)

    def test_keep_whitespace_default(self):
        self.assertEqual(char_count("a b"), 3)


class TopWordsTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(top_words(""), [])

    def test_n_non_positive(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -1), [])

    def test_ordering_by_count(self):
        text = "b b b a a c"
        self.assertEqual(top_words(text, 2), [("b", 3), ("a", 2)])

    def test_tie_break_alphabetical(self):
        text = "b a c"
        self.assertEqual(top_words(text, 3), [("a", 1), ("b", 1), ("c", 1)])

    def test_case_folding(self):
        text = "Hello hello HELLO world"
        self.assertEqual(top_words(text, 1), [("hello", 3)])

    def test_default_n(self):
        text = "a b c d e"
        self.assertEqual(len(top_words(text)), 3)


class SummarizeTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(summarize(""), {"words": 0, "chars": 0, "unique_words": 0})

    def test_basic(self):
        text = "one two two"
        self.assertEqual(summarize(text), {"words": 3, "chars": 11, "unique_words": 2})

    def test_consistency_with_helpers(self):
        text = "Alpha beta alpha"
        summary = summarize(text)
        self.assertEqual(summary["words"], word_count(text))
        self.assertEqual(summary["chars"], char_count(text))


if __name__ == "__main__":
    unittest.main()
