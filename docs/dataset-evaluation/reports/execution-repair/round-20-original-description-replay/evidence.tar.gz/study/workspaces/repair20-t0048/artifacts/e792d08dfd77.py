"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import textstats  # noqa: E402


class TestWordCount(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(textstats.word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(textstats.word_count("   \t\n  "), 0)

    def test_simple_sentence(self):
        self.assertEqual(textstats.word_count("the quick brown fox"), 4)

    def test_extra_whitespace(self):
        self.assertEqual(textstats.word_count("  a   b\tc\n"), 3)


class TestUniqueWordCount(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(textstats.unique_word_count(""), 0)

    def test_case_insensitive(self):
        self.assertEqual(textstats.unique_word_count("The the THE"), 1)

    def test_mixed(self):
        self.assertEqual(textstats.unique_word_count("a b a c B"), 3)


class TestCharCount(unittest.TestCase):
    def test_with_spaces(self):
        self.assertEqual(textstats.char_count("a b"), 3)

    def test_without_spaces(self):
        self.assertEqual(textstats.char_count("a b", include_spaces=False), 2)

    def test_empty(self):
        self.assertEqual(textstats.char_count(""), 0)
        self.assertEqual(textstats.char_count("", include_spaces=False), 0)


class TestMostCommonWord(unittest.TestCase):
    def test_empty(self):
        self.assertIsNone(textstats.most_common_word(""))

    def test_whitespace_only(self):
        self.assertIsNone(textstats.most_common_word("   "))

    def test_simple(self):
        self.assertEqual(textstats.most_common_word("a b a c a"), "a")

    def test_case_insensitive(self):
        self.assertEqual(textstats.most_common_word("Go go GO stop"), "go")

    def test_tie_breaks_by_first_appearance(self):
        self.assertEqual(textstats.most_common_word("b a"), "b")


class TestSummarize(unittest.TestCase):
    def test_keys_and_values(self):
        result = textstats.summarize("the cat the dog")
        self.assertEqual(
            set(result.keys()),
            {
                "word_count",
                "unique_word_count",
                "char_count",
                "char_count_no_spaces",
                "most_common_word",
            },
        )
        self.assertEqual(result["word_count"], 4)
        self.assertEqual(result["unique_word_count"], 3)
        self.assertEqual(result["char_count"], len("the cat the dog"))
        self.assertEqual(result["char_count_no_spaces"], 12)
        self.assertEqual(result["most_common_word"], "the")

    def test_empty(self):
        result = textstats.summarize("")
        self.assertEqual(result["word_count"], 0)
        self.assertEqual(result["unique_word_count"], 0)
        self.assertEqual(result["char_count"], 0)
        self.assertIsNone(result["most_common_word"])


if __name__ == "__main__":
    unittest.main()
