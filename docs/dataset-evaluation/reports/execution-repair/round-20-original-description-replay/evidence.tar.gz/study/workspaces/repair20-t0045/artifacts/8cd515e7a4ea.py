"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import top_words, unique_word_count, word_frequencies  # noqa: E402


class WordFrequenciesTests(unittest.TestCase):
    def test_basic_mixed_case(self):
        self.assertEqual(word_frequencies("The the THE"), {"the": 3})

    def test_punctuation_stripped(self):
        self.assertEqual(
            word_frequencies("hello, world!"),
            {"hello": 1, "world": 1},
        )

    def test_empty_and_whitespace(self):
        self.assertEqual(word_frequencies(""), {})
        self.assertEqual(word_frequencies("   \t\n "), {})

    def test_counts_multiple_words(self):
        self.assertEqual(
            word_frequencies("a b a c a b"),
            {"a": 3, "b": 2, "c": 1},
        )


class TopWordsTests(unittest.TestCase):
    def test_ordering_and_tie_break(self):
        text = "b a c a b a"
        self.assertEqual(top_words(text, 3), [("a", 3), ("b", 2), ("c", 1)])

    def test_tie_break_alphabetical(self):
        text = "z y x"
        self.assertEqual(top_words(text, 3), [("x", 1), ("y", 1), ("z", 1)])

    def test_n_exceeds_distinct(self):
        self.assertEqual(top_words("one two", 10), [("one", 1), ("two", 1)])

    def test_n_zero(self):
        self.assertEqual(top_words("one two", 0), [])

    def test_negative_n_raises(self):
        with self.assertRaises(ValueError):
            top_words("one two", -1)

    def test_default_n(self):
        text = "a b c d e"
        self.assertEqual(len(top_words(text)), 3)


class UniqueWordCountTests(unittest.TestCase):
    def test_unique_count(self):
        self.assertEqual(unique_word_count("a b a c a b"), 3)

    def test_unique_count_empty(self):
        self.assertEqual(unique_word_count(""), 0)


if __name__ == "__main__":
    unittest.main()
