"""Word-frequency counter utility.

Provides:
    word_frequency(text) -> dict[str, int]
    format_counts(counts) -> str
    main(argv=None) -> int   (CLI: reads stdin, prints sorted counts)
"""

from __future__ import annotations

import re
import sys

__all__ = ["word_frequency", "format_counts", "main"]

# Leading/trailing non-alphanumeric characters (Unicode-aware in Python 3).
_EDGE_PUNCT = re.compile(r"^\W+|\W+$", re.UNICODE)


def _clean(token: str) -> str:
    """Strip leading/trailing punctuation and lowercase the token."""
    return _EDGE_PUNCT.sub("", token).lower()


def word_frequency(text: str) -> dict[str, int]:
    """Count occurrences of each word in *text*.

    Words are whitespace-separated; leading/trailing punctuation is stripped
    and comparison is case-insensitive. Empty or whitespace-only input yields
    an empty dict.
    """
    if not text or not text.strip():
        return {}

    counts: dict[str, int] = {}
    for raw in text.split():
        word = _clean(raw)
        if not word:
            continue
        counts[word] = counts.get(word, 0) + 1
    return counts


def format_counts(counts: dict[str, int]) -> str:
    """Render counts sorted by descending frequency, then alphabetically."""
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return "\n".join(f"{word}: {count}" for word, count in ordered)


def main(argv=None) -> int:
    """CLI entry point: read text from stdin and print sorted word counts."""
    text = sys.stdin.read()
    output = format_counts(word_frequency(text))
    if output:
        print(output)
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
