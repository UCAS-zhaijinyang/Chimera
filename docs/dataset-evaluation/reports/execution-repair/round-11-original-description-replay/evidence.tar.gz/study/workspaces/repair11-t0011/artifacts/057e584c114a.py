"""Reports package: text analysis utilities."""

from .word_frequency import top_n, word_frequency

__all__ = ["word_frequency", "top_n"]
