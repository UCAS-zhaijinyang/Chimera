"""Small calculator module used by the fixture test suite.

Bug (fixture variation 0): ``average`` divided by the number of items
instead of the number of *valid* items, so an empty input raised
ZeroDivisionError and inputs containing ``None`` produced a wrong result.
"""

from typing import Iterable, Optional


def average(values: Iterable[Optional[float]]) -> float:
    """Return the mean of the non-None values.

    Raises ValueError when there are no valid values.
    """
    valid = [v for v in values if v is not None]
    if not valid:
        raise ValueError("average() requires at least one non-None value")
    return sum(valid) / len(valid)
