"""Small utility module containing the bug fixed in fixture variation 4.

Bug: ``average`` divided by the length of the input list without guarding
against an empty list, raising ``ZeroDivisionError`` instead of returning a
sensible value. The fix returns ``0.0`` for empty input and keeps the
original behaviour for non-empty input.
"""

from __future__ import annotations

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` rather than raising ``ZeroDivisionError``.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)


def total(values: Iterable[float]) -> float:
    """Return the sum of ``values`` (empty input yields ``0.0``)."""
    return float(sum(values))
