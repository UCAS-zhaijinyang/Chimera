"""Small dependency-free slugify utility.

Converts arbitrary text into a URL-friendly slug:

- lowercased
- runs of non-alphanumeric characters collapsed to a single hyphen
- leading/trailing hyphens stripped
- ``None`` or empty input yields ``""``
"""

from __future__ import annotations

import re
import unicodedata

__all__ = ["slugify"]

_NON_ALNUM_RE = re.compile(r"[^a-z0-9]+")


def slugify(text: str | None) -> str:
    """Return a URL-friendly slug for ``text``.

    Args:
        text: Arbitrary input text, or ``None``.

    Returns:
        A lowercase slug containing only ``[a-z0-9-]`` with no leading or
        trailing hyphens. Returns ``""`` for ``None`` or empty input.
    """
    if text is None:
        return ""

    # Fold accented characters to their ASCII base form (é -> e).
    normalized = unicodedata.normalize("NFKD", text)
    ascii_text = "".join(ch for ch in normalized if not unicodedata.combining(ch))

    lowered = ascii_text.lower()
    hyphenated = _NON_ALNUM_RE.sub("-", lowered)
    return hyphenated.strip("-")
