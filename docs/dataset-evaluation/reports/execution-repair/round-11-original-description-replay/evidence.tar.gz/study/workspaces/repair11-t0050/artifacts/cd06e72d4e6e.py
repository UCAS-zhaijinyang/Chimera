"""Small calculator module used by the bug-fix fixture.

Bug: ``average`` divided by the number of *values* instead of the number of
*valid* values, so a list containing ``None`` entries produced a wrong result
(and could raise ZeroDivisionError for an all-None list).
"""

from typing import Iterable, Optional


def average(values: Iterable[Optional[float]]) -> float:
    """Return the arithmetic mean of the non-None values.

    Raises ValueError if there are no valid (non-None) values.
    """
    valid = [v for v in values if v is not None]
    if not valid:
        raise ValueError("average() requires at least one non-None value")
    return sum(valid) / len(valid)
