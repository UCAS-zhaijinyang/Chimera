"""Word-frequency counting utility.

Public API:
    word_frequencies(text: str) -> dict[str, int]
"""

from __future__ import annotations

import string

__all__ = ["word_frequencies"]

_EDGE_PUNCTUATION = string.punctuation


def word_frequencies(text: str) -> dict[str, int]:
    """Count word frequencies in ``text``.

    Words are split on whitespace, lowercased, and have leading/trailing
    punctuation stripped. Empty or whitespace-only input yields ``{}``.
    Tokens that become empty after punctuation stripping are ignored.

    Args:
        text: The input text to analyze.

    Returns:
        A mapping of normalized word to its occurrence count.
    """
    if not text or not text.strip():
        return {}

    counts: dict[str, int] = {}
    for token in text.split():
        word = token.strip(_EDGE_PUNCTUATION).lower()
        if not word:
            continue
        counts[word] = counts.get(word, 0) + 1
    return counts
