"""Small Python bug fix (fixture variation 5).

Bug: `average` divided by the length of the input list without guarding
against an empty list, raising ZeroDivisionError instead of returning a
sensible value. It also used integer division semantics implicitly when
summing ints in Python 2 style code paths.

Fix: return 0.0 for an empty sequence and always perform true division.
"""

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Returns ``0.0`` for an empty input instead of raising ZeroDivisionError.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)


if __name__ == "__main__":
    print(average([1, 2, 3, 4]))  # 2.5
    print(average([]))            # 0.0
