# Design: word_frequency utility (textstats)

## Goal
Add `word_frequency(text, top_n=5)` to `src/textstats.py` returning the top-N most
common words with counts.

## Interface
```python
def word_frequency(text: str, top_n: int = 5) -> list[tuple[str, int]]
```
- Returns a list of `(word, count)` tuples sorted by count descending, then
  alphabetically for ties.
- Empty/whitespace input or `top_n <= 0` returns `[]`.

## Behavior
1. Lowercase the input.
2. Tokenize with `re.findall(r"[a-z']+", text.lower())` so punctuation is dropped.
3. Remove stopwords from a small built-in set (the, a, an, and, or, of, to, in, is, it).
4. Count with `collections.Counter`.
5. Return the `top_n` most common items.

## Tests (`tests/test_textstats.py`)
- Basic ranking and counts.
- Case-insensitivity and punctuation stripping.
- Stopword removal.
- Tie-breaking alphabetical order.
- `top_n` limiting, `top_n <= 0`, and empty input.

## Build
Package as a plain module; build step runs `python -m compileall src` and the test
suite via `python -m pytest -q`.

## Risks
- Stopword list is intentionally minimal; documented in the docstring.
- Unicode letters outside `[a-z']` are ignored — acceptable for this small feature.
