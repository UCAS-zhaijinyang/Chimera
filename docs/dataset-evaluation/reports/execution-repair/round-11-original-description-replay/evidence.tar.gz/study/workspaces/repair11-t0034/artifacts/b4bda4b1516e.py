"""Small utility module containing the buggy function under repair.

Bug (fixture variation 3): ``average`` divides by the length of the input
sequence even when the sequence is empty, raising ``ZeroDivisionError``.
The intended behaviour is to return ``0.0`` for an empty sequence.
"""

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` instead of raising ``ZeroDivisionError``.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)
