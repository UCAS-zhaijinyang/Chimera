"""Small text utilities."""

import re

__all__ = ["slugify"]

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(text):
    """Convert arbitrary text into a URL-safe slug.

    The input is lowercased, every maximal run of non-alphanumeric
    characters is replaced by a single hyphen, and leading/trailing
    hyphens are stripped. ``None`` and text without alphanumeric
    characters yield an empty string.
    """
    if text is None:
        return ""
    return _SLUG_RE.sub("-", text.lower()).strip("-")
