"""Small calculator module used by the fixture variation 2 bug fix.

Bug: ``average`` divided by the length of the input list without guarding
against an empty list, raising ``ZeroDivisionError`` instead of returning a
sensible value. The fix returns ``0.0`` for an empty input.
"""

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` rather than raising ``ZeroDivisionError``.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)
