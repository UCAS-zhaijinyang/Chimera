"""Reports package: text analysis utilities."""

from .word_frequency import top_words, word_frequency

__all__ = ["word_frequency", "top_words"]
