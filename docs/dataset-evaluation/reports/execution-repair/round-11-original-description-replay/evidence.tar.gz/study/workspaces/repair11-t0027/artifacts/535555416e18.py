"""Word-frequency counter utility."""

from .counter import word_frequency

__all__ = ["word_frequency"]
__version__ = "0.1.0"
