"""Minimal fix for the reported small Python bug (fixture variation 2).

Bug: an off-by-one error in the inclusive range helper caused the last
element to be dropped when computing a slice end index.

Fix: use the correct inclusive upper bound so the final element is kept.
"""


def inclusive_slice_end(start: int, count: int) -> int:
    """Return the exclusive end index for ``count`` items starting at ``start``.

    Previously this returned ``start + count - 1``, which dropped the last
    element. The correct exclusive end index is ``start + count``.
    """
    if count < 0:
        raise ValueError("count must be non-negative")
    return start + count


def take(items, start: int, count: int):
    """Return ``count`` items from ``items`` beginning at ``start``."""
    return items[start:inclusive_slice_end(start, count)]
