"""Small text statistics utilities.

Currently provides :func:`word_frequency`, a case-insensitive top-N word counter.
"""

from __future__ import annotations

import re
from collections import Counter

__all__ = ["word_frequency", "STOPWORDS"]

#: Minimal built-in stopword set. Intentionally small and documented here so
#: callers know exactly what is filtered out.
STOPWORDS = frozenset(
    {"the", "a", "an", "and", "or", "of", "to", "in", "is", "it"}
)

_TOKEN_RE = re.compile(r"[a-z']+")


def word_frequency(text: str, top_n: int = 5) -> list[tuple[str, int]]:
    """Return the ``top_n`` most common words in ``text`` with their counts.

    Words are lowercased, punctuation is ignored, and the small built-in
    :data:`STOPWORDS` set is removed. Results are sorted by count descending,
    with ties broken alphabetically.

    Args:
        text: Input text to analyze.
        top_n: Maximum number of ``(word, count)`` pairs to return.

    Returns:
        A list of ``(word, count)`` tuples. Empty input or ``top_n <= 0``
        yields an empty list.
    """
    if not text or top_n <= 0:
        return []

    tokens = _TOKEN_RE.findall(text.lower())
    counts = Counter(token for token in tokens if token not in STOPWORDS)

    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ranked[:top_n]
