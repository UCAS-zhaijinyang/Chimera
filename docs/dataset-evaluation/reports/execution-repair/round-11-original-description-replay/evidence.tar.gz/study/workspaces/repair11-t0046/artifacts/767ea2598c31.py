"""Word-frequency counter utility.

Provides :func:`word_frequency` for counting word occurrences in text and a
small CLI entry point that reads text from stdin and prints the counts sorted
by descending frequency (ties broken alphabetically).
"""

from __future__ import annotations

import sys
from typing import Dict, List, Tuple

__all__ = ["word_frequency", "format_counts", "main"]


def _clean_token(token: str) -> str:
    """Strip leading/trailing non-alphanumeric characters and lowercase.

    Unicode letters/digits are preserved; only surrounding punctuation and
    symbols are removed. Returns an empty string if nothing remains.
    """
    start = 0
    end = len(token)
    while start < end and not token[start].isalnum():
        start += 1
    while end > start and not token[end - 1].isalnum():
        end -= 1
    return token[start:end].lower()


def word_frequency(text: str) -> Dict[str, int]:
    """Return a mapping of lowercase words to their occurrence counts.

    Words are split on whitespace. Leading/trailing non-alphanumeric
    characters are stripped from each token. Empty or whitespace-only input
    returns an empty dict. Counting is case-insensitive.
    """
    if not text or not text.strip():
        return {}

    counts: Dict[str, int] = {}
    for raw in text.split():
        word = _clean_token(raw)
        if not word:
            continue
        counts[word] = counts.get(word, 0) + 1
    return counts


def format_counts(counts: Dict[str, int]) -> List[Tuple[str, int]]:
    """Sort counts by descending frequency, then alphabetically for ties."""
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))


def main(argv: List[str] | None = None) -> int:
    """CLI entry point: read stdin, print ``word count`` lines."""
    del argv  # no arguments are used
    text = sys.stdin.read()
    for word, count in format_counts(word_frequency(text)):
        print(f"{word} {count}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
