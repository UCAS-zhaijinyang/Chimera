"""Small Python bug fix — fixture variation 3.

Reported bug
------------
``average`` returned the wrong result for empty input and for inputs
containing non-numeric values, and ``running_total`` mutated the caller's
list. The minimal fix below:

1. ``average`` raises a clear ``ValueError`` on empty input instead of
   dividing by zero.
2. ``average`` validates that every element is numeric.
3. ``running_total`` no longer mutates the caller's list.

These are the only behaviours changed; no new requirements were invented.
"""

from __future__ import annotations

from numbers import Real
from typing import Iterable, List


def average(values: Iterable[Real]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty or contains non-numeric items.
    """
    items: List[Real] = list(values)
    if not items:
        raise ValueError("average() requires at least one value")
    for item in items:
        if isinstance(item, bool) or not isinstance(item, Real):
            raise ValueError(f"average() requires numeric values, got {item!r}")
    return sum(items) / len(items)


def running_total(values: Iterable[Real]) -> List[Real]:
    """Return the running totals of ``values`` without mutating the input."""
    result: List[Real] = []
    total: Real = 0
    for value in values:
        total += value
        result.append(total)
    return result
