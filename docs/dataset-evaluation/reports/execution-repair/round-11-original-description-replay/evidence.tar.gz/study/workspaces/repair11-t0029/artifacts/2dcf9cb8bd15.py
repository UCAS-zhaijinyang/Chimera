"""Small string utility feature (fixture variation 4).

Provides two dependency-free helpers:

* :func:`slugify` -- convert arbitrary text into a URL-friendly slug.
* :func:`truncate` -- shorten text to a maximum length with a suffix.

Behavior is intentionally ASCII-oriented and documented explicitly; no
requirements beyond the source issue are assumed.
"""

from __future__ import annotations

import re

__all__ = ["slugify", "truncate"]

_NON_ALNUM_RUN = re.compile(r"[^a-z0-9]+")


def slugify(text: str) -> str:
    """Return a lowercase, hyphen-separated slug for ``text``.

    Any run of characters that is not an ASCII letter or digit is replaced
    by a single hyphen. Leading and trailing hyphens are stripped. Input
    that contains no alphanumeric characters yields ``""``.

    >>> slugify("Hello, World!")
    'hello-world'
    >>> slugify("  --Already  Slugged--  ")
    'already-slugged'
    >>> slugify("!!!")
    ''
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    lowered = text.lower()
    slug = _NON_ALNUM_RUN.sub("-", lowered)
    return slug.strip("-")


def truncate(text: str, max_length: int, suffix: str = "...") -> str:
    """Shorten ``text`` to at most ``max_length`` characters.

    If ``text`` already fits, it is returned unchanged. Otherwise the result
    is ``text[: max_length - len(suffix)] + suffix``.

    Raises:
        ValueError: if ``max_length`` is smaller than ``len(suffix)``.
        TypeError: if ``text`` or ``suffix`` is not a ``str``.

    >>> truncate("hello", 10)
    'hello'
    >>> truncate("hello world", 8)
    'hello...'
    >>> truncate("hello world", 8, "…")
    'hello w…'
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    if not isinstance(suffix, str):
        raise TypeError("suffix must be a str")
    if max_length < len(suffix):
        raise ValueError("max_length must be >= len(suffix)")
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix
