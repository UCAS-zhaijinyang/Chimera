"""Word-frequency summary utility.

Pure-stdlib helpers for summarizing word frequencies in a block of text.
"""

from __future__ import annotations

import string
from collections import Counter

__all__ = ["word_frequency", "top_words"]

_PUNCTUATION = string.punctuation


def word_frequency(text: str | None) -> dict[str, int]:
    """Return a mapping of lowercase word -> count for ``text``.

    Words are split on whitespace and stripped of surrounding punctuation.
    Tokens that are empty after stripping are ignored. ``None`` or
    empty/whitespace-only input yields an empty dict.
    """
    if not text:
        return {}

    counts: Counter[str] = Counter()
    for token in text.split():
        word = token.strip(_PUNCTUATION).lower()
        if word:
            counts[word] += 1
    return dict(counts)


def top_words(text: str | None, n: int = 5) -> list[tuple[str, int]]:
    """Return the ``n`` most common words as ``(word, count)`` tuples.

    Ordering is by count descending, then word ascending for ties.
    ``n <= 0`` returns an empty list; ``n`` larger than the vocabulary
    returns every word.
    """
    if n <= 0:
        return []

    counts = word_frequency(text)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]
