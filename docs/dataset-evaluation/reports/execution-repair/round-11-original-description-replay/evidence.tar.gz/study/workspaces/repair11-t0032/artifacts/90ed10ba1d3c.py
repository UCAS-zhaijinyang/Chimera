"""Small arithmetic helpers used by the reporting pipeline.

Bug (fixture variation 1): ``average`` divided by the length of the raw
input instead of the number of values actually summed, so any input
containing ``None`` entries produced a wrong (too small) result.  The fix
filters out ``None`` values first and guards against an empty sequence.
"""

from __future__ import annotations

from typing import Iterable, Optional


def average(values: Iterable[Optional[float]]) -> float:
    """Return the arithmetic mean of the non-``None`` values.

    ``None`` entries are ignored (they represent missing measurements).
    Raises ``ValueError`` when there is nothing to average.
    """
    numbers = [v for v in values if v is not None]
    if not numbers:
        raise ValueError("average() requires at least one non-None value")
    return sum(numbers) / len(numbers)


def total(values: Iterable[Optional[float]]) -> float:
    """Return the sum of the non-``None`` values."""
    return sum(v for v in values if v is not None)
