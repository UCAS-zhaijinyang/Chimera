"""String utility helpers."""

import re

__all__ = ["slugify"]

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def slugify(text: str) -> str:
    """Convert ``text`` into a URL-friendly slug.

    The input is lowercased, every maximal run of non-alphanumeric
    characters is replaced by a single hyphen, and leading/trailing
    hyphens are stripped. Inputs without any alphanumeric characters
    produce an empty string.

    Raises:
        TypeError: if ``text`` is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError("slugify() expects a str")
    return _SLUG_RE.sub("-", text.lower()).strip("-")
