"""Reports package: small text/reporting utilities."""

from .word_frequency import format_counts, word_frequency

__all__ = ["word_frequency", "format_counts"]
