"""Small calculator module used by the fixture variation 1 bug fix.

Bug: ``average`` divided by the raw length of the input list, so an empty
input raised ``ZeroDivisionError`` instead of returning a defined value.
The fix guards the empty case and returns ``0.0``.
"""

from __future__ import annotations

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` rather than raising ``ZeroDivisionError``.
    """
    numbers = list(values)
    if not numbers:
        return 0.0
    return sum(numbers) / len(numbers)


def add(a: float, b: float) -> float:
    """Return the sum of ``a`` and ``b``."""
    return a + b
