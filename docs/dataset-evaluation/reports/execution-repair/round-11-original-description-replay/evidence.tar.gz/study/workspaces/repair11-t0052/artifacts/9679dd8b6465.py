"""Small calculator helpers used by the fixture variation 3 bug fix."""


def add(a, b):
    """Return the sum of two numbers."""
    return a + b


def divide(a, b):
    """Return a / b.

    Bug: the original implementation used integer division (``//``), so
    ``divide(7, 2)`` returned ``3`` instead of ``3.5``. Fixed by using true
    division.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b


def average(values):
    """Return the arithmetic mean of a non-empty sequence of numbers."""
    if not values:
        raise ValueError("average() requires at least one value")
    return divide(sum(values), len(values))
