"""String normalization utilities.

This module provides a single, dependency-free helper for normalizing
arbitrary text: surrounding whitespace is stripped, internal whitespace
runs are collapsed to a single space, and the result is lowercased.
"""

from __future__ import annotations

__all__ = ["normalize"]


def normalize(text: str) -> str:
    """Return a normalized copy of *text*.

    Normalization steps:

    1. Strip leading and trailing whitespace.
    2. Collapse internal runs of whitespace into a single space.
    3. Lowercase the result.

    Args:
        text: The string to normalize.

    Returns:
        The normalized string. Whitespace-only input yields ``""``.

    Raises:
        TypeError: If *text* is not a ``str``.

    Examples:
        >>> normalize("  Hello   World  ")
        'hello world'
        >>> normalize("a\\t\\tb\\n c")
        'a b c'
        >>> normalize("   \\t\\n ")
        ''
    """
    if not isinstance(text, str):
        raise TypeError(
            f"normalize() expected str, got {type(text).__name__}"
        )

    # ``str.split()`` with no arguments splits on arbitrary whitespace runs
    # and discards empty tokens, which handles tabs, newlines and other
    # Unicode whitespace uniformly.
    return " ".join(text.split()).lower()
