"""Word-frequency counter utility.

Dependency-free (standard library only). Provides:

- ``word_frequencies(text)`` -> mapping of lowercase words to counts
- ``top_words(text, n)`` -> the ``n`` most common words
- ``main(argv)`` -> small CLI entry point

Usage:
    python -m wordfreq <path> [--top N]
"""

from __future__ import annotations

import string
import sys
from collections import Counter

__all__ = ["word_frequencies", "top_words", "main"]

_PUNCTUATION = string.punctuation


def word_frequencies(text: str) -> dict[str, int]:
    """Return a mapping of lowercase words to their occurrence counts.

    Words are split on whitespace and surrounding punctuation is stripped.
    Tokens that are empty after stripping are ignored. Empty or
    whitespace-only input returns an empty dict.
    """
    if not text or not text.strip():
        return {}

    counts: Counter[str] = Counter()
    for token in text.split():
        word = token.strip(_PUNCTUATION).lower()
        if word:
            counts[word] += 1
    return dict(counts)


def top_words(text: str, n: int = 10) -> list[tuple[str, int]]:
    """Return the ``n`` most common words as ``(word, count)`` pairs.

    Sorted by count descending, then alphabetically ascending for ties.
    ``n <= 0`` yields an empty list.
    """
    if n <= 0:
        return []
    counts = word_frequencies(text)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def main(argv: list[str] | None = None) -> int:
    """CLI entry point: print top words for a text file.

    Returns 0 on success, 2 on usage or I/O error.
    """
    args = list(sys.argv[1:] if argv is None else argv)

    top_n = 10
    if "--top" in args:
        idx = args.index("--top")
        try:
            top_n = int(args[idx + 1])
        except (IndexError, ValueError):
            print("error: --top requires an integer value", file=sys.stderr)
            return 2
        del args[idx : idx + 2]

    if len(args) != 1:
        print("usage: python -m wordfreq <path> [--top N]", file=sys.stderr)
        return 2

    path = args[0]
    try:
        with open(path, "r", encoding="utf-8") as handle:
            text = handle.read()
    except OSError as exc:
        print(f"error: cannot read {path!r}: {exc}", file=sys.stderr)
        return 2

    for word, count in top_words(text, top_n):
        print(f"{word}\t{count}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
