"""Small text utility helpers."""

import re

__all__ = ["normalize_whitespace"]

_WHITESPACE_RE = re.compile(r"\s+")


def normalize_whitespace(text: str) -> str:
    """Collapse all runs of whitespace into single spaces and strip the ends.

    Args:
        text: The input string to normalize.

    Returns:
        The normalized string with internal whitespace runs collapsed to a
        single space and leading/trailing whitespace removed.

    Raises:
        TypeError: If ``text`` is not a string.
    """
    if not isinstance(text, str):
        raise TypeError(f"expected str, got {type(text).__name__}")
    return _WHITESPACE_RE.sub(" ", text).strip()
