"""Small calculator module used by the bug-fix fixture (variation 4).

Bug: ``average`` divided by the length of the input list without guarding
against an empty list, raising ``ZeroDivisionError`` instead of returning a
sensible value. It also used integer division semantics implicitly for
integer inputs in older Python versions.
"""

from __future__ import annotations

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Returns ``0.0`` for an empty input instead of raising
    ``ZeroDivisionError``.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)


def add(a: float, b: float) -> float:
    """Return the sum of ``a`` and ``b``."""
    return a + b
