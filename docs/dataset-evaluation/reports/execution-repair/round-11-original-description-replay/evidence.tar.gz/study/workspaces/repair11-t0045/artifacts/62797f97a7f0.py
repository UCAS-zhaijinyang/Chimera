"""URL-safe slug generation utility.

See design: slugify(text, separator="-") lowercases, strips accents,
collapses non-alphanumeric runs into the separator, and trims separators.
"""

from __future__ import annotations

import re
import unicodedata

__all__ = ["slugify"]

_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def _strip_accents(text: str) -> str:
    """Return *text* with combining marks removed (NFKD decomposition)."""
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch))


def slugify(text: str, separator: str = "-") -> str:
    """Convert *text* into a URL-safe slug.

    Args:
        text: The source string. Must be a ``str``.
        separator: String inserted between words. Defaults to ``"-"``.

    Returns:
        A lowercase slug containing only ``[a-z0-9]`` and *separator*.
        Returns ``""`` when no alphanumeric characters remain.

    Raises:
        TypeError: If *text* is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")

    normalized = _strip_accents(text).lower()
    slug = _NON_ALNUM.sub(separator, normalized)
    return slug.strip(separator)
