"""Small Python bug fix fixture (variation 0).

Bug: `average` divided by the length of the input list without guarding
against an empty list, raising ZeroDivisionError instead of returning a
sensible value. It also used integer division semantics implicitly when
given ints in Python 2 style code paths.

Fix: return 0.0 for an empty sequence and use true division so the result
is always a float.
"""

from __future__ import annotations

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` rather than raising ``ZeroDivisionError``.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)


if __name__ == "__main__":  # pragma: no cover - manual smoke check
    print(average([1, 2, 3]))
    print(average([]))
