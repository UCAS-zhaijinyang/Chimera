"""Fixture variation 5: small Python bug fix.

Bug: `average` divides by the length of the *input* sequence instead of the
number of values actually summed, so it raises ZeroDivisionError on an empty
input and returns a wrong result when values are filtered out.

Fix: count the values that are actually summed and guard against a zero count.
"""

from __future__ import annotations

from typing import Iterable, Optional


def average(values: Iterable[float], ignore_none: bool = True) -> Optional[float]:
    """Return the arithmetic mean of ``values``.

    ``None`` entries are skipped when ``ignore_none`` is true. Returns ``None``
    when there is nothing to average instead of raising ``ZeroDivisionError``.
    """
    total = 0.0
    count = 0
    for value in values:
        if value is None:
            if ignore_none:
                continue
            raise TypeError("None value encountered while ignore_none=False")
        total += value
        count += 1

    if count == 0:
        return None
    return total / count
