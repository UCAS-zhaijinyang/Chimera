"""Small arithmetic helpers used by the reporting layer.

Bug (fixture variation 5): ``average`` raised ``ZeroDivisionError`` for an
empty input sequence instead of returning a defined value, and it also
silently truncated integer division results.
"""

from __future__ import annotations

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` rather than raising ``ZeroDivisionError``.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)


def total(values: Iterable[float]) -> float:
    """Return the sum of ``values`` (0 for an empty input)."""
    return sum(values)
