"""Small calculator module used by the fixture workflow.

Bug (fixture variation 0): ``average`` divided by the number of *items*
instead of the number of *valid* items, so a list containing ``None``
entries produced a wrong result (and could raise ZeroDivisionError when
every entry was ``None``).
"""

from typing import Iterable, Optional


def average(values: Iterable[Optional[float]]) -> float:
    """Return the mean of the non-``None`` values.

    Raises ``ValueError`` if there are no valid values.
    """
    valid = [v for v in values if v is not None]
    if not valid:
        raise ValueError("average() requires at least one non-None value")
    return sum(valid) / len(valid)
