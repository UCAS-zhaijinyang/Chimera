"""Word-frequency summary utility for the reports module.

Implements :func:`word_frequency`, which returns the most common words in a
piece of text, case-insensitively, ignoring punctuation and stopwords.
"""

from __future__ import annotations

import re
from collections import Counter

__all__ = ["word_frequency", "STOPWORDS", "tokenize"]

#: Common English stopwords excluded from frequency counts.
STOPWORDS = frozenset(
    {
        "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "from",
        "had", "has", "have", "he", "her", "his", "i", "in", "is", "it", "its",
        "me", "my", "no", "not", "of", "on", "or", "our", "she", "so", "that",
        "the", "their", "them", "then", "there", "these", "they", "this", "to",
        "was", "we", "were", "what", "when", "which", "who", "will", "with",
        "you", "your",
    }
)

_TOKEN_RE = re.compile(r"[a-z0-9']+")


def tokenize(text: str) -> list[str]:
    """Lowercase ``text`` and split it into word tokens, dropping punctuation."""
    return _TOKEN_RE.findall(text.lower())


def word_frequency(text: str, top_n: int = 5) -> list[tuple[str, int]]:
    """Return the ``top_n`` most common words in ``text``.

    Counting is case-insensitive and ignores punctuation and stopwords.
    Results are ordered by descending count, then alphabetically for ties.

    Args:
        text: The text to analyze.
        top_n: Maximum number of ``(word, count)`` pairs to return.

    Returns:
        A list of ``(word, count)`` tuples. Empty when ``text`` has no
        countable words or when ``top_n <= 0``.
    """
    if top_n <= 0:
        return []

    counts = Counter(
        token for token in tokenize(text) if token not in STOPWORDS
    )
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ranked[:top_n]
