"""Restricted numeric helpers."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values. The numeric type of the
    winning argument is preserved.

    Examples:
        >>> compute(2, 3)
        3
        >>> compute(-1, -5)
        -1
        >>> compute(1.5, 1.25)
        1.5
    """
    return a if a >= b else b
