"""Core module for the compute feature."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports zero, negative, and fractional values.
    Example: compute(2, 3) == 2
    """
    return min(a, b)
