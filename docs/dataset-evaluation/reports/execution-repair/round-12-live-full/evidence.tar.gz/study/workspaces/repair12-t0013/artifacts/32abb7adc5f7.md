# Design: compute(a, b) product feature

## Goal
Define `compute(a, b)` in `src/main.py` that returns the product of two finite numeric inputs.

## Requirements
- `compute(2, 3)` returns `6`.
- Support zero, negative, and fractional values.
- Inputs are finite numeric values (int/float).

## Interface
```python
def compute(a, b):
    """Return the product of two finite numeric inputs."""
    return a * b
```

## Behavior
- Zero: `compute(0, 5) == 0`, `compute(0, 0) == 0`.
- Negative: `compute(-2, 3) == -6`, `compute(-2, -3) == 6`.
- Fractional: `compute(0.5, 4) == 2.0`, `compute(1.5, 2) == 3.0`.
- Example: `compute(2, 3) == 6`.

## Verification
1. Behavioral check: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
2. Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Files
- `src/main.py` — implementation.
