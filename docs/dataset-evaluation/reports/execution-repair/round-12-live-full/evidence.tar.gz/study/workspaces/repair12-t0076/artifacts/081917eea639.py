"""Arithmetic helpers."""

import math


def _validate(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a finite numeric value")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Examples:
        compute(2, 3) == 2.5
        compute(0, 0) == 0.0
        compute(-1, 1) == 0.0
        compute(0.5, 1.5) == 1.0
    """
    _validate(a, "a")
    _validate(b, "b")
    return (a + b) / 2
