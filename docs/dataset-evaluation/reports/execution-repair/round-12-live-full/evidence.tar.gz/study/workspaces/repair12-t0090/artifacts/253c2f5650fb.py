"""Restricted numeric helpers."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError("compute() requires numeric inputs")
    if isinstance(a, bool) or isinstance(b, bool):
        raise TypeError("compute() requires numeric inputs")
    if a != a or b != b:
        raise ValueError("compute() requires finite numeric inputs")
    if a in (float("inf"), float("-inf")) or b in (float("inf"), float("-inf")):
        raise ValueError("compute() requires finite numeric inputs")
    return a if a >= b else b
