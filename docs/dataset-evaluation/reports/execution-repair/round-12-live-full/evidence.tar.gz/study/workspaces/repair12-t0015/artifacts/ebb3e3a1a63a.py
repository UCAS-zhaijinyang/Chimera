"""Core module for the minimum-of-two feature."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        2
        >>> compute(-5, -2)
        -5
        >>> compute(1.5, 0.5)
        0.5
    """
    return min(a, b)
