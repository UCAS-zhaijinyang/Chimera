"""Main module for the arithmetic mean feature."""


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Supports zero, negative and fractional values.
    Example: compute(2, 3) == 2.5
    """
    return (a + b) / 2
