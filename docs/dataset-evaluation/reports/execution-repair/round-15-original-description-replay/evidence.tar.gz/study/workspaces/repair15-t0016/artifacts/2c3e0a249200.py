"""Pagination helpers."""


def page_count(total, per_page):
    """Return the number of pages needed to hold ``total`` items.

    Uses ceiling division so that a total which is an exact multiple of
    ``per_page`` yields exactly ``total // per_page`` pages.
    """
    if per_page <= 0:
        raise ValueError("per_page must be positive")
    if total <= 0:
        return 0
    return (total + per_page - 1) // per_page
