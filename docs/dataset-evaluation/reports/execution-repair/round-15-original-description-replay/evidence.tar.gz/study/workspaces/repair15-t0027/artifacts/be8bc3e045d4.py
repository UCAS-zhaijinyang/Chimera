"""textstats: small pure-standard-library text statistics utility.

Public API:
    summarize(text: str) -> dict

Semantics:
    - chars: len(text)
    - words: number of whitespace-separated tokens (text.split())
    - lines: number of lines (len(text.splitlines()))
    - unique_words: number of distinct lowercased whitespace-separated tokens

Punctuation is NOT stripped; tokens are defined purely by whitespace.
"""

from __future__ import annotations

__all__ = ["summarize"]


def summarize(text: str) -> dict:
    """Return basic statistics for ``text``.

    Empty input yields all-zero counts. Raises TypeError for non-str input.
    """
    if not isinstance(text, str):
        raise TypeError(f"summarize() expects str, got {type(text).__name__}")

    tokens = text.split()
    return {
        "chars": len(text),
        "words": len(tokens),
        "lines": len(text.splitlines()),
        "unique_words": len({token.lower() for token in tokens}),
    }
