"""Regression tests for the pagination helper."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pagination import paginate  # noqa: E402


def test_exact_multiple_has_no_trailing_empty_page():
    # Regression: 20 items with page_size 10 must be 2 pages, not 3.
    assert paginate(total=20, page_size=10) == 2


def test_partial_last_page_rounds_up():
    assert paginate(total=21, page_size=10) == 3


def test_single_item():
    assert paginate(total=1, page_size=10) == 1


def test_zero_items_yields_zero_pages():
    assert paginate(total=0, page_size=10) == 0


def test_page_size_larger_than_total():
    assert paginate(total=3, page_size=10) == 1


def test_negative_total_rejected():
    with pytest.raises(ValueError):
        paginate(total=-1, page_size=10)


def test_non_positive_page_size_rejected():
    with pytest.raises(ValueError):
        paginate(total=10, page_size=0)
