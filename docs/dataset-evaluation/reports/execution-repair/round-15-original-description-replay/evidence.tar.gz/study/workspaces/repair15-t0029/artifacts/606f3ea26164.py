"""Unit tests for src/stats_utils.py (fixture variation 4)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stats_utils import clamp, mean, median, mode  # noqa: E402


class MeanTests(unittest.TestCase):
    def test_mean_basic(self):
        self.assertEqual(mean([1, 2, 3, 4]), 2.5)

    def test_mean_single(self):
        self.assertEqual(mean([7]), 7)

    def test_mean_floats(self):
        self.assertAlmostEqual(mean([0.5, 1.5]), 1.0)

    def test_mean_empty_raises(self):
        with self.assertRaises(ValueError):
            mean([])


class MedianTests(unittest.TestCase):
    def test_median_odd(self):
        self.assertEqual(median([3, 1, 2]), 2)

    def test_median_even(self):
        self.assertEqual(median([1, 2, 3, 4]), 2.5)

    def test_median_single(self):
        self.assertEqual(median([9]), 9)

    def test_median_unsorted(self):
        self.assertEqual(median([5, 1, 4, 2, 3]), 3)

    def test_median_empty_raises(self):
        with self.assertRaises(ValueError):
            median([])


class ModeTests(unittest.TestCase):
    def test_mode_basic(self):
        self.assertEqual(mode([1, 2, 2, 3]), 2)

    def test_mode_tie_smallest(self):
        self.assertEqual(mode([3, 3, 1, 1, 2]), 1)

    def test_mode_single(self):
        self.assertEqual(mode([4]), 4)

    def test_mode_all_unique(self):
        self.assertEqual(mode([5, 4, 3]), 3)

    def test_mode_empty_raises(self):
        with self.assertRaises(ValueError):
            mode([])


class ClampTests(unittest.TestCase):
    def test_clamp_below(self):
        self.assertEqual(clamp(-5, 0, 10), 0)

    def test_clamp_above(self):
        self.assertEqual(clamp(15, 0, 10), 10)

    def test_clamp_inside(self):
        self.assertEqual(clamp(5, 0, 10), 5)

    def test_clamp_boundaries(self):
        self.assertEqual(clamp(0, 0, 10), 0)
        self.assertEqual(clamp(10, 0, 10), 10)

    def test_clamp_invalid_range_raises(self):
        with self.assertRaises(ValueError):
            clamp(5, 10, 0)


if __name__ == "__main__":
    unittest.main()
