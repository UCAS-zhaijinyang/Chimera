"""URL-friendly slug generation.

Small, self-contained string utility using only the standard library.
"""

import re
import unicodedata

__all__ = ["slugify"]

_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def slugify(text: str) -> str:
    """Convert arbitrary text into a URL-friendly slug.

    Steps:
      1. Return "" for empty or whitespace-only input.
      2. Unicode-normalize (NFKD) and drop non-ASCII characters (ASCII fallback).
      3. Lowercase.
      4. Collapse runs of non-alphanumeric characters into a single hyphen.
      5. Trim leading/trailing hyphens.

    Args:
        text: Any string.

    Returns:
        A lowercase, hyphen-separated slug (possibly empty).
    """
    if not text or not text.strip():
        return ""

    normalized = unicodedata.normalize("NFKD", text)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    lowered = ascii_text.lower()
    hyphenated = _NON_ALNUM.sub("-", lowered)
    return hyphenated.strip("-")
