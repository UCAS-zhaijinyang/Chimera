"""Small text statistics utility (fixture variation 5).

Public API:
    word_count(text) -> int
    char_count(text, ignore_whitespace=False) -> int
    top_words(text, n=3) -> list[tuple[str, int]]
    summarize(text) -> dict
"""

from __future__ import annotations

from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]

_PUNCT = ".,!?;:\"'()[]{}<>«»…-—–_/\\|@#$%^&*+=~`"


def _require_str(text: str) -> str:
    if not isinstance(text, str):
        raise TypeError(f"expected str, got {type(text).__name__}")
    return text


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in *text*."""
    _require_str(text)
    return len(text.split())


def char_count(text: str, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in *text*.

    If *ignore_whitespace* is True, whitespace characters are excluded.
    """
    _require_str(text)
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def _normalize(token: str) -> str:
    return token.strip(_PUNCT).lower()


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the *n* most frequent words as ``(word, count)`` pairs.

    Words are lowercased and stripped of surrounding punctuation. Results are
    sorted by descending count, then alphabetically for deterministic ties.
    """
    _require_str(text)
    if n <= 0:
        return []
    tokens = [_normalize(tok) for tok in text.split()]
    tokens = [tok for tok in tokens if tok]
    counts = Counter(tokens)
    ordered = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return an aggregate summary dict for *text*."""
    _require_str(text)
    return {
        "words": word_count(text),
        "chars": char_count(text),
        "chars_no_ws": char_count(text, ignore_whitespace=True),
        "top": top_words(text),
    }
