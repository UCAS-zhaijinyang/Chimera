"""Build step: byte-compile src/ and tests/ to validate syntax.

Usage:
    python build.py

Exits non-zero if compilation fails.
"""

import compileall
import sys


def main() -> int:
    targets = ["src", "tests"]
    ok = True
    for target in targets:
        print(f"[build] compiling {target}/ ...")
        if not compileall.compile_dir(target, quiet=1, force=True):
            ok = False
            print(f"[build] FAILED: {target}/")
        else:
            print(f"[build] OK: {target}/")
    if ok:
        print("[build] SUCCESS")
        return 0
    print("[build] FAILURE")
    return 1


if __name__ == "__main__":
    sys.exit(main())
