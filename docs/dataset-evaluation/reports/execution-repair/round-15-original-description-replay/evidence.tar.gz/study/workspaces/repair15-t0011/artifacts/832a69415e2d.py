"""Small text statistics utilities.

Public API:
    word_count(text) -> int
    char_frequency(text) -> dict[str, int]
    top_words(text, n=3) -> list[tuple[str, int]]

All functions are pure and dependency-free.
"""

from __future__ import annotations

from collections import Counter

__all__ = ["word_count", "char_frequency", "top_words"]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    An empty or whitespace-only string yields ``0``.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return len(text.split())


def char_frequency(text: str) -> dict[str, int]:
    """Return frequency of alphanumeric characters, lowercased.

    Non-alphanumeric characters (spaces, punctuation, symbols) are ignored.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    counts: Counter[str] = Counter()
    for ch in text:
        if ch.isalnum():
            counts[ch.lower()] += 1
    return dict(counts)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most common words as ``(word, count)`` pairs.

    Words are whitespace-separated tokens, lowercased. Ties are broken
    alphabetically. ``n <= 0`` returns an empty list.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    if n <= 0:
        return []
    counts = Counter(token.lower() for token in text.split())
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]
