import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pagination import page_count


def test_exact_multiple():
    assert page_count(20, 10) == 2


def test_remainder():
    assert page_count(21, 10) == 3


def test_single_page():
    assert page_count(5, 10) == 1


def test_empty():
    assert page_count(0, 10) == 0


def test_invalid_per_page():
    try:
        page_count(10, 0)
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError for per_page <= 0")


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print("ok", name)
    print("all tests passed")
