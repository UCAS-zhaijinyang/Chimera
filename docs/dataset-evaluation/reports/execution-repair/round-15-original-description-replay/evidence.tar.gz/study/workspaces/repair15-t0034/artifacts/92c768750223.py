"""Pagination helpers."""

from __future__ import annotations


def total_pages(total_items: int, page_size: int) -> int:
    """Return the number of pages needed to hold ``total_items`` items.

    Uses ceiling division so that an exact multiple of ``page_size`` does not
    produce a trailing empty page.
    """
    if page_size <= 0:
        raise ValueError("page_size must be positive")
    if total_items <= 0:
        return 0
    return (total_items + page_size - 1) // page_size
