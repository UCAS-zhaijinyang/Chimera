"""Unit tests for src/textstats.py (fixture variation 5)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_basic(self):
        self.assertEqual(word_count("hello world"), 2)

    def test_empty(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n  "), 0)

    def test_extra_spaces(self):
        self.assertEqual(word_count("  a   b  c "), 3)


class CharCountTests(unittest.TestCase):
    def test_includes_whitespace(self):
        self.assertEqual(char_count("a b"), 3)

    def test_ignore_whitespace(self):
        self.assertEqual(char_count("a b\nc", ignore_whitespace=True), 3)

    def test_empty(self):
        self.assertEqual(char_count(""), 0)
        self.assertEqual(char_count("", ignore_whitespace=True), 0)


class TopWordsTests(unittest.TestCase):
    def test_frequency_order(self):
        text = "the cat the dog the bird cat"
        self.assertEqual(top_words(text, 2), [("the", 3), ("cat", 2)])

    def test_case_insensitive(self):
        self.assertEqual(top_words("Go go GO stop", 1), [("go", 3)])

    def test_punctuation_stripped(self):
        self.assertEqual(top_words("hi, hi! hi.", 1), [("hi", 3)])

    def test_tie_break_alphabetical(self):
        self.assertEqual(top_words("b a c", 3), [("a", 1), ("b", 1), ("c", 1)])

    def test_n_bounds(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -5), [])

    def test_n_larger_than_unique(self):
        self.assertEqual(top_words("a a b", 10), [("a", 2), ("b", 1)])

    def test_empty(self):
        self.assertEqual(top_words(""), [])


class SummarizeTests(unittest.TestCase):
    def test_summary_keys_and_values(self):
        result = summarize("one two two")
        self.assertEqual(result["words"], 3)
        self.assertEqual(result["chars"], 11)
        self.assertEqual(result["chars_no_ws"], 9)
        self.assertEqual(result["top_words"], [("two", 2), ("one", 1)])

    def test_empty_summary(self):
        result = summarize("")
        self.assertEqual(
            result,
            {"words": 0, "chars": 0, "chars_no_ws": 0, "top_words": []},
        )


if __name__ == "__main__":
    unittest.main()
