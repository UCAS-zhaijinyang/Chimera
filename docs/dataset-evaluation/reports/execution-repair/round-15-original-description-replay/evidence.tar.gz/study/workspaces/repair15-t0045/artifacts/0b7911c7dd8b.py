"""Unit tests for the textstats module."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import summarize  # noqa: E402


class SummarizeTests(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(
            summarize(""),
            {"chars": 0, "words": 0, "lines": 0, "unique_words": 0},
        )

    def test_single_line(self):
        self.assertEqual(
            summarize("hello world"),
            {"chars": 11, "words": 2, "lines": 1, "unique_words": 2},
        )

    def test_multi_line(self):
        result = summarize("a\nb\nc")
        self.assertEqual(result["lines"], 3)
        self.assertEqual(result["words"], 3)
        self.assertEqual(result["unique_words"], 3)

    def test_case_insensitive_uniqueness(self):
        result = summarize("The the THE")
        self.assertEqual(result["words"], 3)
        self.assertEqual(result["unique_words"], 1)

    def test_whitespace_only(self):
        result = summarize("   ")
        self.assertEqual(result["chars"], 3)
        self.assertEqual(result["words"], 0)
        self.assertEqual(result["lines"], 0)
        self.assertEqual(result["unique_words"], 0)

    def test_punctuation_kept_as_token(self):
        result = summarize("Hello, hello!")
        self.assertEqual(result["words"], 2)
        self.assertEqual(result["unique_words"], 2)

    def test_type_error(self):
        with self.assertRaises(TypeError):
            summarize(123)


if __name__ == "__main__":
    unittest.main()
