"""Unit tests for src.slugify.slugify."""

import unittest

from src.slugify import slugify


class TestSlugify(unittest.TestCase):
    def test_basic_phrase(self):
        self.assertEqual(slugify("Hello World"), "hello-world")

    def test_punctuation(self):
        self.assertEqual(slugify("Hello, World!"), "hello-world")

    def test_accents(self):
        self.assertEqual(slugify("Café Crème"), "cafe-creme")

    def test_multiple_separators(self):
        self.assertEqual(slugify("a   b---c"), "a-b-c")

    def test_leading_and_trailing_separators(self):
        self.assertEqual(slugify("  --Hello--  "), "hello")

    def test_empty_input(self):
        self.assertEqual(slugify(""), "")

    def test_whitespace_only(self):
        self.assertEqual(slugify("   \t\n"), "")

    def test_unicode_edge_case(self):
        self.assertEqual(slugify("Ünïcödé Ñoñó"), "unicode-nono")

    def test_digits_preserved(self):
        self.assertEqual(slugify("Version 2.0 Release"), "version-2-0-release")

    def test_symbols_only(self):
        self.assertEqual(slugify("!!!???"), "")

    def test_mixed_case_and_underscores(self):
        self.assertEqual(slugify("Foo_Bar Baz"), "foo-bar-baz")


if __name__ == "__main__":
    unittest.main()
