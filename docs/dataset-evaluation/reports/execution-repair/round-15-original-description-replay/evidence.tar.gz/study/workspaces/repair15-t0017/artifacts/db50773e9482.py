"""Tests for src/calculator.py (fixture variation 4)."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from calculator import add, average  # noqa: E402


def test_add():
    assert add(2, 3) == 5
    assert add(0.5, 0.25) == 0.75


def test_average_returns_true_division_for_ints():
    # Regression: previously returned 1 (integer division) instead of 1.5.
    assert average([1, 2]) == 1.5


def test_average_floats():
    assert average([1.0, 2.0, 3.0]) == 2.0


def test_average_single_value():
    assert average([7]) == 7


def test_average_accepts_generator():
    assert average(x for x in [2, 4, 6]) == 4.0


def test_average_empty_raises():
    with pytest.raises(ValueError):
        average([])
