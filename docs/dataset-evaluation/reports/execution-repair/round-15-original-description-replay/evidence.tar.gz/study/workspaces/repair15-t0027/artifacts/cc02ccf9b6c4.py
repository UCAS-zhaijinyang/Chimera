"""Unit tests for textstats.summarize."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import summarize  # noqa: E402


class TestSummarize(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(
            summarize(""),
            {"chars": 0, "words": 0, "lines": 0, "unique_words": 0},
        )

    def test_single_line(self):
        self.assertEqual(
            summarize("hello world"),
            {"chars": 11, "words": 2, "lines": 1, "unique_words": 2},
        )

    def test_multi_line(self):
        self.assertEqual(
            summarize("a\nb\nc"),
            {"chars": 5, "words": 3, "lines": 3, "unique_words": 3},
        )

    def test_case_insensitive_uniqueness(self):
        result = summarize("The the THE")
        self.assertEqual(result["words"], 3)
        self.assertEqual(result["unique_words"], 1)

    def test_punctuation_not_stripped(self):
        result = summarize("hi, hi!")
        self.assertEqual(result["words"], 2)
        self.assertEqual(result["unique_words"], 2)

    def test_whitespace_only(self):
        result = summarize("   \n  ")
        self.assertEqual(result["words"], 0)
        self.assertEqual(result["unique_words"], 0)
        self.assertEqual(result["chars"], 6)

    def test_non_string_raises(self):
        with self.assertRaises(TypeError):
            summarize(123)


if __name__ == "__main__":
    unittest.main()
