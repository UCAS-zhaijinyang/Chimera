"""Small statistics helpers used by the reporting pipeline."""


def mean(values):
    """Return the arithmetic mean of a non-empty sequence of numbers."""
    if not values:
        raise ValueError("mean() requires at least one value")
    return sum(values) / len(values)


def median(values):
    """Return the median of a non-empty sequence of numbers.

    For an even number of values the median is the average of the two
    middle values.
    """
    if not values:
        raise ValueError("median() requires at least one value")
    ordered = sorted(values)
    n = len(ordered)
    mid = n // 2
    if n % 2 == 1:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2


def variance(values):
    """Return the population variance of a non-empty sequence."""
    if not values:
        raise ValueError("variance() requires at least one value")
    m = mean(values)
    return sum((v - m) ** 2 for v in values) / len(values)


def percentile(values, pct):
    """Return the pct-th percentile (0-100) using linear interpolation.

    Bug fixed: the previous implementation indexed the ordered list with
    ``int(pct / 100 * n)``, which returned the wrong element for many
    inputs and raised IndexError when pct == 100.
    """
    if not values:
        raise ValueError("percentile() requires at least one value")
    if not 0 <= pct <= 100:
        raise ValueError("pct must be between 0 and 100")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    rank = (pct / 100) * (len(ordered) - 1)
    lower = int(rank)
    upper = min(lower + 1, len(ordered) - 1)
    frac = rank - lower
    return ordered[lower] + (ordered[upper] - ordered[lower]) * frac
