"""Unit tests for src.slugify.slugify (fixture variation 1)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.slugify import slugify  # noqa: E402


class TestSlugify(unittest.TestCase):
    def test_basic_phrase(self):
        self.assertEqual(slugify("Hello World"), "hello-world")

    def test_punctuation(self):
        self.assertEqual(slugify("Hello, World!!!"), "hello-world")

    def test_accents(self):
        self.assertEqual(slugify("Café Münster"), "cafe-munster")

    def test_empty_string(self):
        self.assertEqual(slugify(""), "")

    def test_whitespace_only(self):
        self.assertEqual(slugify("   \t\n "), "")

    def test_leading_trailing_separators(self):
        self.assertEqual(slugify("  --Hello--  "), "hello")

    def test_multiple_separators_collapse(self):
        self.assertEqual(slugify("a___b   c"), "a-b-c")

    def test_eszett(self):
        self.assertEqual(slugify("Straße"), "strasse")

    def test_uppercase_and_digits(self):
        self.assertEqual(slugify("Python 3.12 Release"), "python-3-12-release")

    def test_non_string_int_raises(self):
        with self.assertRaises(TypeError):
            slugify(123)

    def test_non_string_none_raises(self):
        with self.assertRaises(TypeError):
            slugify(None)

    def test_non_string_list_raises(self):
        with self.assertRaises(TypeError):
            slugify(["hello"])


if __name__ == "__main__":
    unittest.main()
