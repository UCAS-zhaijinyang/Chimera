"""Unit tests for src/textstats.py (stdlib unittest only)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import summarize  # noqa: E402


class TestSummarize(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(
            summarize(""),
            {"chars": 0, "words": 0, "lines": 0, "unique_words": 0},
        )

    def test_single_word(self):
        self.assertEqual(
            summarize("hello"),
            {"chars": 5, "words": 1, "lines": 1, "unique_words": 1},
        )

    def test_multi_line(self):
        text = "first line\nsecond line\nthird"
        self.assertEqual(
            summarize(text),
            {"chars": len(text), "words": 5, "lines": 3, "unique_words": 5},
        )

    def test_trailing_newline_does_not_add_line(self):
        self.assertEqual(summarize("a\n")["lines"], 1)

    def test_unique_words_case_insensitive(self):
        self.assertEqual(
            summarize("The the THE cat")["unique_words"],
            2,
        )

    def test_whitespace_only(self):
        self.assertEqual(
            summarize("   \t  "),
            {"chars": 6, "words": 0, "lines": 1, "unique_words": 0},
        )

    def test_non_string_raises_type_error(self):
        for bad in (None, 123, ["a"], b"bytes"):
            with self.subTest(bad=bad):
                with self.assertRaises(TypeError):
                    summarize(bad)


if __name__ == "__main__":
    unittest.main()
