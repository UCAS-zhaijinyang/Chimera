"""Small self-contained statistics helpers.

Fixture variation 4.
"""

from __future__ import annotations

from collections import Counter
from typing import Sequence

__all__ = ["mean", "median", "mode", "clamp"]


def _require_non_empty(values: Sequence[float]) -> None:
    if len(values) == 0:
        raise ValueError("values must be non-empty")


def mean(values: Sequence[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    _require_non_empty(values)
    return sum(values) / len(values)


def median(values: Sequence[float]) -> float:
    """Return the median of ``values``.

    For an even number of elements the average of the two central values is
    returned.

    Raises:
        ValueError: if ``values`` is empty.
    """
    _require_non_empty(values)
    ordered = sorted(values)
    n = len(ordered)
    mid = n // 2
    if n % 2 == 1:
        return float(ordered[mid])
    return (ordered[mid - 1] + ordered[mid]) / 2


def mode(values: Sequence[float]) -> float:
    """Return the most common value in ``values``.

    Ties are resolved deterministically by returning the smallest value among
    the most frequent ones.

    Raises:
        ValueError: if ``values`` is empty.
    """
    _require_non_empty(values)
    counts = Counter(values)
    highest = max(counts.values())
    return min(value for value, count in counts.items() if count == highest)


def clamp(value: float, low: float, high: float) -> float:
    """Clamp ``value`` into the inclusive range ``[low, high]``.

    Raises:
        ValueError: if ``low`` is greater than ``high``.
    """
    if low > high:
        raise ValueError("low must be less than or equal to high")
    if value < low:
        return low
    if value > high:
        return high
    return value
