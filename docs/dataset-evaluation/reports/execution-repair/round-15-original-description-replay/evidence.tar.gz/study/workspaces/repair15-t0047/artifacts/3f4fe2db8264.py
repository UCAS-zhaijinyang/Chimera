"""Unit tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


def test_word_count_normal():
    assert word_count("the quick brown fox") == 4


def test_word_count_empty_and_whitespace():
    assert word_count("") == 0
    assert word_count("   \t\n ") == 0


def test_char_count_normal():
    assert char_count("abc") == 3
    assert char_count("a b c") == 5


def test_char_count_ignore_whitespace():
    assert char_count("a b c", ignore_whitespace=True) == 3
    assert char_count("  ", ignore_whitespace=True) == 0


def test_top_words_ranking_and_case_insensitivity():
    text = "The cat the dog The bird"
    assert top_words(text, n=2) == [("the", 3), ("bird", 1)]


def test_top_words_tie_break_alphabetical():
    text = "banana apple cherry"
    assert top_words(text, n=3) == [("apple", 1), ("banana", 1), ("cherry", 1)]


def test_top_words_punctuation_stripped():
    text = "hello, hello! world."
    assert top_words(text, n=1) == [("hello", 2)]


def test_top_words_n_zero_or_negative():
    assert top_words("a b c", n=0) == []
    assert top_words("a b c", n=-5) == []


def test_top_words_n_larger_than_vocab():
    assert top_words("a b", n=10) == [("a", 1), ("b", 1)]


def test_top_words_empty_input():
    assert top_words("") == []
    assert top_words("   ") == []


def test_summarize_aggregate():
    result = summarize("one two two three three three")
    assert result["words"] == 6
    assert result["chars"] == len("one two two three three three")
    assert result["unique_words"] == 3
    assert result["top_words"][0] == ("three", 3)


def test_summarize_empty():
    result = summarize("")
    assert result == {"words": 0, "chars": 0, "unique_words": 0, "top_words": []}


@pytest.mark.parametrize("func", [word_count, char_count, top_words, summarize])
def test_non_string_raises_type_error(func):
    with pytest.raises(TypeError):
        func(123)
