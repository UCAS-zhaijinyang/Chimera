"""Regression tests for src/pagination.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from pagination import total_pages  # noqa: E402


def test_exact_multiple_has_no_extra_page():
    # Regression: 20 items / 10 per page must be 2 pages, not 3.
    assert total_pages(20, 10) == 2


def test_partial_last_page_rounds_up():
    assert total_pages(21, 10) == 3


def test_single_page():
    assert total_pages(5, 10) == 1


def test_zero_items():
    assert total_pages(0, 10) == 0


def test_invalid_page_size():
    with pytest.raises(ValueError):
        total_pages(10, 0)
