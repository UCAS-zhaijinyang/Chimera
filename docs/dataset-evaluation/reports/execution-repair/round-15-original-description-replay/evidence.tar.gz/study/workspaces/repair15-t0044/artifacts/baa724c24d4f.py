"""Test package for the slugify feature."""
