"""Small utility for splitting a sequence into fixed-size chunks."""

from typing import Sequence, List, TypeVar

T = TypeVar("T")


def chunk(seq: Sequence[T], size: int) -> List[List[T]]:
    """Split ``seq`` into consecutive chunks of at most ``size`` elements.

    The final chunk may be shorter than ``size`` when the sequence length is
    not an exact multiple of ``size``. An empty sequence yields an empty list.
    """
    if size <= 0:
        raise ValueError("size must be a positive integer")

    chunks: List[List[T]] = []
    for start in range(0, len(seq), size):
        chunks.append(list(seq[start:start + size]))
    return chunks
