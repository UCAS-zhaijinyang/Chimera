"""Tests covering the mean() bug from fixture variation 2."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from stats import mean  # noqa: E402


def test_mean_of_single_value():
    assert mean([5]) == 5.0


def test_mean_of_even_count():
    assert mean([1, 2, 3, 4]) == 2.5


def test_mean_of_odd_count():
    assert mean([1, 2, 3]) == 2.0


def test_mean_of_empty_is_zero():
    assert mean([]) == 0.0


def test_mean_accepts_generator():
    assert mean(x for x in [2, 4, 6]) == 4.0
