"""Regression tests for src/calculator.py (fixture variation 4)."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from calculator import average, median, total  # noqa: E402


def test_total():
    assert total([1, 2, 3]) == 6


def test_average_without_zeros():
    assert average([2, 4, 6]) == 4


def test_average_with_zeros_regression():
    # Regression: zeros must count toward the divisor.
    assert average([0, 2]) == 1
    assert average([0, 0, 0]) == 0
    assert average([0, 1, 2, 3]) == 1.5


def test_average_empty_raises():
    with pytest.raises(ValueError):
        average([])


def test_median():
    assert median([3, 1, 2]) == 2
    assert median([4, 1, 3, 2]) == 2.5
