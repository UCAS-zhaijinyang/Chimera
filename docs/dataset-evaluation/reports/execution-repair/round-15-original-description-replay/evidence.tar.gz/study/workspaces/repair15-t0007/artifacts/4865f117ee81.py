"""Unit tests for src.text_utils.normalize_whitespace."""

import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.text_utils import normalize_whitespace


class TestNormalizeWhitespace(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(normalize_whitespace(""), "")

    def test_single_word(self):
        self.assertEqual(normalize_whitespace("hello"), "hello")

    def test_multiple_spaces(self):
        self.assertEqual(normalize_whitespace("a   b"), "a b")

    def test_tabs_and_newlines(self):
        self.assertEqual(normalize_whitespace("a\t\nb"), "a b")

    def test_leading_and_trailing_whitespace(self):
        self.assertEqual(normalize_whitespace("  a b  "), "a b")

    def test_only_whitespace(self):
        self.assertEqual(normalize_whitespace("   \t\n  "), "")

    def test_mixed_whitespace_runs(self):
        self.assertEqual(normalize_whitespace("  one \t two \n\n three  "), "one two three")

    def test_non_string_none_raises_type_error(self):
        with self.assertRaises(TypeError):
            normalize_whitespace(None)

    def test_non_string_int_raises_type_error(self):
        with self.assertRaises(TypeError):
            normalize_whitespace(123)

    def test_non_string_list_raises_type_error(self):
        with self.assertRaises(TypeError):
            normalize_whitespace(["a", "b"])


if __name__ == "__main__":
    unittest.main()
