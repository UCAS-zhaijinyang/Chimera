"""Small statistics helpers.

Bug (fixture variation 2): ``mean`` divided by ``len(values) - 1`` instead of
``len(values)``, so the average of a non-empty sequence was wrong (and an empty
sequence raised ZeroDivisionError instead of returning 0.0).
"""

from __future__ import annotations

from typing import Iterable


def mean(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` rather than raising.
    """
    items = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)
