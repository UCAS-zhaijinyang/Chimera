"""Unit tests for :mod:`textstats`."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import summarize  # noqa: E402


class SummarizeTests(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(
            summarize(""),
            {
                "characters": 0,
                "words": 0,
                "lines": 0,
                "unique_words": 0,
                "longest_word": "",
            },
        )

    def test_single_word(self):
        self.assertEqual(
            summarize("Hello"),
            {
                "characters": 5,
                "words": 1,
                "lines": 1,
                "unique_words": 1,
                "longest_word": "hello",
            },
        )

    def test_multiline(self):
        text = "Hello world\nHello there"
        result = summarize(text)
        self.assertEqual(result["characters"], len(text))
        self.assertEqual(result["words"], 4)
        self.assertEqual(result["lines"], 2)
        self.assertEqual(result["unique_words"], 3)
        self.assertEqual(result["longest_word"], "hello")

    def test_case_insensitive_uniqueness(self):
        result = summarize("Cat cat CAT dog")
        self.assertEqual(result["words"], 4)
        self.assertEqual(result["unique_words"], 2)

    def test_longest_word_tie_first_occurrence(self):
        result = summarize("abcd wxyz ab")
        self.assertEqual(result["longest_word"], "abcd")

    def test_whitespace_only(self):
        result = summarize("   \n\t  ")
        self.assertEqual(result["words"], 0)
        self.assertEqual(result["unique_words"], 0)
        self.assertEqual(result["longest_word"], "")
        self.assertEqual(result["characters"], 7)

    def test_trailing_newline_does_not_add_line(self):
        self.assertEqual(summarize("a\nb\n")["lines"], 2)

    def test_non_string_raises_type_error(self):
        with self.assertRaises(TypeError):
            summarize(123)
        with self.assertRaises(TypeError):
            summarize(None)


if __name__ == "__main__":
    unittest.main()
