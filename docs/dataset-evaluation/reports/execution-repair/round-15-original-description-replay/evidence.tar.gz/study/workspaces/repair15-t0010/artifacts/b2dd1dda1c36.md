# Design Document — Small Python Feature (Fixture Variation 3)

## 1. Scope
Implement a small, self-contained Python feature with unit tests, a build step, and a
simulated review record. No external dependencies beyond the Python standard library.

## 2. Feature
A text statistics utility module `src/textstats.py` providing:

- `word_count(text: str) -> int` — number of whitespace-separated tokens.
- `char_count(text: str, ignore_whitespace: bool = False) -> int` — character count,
  optionally excluding whitespace.
- `top_words(text: str, n: int = 3) -> list[tuple[str, int]]` — most frequent
  lowercased words, ties broken alphabetically, limited to `n` entries.
- `summarize(text: str) -> dict` — aggregate dict with `words`, `chars`,
  `chars_no_ws`, and `top`.

Edge cases: empty string returns zeros / empty list; `n <= 0` returns `[]`;
punctuation is stripped from word boundaries for `top_words`.

## 3. Files
- `src/textstats.py` — implementation.
- `tests/test_textstats.py` — unit tests (stdlib `unittest`).
- `reports/design.md` — this document (copy).
- `reports/review.md` — simulated review record (produced at review phase).

## 4. Test Plan
Run `python -m unittest discover -s tests -v` using the project interpreter.
Cover: empty input, single word, multi-word, whitespace-only, punctuation handling,
`n` bounds, and `summarize` aggregation.

## 5. Build
Build step: byte-compile sources and run the test suite as the acceptance gate:
`python -m compileall src tests` then the unittest command above.

## 6. Acceptance Criteria
- All unit tests pass.
- `compileall` succeeds with no syntax errors.
- Public functions behave per Section 2 including edge cases.
