"""Tests for src/strutil.py (fixture variation 0)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from strutil import normalize_whitespace  # noqa: E402


class NormalizeWhitespaceTests(unittest.TestCase):
    def test_collapses_multiple_spaces(self):
        self.assertEqual(normalize_whitespace("  hello   world  "), "hello world")

    def test_collapses_mixed_whitespace(self):
        self.assertEqual(normalize_whitespace("a\t\tb\n c"), "a b c")

    def test_strips_leading_and_trailing(self):
        self.assertEqual(normalize_whitespace("\n  value \t"), "value")

    def test_empty_string(self):
        self.assertEqual(normalize_whitespace(""), "")

    def test_whitespace_only(self):
        self.assertEqual(normalize_whitespace("   \n\t "), "")

    def test_single_word_unchanged(self):
        self.assertEqual(normalize_whitespace("single"), "single")

    def test_unicode_whitespace(self):
        self.assertEqual(normalize_whitespace("a\u00a0\u2003b"), "a b")

    def test_non_string_raises_type_error(self):
        with self.assertRaises(TypeError):
            normalize_whitespace(None)
        with self.assertRaises(TypeError):
            normalize_whitespace(123)


if __name__ == "__main__":
    unittest.main()
