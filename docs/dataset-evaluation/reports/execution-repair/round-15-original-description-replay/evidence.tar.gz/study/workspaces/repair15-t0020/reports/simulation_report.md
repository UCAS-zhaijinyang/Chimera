# Simulation Data Report

Source: simulation data (fixture variation 1)
Evidence level: simulation_only
Business status: not_measured

## Transformed Data (grouped by week)

| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Summary

- Total count across weeks: 8
- Weeks observed: 2 (W1, W2)
- Trend: count increased from W1 (3) to W2 (5), a change of +2.

## Notes

This report is based on simulated data only. Values are not measured business
results and should not be used for operational decisions.
