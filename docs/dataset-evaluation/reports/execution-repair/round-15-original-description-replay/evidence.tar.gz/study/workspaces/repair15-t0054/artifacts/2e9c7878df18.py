"""Regression tests for src/textstats.py (fixture variation 5)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import average_word_length  # noqa: E402


class AverageWordLengthTests(unittest.TestCase):
    def test_simple_sentence(self):
        self.assertEqual(average_word_length("ab cde"), 2.5)

    def test_repeated_whitespace_is_ignored(self):
        self.assertEqual(average_word_length("  ab   cde  "), 2.5)

    def test_empty_string_returns_zero(self):
        self.assertEqual(average_word_length(""), 0.0)

    def test_whitespace_only_returns_zero(self):
        self.assertEqual(average_word_length("   \t\n  "), 0.0)


if __name__ == "__main__":
    unittest.main()
