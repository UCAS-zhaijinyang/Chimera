"""Small Python feature package (fixture variation 1)."""

from .slugify import slugify

__all__ = ["slugify"]
