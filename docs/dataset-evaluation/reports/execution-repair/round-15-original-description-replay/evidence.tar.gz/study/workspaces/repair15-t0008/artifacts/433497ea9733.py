"""Small text statistics utility.

Public API:
    summarize(text: str) -> dict

See reports/design_document.md for the full specification.
"""

from __future__ import annotations

__all__ = ["summarize"]


def summarize(text: str) -> dict:
    """Return basic statistics for ``text``.

    Parameters
    ----------
    text:
        The string to analyze. Must be a ``str``.

    Returns
    -------
    dict
        A dict with the keys:

        - ``chars``: number of characters (``len(text)``).
        - ``words``: number of whitespace-separated tokens.
        - ``lines``: number of lines (``0`` for the empty string).
        - ``unique_words``: number of distinct lowercased word tokens.

    Raises
    ------
    TypeError
        If ``text`` is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")

    tokens = text.split()
    return {
        "chars": len(text),
        "words": len(tokens),
        "lines": len(text.splitlines()) if text else 0,
        "unique_words": len({token.lower() for token in tokens}),
    }
