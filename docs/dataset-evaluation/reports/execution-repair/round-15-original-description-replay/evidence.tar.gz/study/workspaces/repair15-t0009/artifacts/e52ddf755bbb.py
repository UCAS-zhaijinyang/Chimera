"""Small text statistics utilities.

Pure, dependency-free helpers for counting words and characters in a string.

Public API:
    word_count(text) -> int
    char_frequency(text) -> dict[str, int]
    top_words(text, n=3) -> list[tuple[str, int]]
"""

from __future__ import annotations

import re
from collections import Counter

_WORD_RE = re.compile(r"[A-Za-z0-9']+")
_ALNUM_RE = re.compile(r"[A-Za-z0-9]")


def normalize(text: str) -> str:
    """Return ``text`` lowercased with surrounding whitespace stripped."""
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return text.lower().strip()


def word_count(text: str) -> int:
    """Return the number of whitespace-separated word tokens in ``text``.

    Punctuation-only tokens are not counted as words.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return len(_WORD_RE.findall(text))


def char_frequency(text: str) -> dict[str, int]:
    """Return the frequency of alphanumeric characters, lowercased.

    Non-alphanumeric characters (spaces, punctuation, symbols) are ignored.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    counts = Counter(ch for ch in text.lower() if _ALNUM_RE.match(ch))
    return dict(counts)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most common words as ``(word, count)`` pairs.

    Words are lowercased. Ties are broken alphabetically (ascending).
    Returns an empty list when ``n <= 0`` or there are no words.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    if n <= 0:
        return []
    counts = Counter(w.lower() for w in _WORD_RE.findall(text))
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]
