"""Small Python feature package: text utilities."""

from .text_utils import normalize_whitespace

__all__ = ["normalize_whitespace"]
