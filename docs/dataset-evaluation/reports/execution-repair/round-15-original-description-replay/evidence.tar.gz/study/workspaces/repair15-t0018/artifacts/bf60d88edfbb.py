"""Regression tests for src/stats.py (fixture variation 5)."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stats import mean, median, variance, percentile  # noqa: E402


def test_mean():
    assert mean([1, 2, 3, 4]) == 2.5


def test_median_odd():
    assert median([3, 1, 2]) == 2


def test_median_even():
    assert median([4, 1, 3, 2]) == 2.5


def test_variance():
    assert variance([2, 4, 4, 4, 5, 5, 7, 9]) == 4.0


def test_percentile_median_of_odd_list():
    # Regression: 50th percentile of [1, 2, 3] must be 2.
    assert percentile([1, 2, 3], 50) == 2


def test_percentile_100_does_not_raise():
    # Regression: pct == 100 previously raised IndexError.
    assert percentile([1, 2, 3, 4], 100) == 4


def test_percentile_0():
    assert percentile([1, 2, 3, 4], 0) == 1


def test_percentile_interpolates():
    assert percentile([0, 10], 25) == 2.5


def test_percentile_single_value():
    assert percentile([7], 90) == 7


def test_percentile_rejects_out_of_range():
    try:
        percentile([1, 2, 3], 150)
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError for pct > 100")


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print("PASS", name)
            except Exception as exc:  # noqa: BLE001
                failures += 1
                print("FAIL", name, "->", exc)
    print("failures:", failures)
    sys.exit(1 if failures else 0)
