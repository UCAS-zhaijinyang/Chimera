"""Small text statistics utilities (fixture variation 5).

Pure, dependency-free helpers for counting words/characters and finding the
most frequent words in a piece of text.
"""

from __future__ import annotations

import string
from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]

_PUNCT = string.punctuation


def _tokens(text: str) -> list[str]:
    """Split text into normalized (lowercased, punctuation-stripped) words."""
    words = []
    for raw in text.split():
        cleaned = raw.strip(_PUNCT).lower()
        if cleaned:
            words.append(cleaned)
    return words


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``."""
    return len(text.split())


def char_count(text: str, ignore_whitespace: bool = False) -> int:
    """Return the character count of ``text``.

    When ``ignore_whitespace`` is True, whitespace characters are excluded.
    """
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` pairs.

    Words are lowercased and stripped of surrounding punctuation. Ties are
    broken alphabetically. ``n <= 0`` yields an empty list.
    """
    if n <= 0:
        return []
    counts = Counter(_tokens(text))
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return an aggregate summary dict for ``text``."""
    return {
        "words": word_count(text),
        "chars": char_count(text),
        "chars_no_ws": char_count(text, ignore_whitespace=True),
        "top_words": top_words(text),
    }
