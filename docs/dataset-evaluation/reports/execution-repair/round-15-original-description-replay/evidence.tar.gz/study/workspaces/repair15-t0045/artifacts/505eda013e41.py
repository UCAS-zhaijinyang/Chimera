"""Small text statistics utility.

Provides :func:`summarize`, which returns basic statistics about a string.
"""

from __future__ import annotations

__all__ = ["summarize"]


def summarize(text: str) -> dict:
    """Return basic statistics for ``text``.

    Parameters
    ----------
    text:
        The string to analyze.

    Returns
    -------
    dict
        A mapping with the keys ``chars``, ``words``, ``lines`` and
        ``unique_words``.

    Examples
    --------
    >>> summarize("hello world")
    {'chars': 11, 'words': 2, 'lines': 1, 'unique_words': 2}
    >>> summarize("")
    {'chars': 0, 'words': 0, 'lines': 0, 'unique_words': 0}
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")

    words = text.split()
    return {
        "chars": len(text),
        "words": len(words),
        "lines": len(text.splitlines()),
        "unique_words": len({word.lower() for word in words}),
    }
