"""Small text statistics utility.

Provides :func:`summarize`, which returns basic statistics about a text string.
"""

from __future__ import annotations

__all__ = ["summarize"]


def summarize(text: str) -> dict:
    """Return basic statistics about ``text``.

    The returned mapping contains:

    ``characters``
        Total number of characters, including whitespace.
    ``words``
        Number of whitespace-separated tokens.
    ``lines``
        Number of lines (``0`` for the empty string).
    ``unique_words``
        Number of distinct lowercased words.
    ``longest_word``
        The longest word, lowercased, or ``""`` when there are no words.
        Ties resolve to the first occurrence.

    Raises:
        TypeError: If ``text`` is not a :class:`str`.
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")

    tokens = text.split()
    lowered = [token.lower() for token in tokens]

    longest_word = ""
    for word in lowered:
        if len(word) > len(longest_word):
            longest_word = word

    return {
        "characters": len(text),
        "words": len(tokens),
        "lines": len(text.splitlines()),
        "unique_words": len(set(lowered)),
        "longest_word": longest_word,
    }
