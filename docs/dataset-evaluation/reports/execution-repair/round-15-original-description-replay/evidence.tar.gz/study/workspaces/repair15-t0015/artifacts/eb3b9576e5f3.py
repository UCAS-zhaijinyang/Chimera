"""Regression tests for the chunking utility (fixture variation 2)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from chunking import chunk  # noqa: E402


class ChunkTests(unittest.TestCase):
    def test_exact_multiple_keeps_final_chunk(self):
        # Regression: the last full chunk used to be dropped.
        self.assertEqual(chunk([1, 2, 3, 4], 2), [[1, 2], [3, 4]])

    def test_remainder_produces_short_final_chunk(self):
        self.assertEqual(chunk([1, 2, 3, 4, 5], 2), [[1, 2], [3, 4], [5]])

    def test_size_larger_than_sequence(self):
        self.assertEqual(chunk([1, 2, 3], 10), [[1, 2, 3]])

    def test_empty_sequence(self):
        self.assertEqual(chunk([], 3), [])

    def test_size_one(self):
        self.assertEqual(chunk([1, 2, 3], 1), [[1], [2], [3]])

    def test_invalid_size_raises(self):
        with self.assertRaises(ValueError):
            chunk([1, 2, 3], 0)
        with self.assertRaises(ValueError):
            chunk([1, 2, 3], -1)


if __name__ == "__main__":
    unittest.main()
