"""Unit tests for src/stats.py (standard library only)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

import stats  # noqa: E402


class MeanTests(unittest.TestCase):
    def test_mean_basic(self):
        self.assertAlmostEqual(stats.mean([1, 2, 3, 4]), 2.5, places=7)

    def test_mean_tuple(self):
        self.assertAlmostEqual(stats.mean((2, 4, 6)), 4.0, places=7)

    def test_mean_empty_raises(self):
        with self.assertRaises(ValueError):
            stats.mean([])


class MedianTests(unittest.TestCase):
    def test_median_odd_unsorted(self):
        self.assertAlmostEqual(stats.median([3, 1, 2]), 2.0, places=7)

    def test_median_even(self):
        self.assertAlmostEqual(stats.median([1, 2, 3, 4]), 2.5, places=7)

    def test_median_single(self):
        self.assertAlmostEqual(stats.median([7]), 7.0, places=7)

    def test_median_empty_raises(self):
        with self.assertRaises(ValueError):
            stats.median([])


class StdevTests(unittest.TestCase):
    def test_stdev_known_value(self):
        self.assertAlmostEqual(
            stats.stdev([2, 4, 4, 4, 5, 5, 7, 9]), 2.138089935299395, places=7
        )

    def test_stdev_two_values(self):
        self.assertAlmostEqual(stats.stdev([1, 3]), 1.4142135623730951, places=7)

    def test_stdev_single_raises(self):
        with self.assertRaises(ValueError):
            stats.stdev([1])

    def test_stdev_empty_raises(self):
        with self.assertRaises(ValueError):
            stats.stdev([])


class SummarizeTests(unittest.TestCase):
    def test_summarize_basic(self):
        result = stats.summarize([1, 2, 3, 4])
        self.assertEqual(result["count"], 4)
        self.assertAlmostEqual(result["mean"], 2.5, places=7)
        self.assertAlmostEqual(result["median"], 2.5, places=7)
        self.assertAlmostEqual(result["stdev"], 1.2909944487358056, places=7)

    def test_summarize_empty_raises(self):
        with self.assertRaises(ValueError):
            stats.summarize([])


class NoMutationTests(unittest.TestCase):
    def test_inputs_not_mutated(self):
        data = [3, 1, 2, 4]
        original = list(data)
        stats.mean(data)
        stats.median(data)
        stats.stdev(data)
        stats.summarize(data)
        self.assertEqual(data, original)


if __name__ == "__main__":
    unittest.main()
