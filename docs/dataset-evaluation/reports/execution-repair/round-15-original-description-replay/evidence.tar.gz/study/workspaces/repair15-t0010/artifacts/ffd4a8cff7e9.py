"""Small text statistics utility (fixture variation 3).

Standard-library only. See reports/design.md for the specification.
"""

from __future__ import annotations

import re
from collections import Counter

_WORD_RE = re.compile(r"[A-Za-z0-9']+")


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in *text*."""
    return len(text.split())


def char_count(text: str, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in *text*.

    When *ignore_whitespace* is true, whitespace characters are excluded.
    """
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the *n* most frequent lowercased words as (word, count) pairs.

    Ties are broken alphabetically. Returns an empty list when *n* <= 0.
    """
    if n <= 0:
        return []
    words = [m.group(0).lower() for m in _WORD_RE.finditer(text)]
    counts = Counter(words)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return an aggregate summary dict for *text*."""
    return {
        "words": word_count(text),
        "chars": char_count(text),
        "chars_no_ws": char_count(text, ignore_whitespace=True),
        "top": top_words(text),
    }
