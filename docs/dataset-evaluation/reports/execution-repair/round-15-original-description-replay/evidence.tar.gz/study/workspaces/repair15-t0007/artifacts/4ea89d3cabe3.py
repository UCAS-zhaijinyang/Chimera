"""Text normalization utilities.

Public API:
    normalize_whitespace(text: str) -> str
"""

import re

__all__ = ["normalize_whitespace"]

_WHITESPACE_RUN = re.compile(r"\s+")


def normalize_whitespace(text: str) -> str:
    """Collapse runs of whitespace into a single space and strip the ends.

    Args:
        text: The string to normalize.

    Returns:
        The normalized string with all runs of whitespace (spaces, tabs,
        newlines, and other Unicode whitespace) replaced by a single space,
        and with leading/trailing whitespace removed.

    Raises:
        TypeError: If ``text`` is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError(
            "normalize_whitespace() expects a str, got "
            f"{type(text).__name__}"
        )
    return _WHITESPACE_RUN.sub(" ", text).strip()
