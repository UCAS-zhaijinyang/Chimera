"""Small text statistics utilities (fixture variation 3).

Standard-library only. See reports/design.md for the design record.
"""

from __future__ import annotations

import re
from collections import Counter

_WORD_RE = re.compile(r"[A-Za-z0-9']+")


def _tokens(text: str) -> list[str]:
    """Return lowercased word tokens with punctuation stripped."""
    return [m.group(0).lower() for m in _WORD_RE.finditer(text)]


def word_count(text: str) -> int:
    """Number of whitespace-separated tokens in *text*."""
    return len(text.split())


def char_count(text: str, ignore_whitespace: bool = False) -> int:
    """Character count of *text*, optionally excluding whitespace."""
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Most frequent lowercased words, ties broken alphabetically.

    Returns at most *n* ``(word, count)`` pairs. ``n <= 0`` yields ``[]``.
    """
    if n <= 0:
        return []
    counts = Counter(_tokens(text))
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Aggregate statistics for *text*."""
    return {
        "words": word_count(text),
        "chars": char_count(text),
        "chars_no_ws": char_count(text, ignore_whitespace=True),
        "top_words": top_words(text),
    }
