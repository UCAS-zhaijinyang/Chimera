"""Build/verification step for the slugify feature.

1. Verifies the module imports and the public API is callable.
2. Runs the unit test suite via unittest discovery.
3. Exits non-zero on failure, prints a success summary otherwise.
"""

import sys
import unittest


def verify_import() -> None:
    from src.slugify import slugify

    assert callable(slugify), "slugify must be callable"
    assert slugify("Build Check") == "build-check", "smoke check failed"
    print("[build] import + smoke check OK")


def run_tests() -> int:
    loader = unittest.TestLoader()
    suite = loader.discover("tests", pattern="test_*.py")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    return 0 if result.wasSuccessful() else 1


def main() -> int:
    verify_import()
    code = run_tests()
    if code == 0:
        print("[build] all tests passed — build succeeded")
    else:
        print("[build] tests failed — build failed", file=sys.stderr)
    return code


if __name__ == "__main__":
    sys.exit(main())
