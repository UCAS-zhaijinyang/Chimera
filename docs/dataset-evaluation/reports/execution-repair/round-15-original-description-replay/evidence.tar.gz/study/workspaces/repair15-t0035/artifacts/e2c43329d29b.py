"""Small calculator module used by the bug-fix workflow fixture."""


def add(a, b):
    """Return the sum of a and b."""
    return a + b


def divide(a, b):
    """Return a divided by b.

    Raises:
        ZeroDivisionError: if b is zero.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b


def average(values):
    """Return the arithmetic mean of a non-empty sequence of numbers.

    Raises:
        ValueError: if values is empty.
    """
    if not values:
        raise ValueError("average() requires at least one value")
    return sum(values) / len(values)
