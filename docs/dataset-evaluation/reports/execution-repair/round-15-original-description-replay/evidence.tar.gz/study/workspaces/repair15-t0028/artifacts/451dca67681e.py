"""Unit tests for src/textstats.py (fixture variation 3)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_normal_text(self):
        self.assertEqual(word_count("the quick brown fox"), 4)

    def test_empty_string(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n  "), 0)

    def test_extra_whitespace(self):
        self.assertEqual(word_count("  a   b  "), 2)


class CharCountTests(unittest.TestCase):
    def test_includes_whitespace_by_default(self):
        self.assertEqual(char_count("a b"), 3)

    def test_ignore_whitespace(self):
        self.assertEqual(char_count("a b\nc", ignore_whitespace=True), 3)

    def test_empty_string(self):
        self.assertEqual(char_count(""), 0)
        self.assertEqual(char_count("", ignore_whitespace=True), 0)


class TopWordsTests(unittest.TestCase):
    def test_basic_ordering(self):
        text = "apple banana apple cherry apple banana"
        self.assertEqual(top_words(text), [("apple", 3), ("banana", 2), ("cherry", 1)])

    def test_ties_broken_alphabetically(self):
        text = "beta alpha beta alpha gamma"
        self.assertEqual(top_words(text, n=2), [("alpha", 2), ("beta", 2)])

    def test_punctuation_stripped_and_case_folded(self):
        text = "Hello, hello! HELLO world."
        self.assertEqual(top_words(text, n=1), [("hello", 3)])

    def test_limit_n(self):
        text = "a b c d e"
        self.assertEqual(len(top_words(text, n=2)), 2)

    def test_n_non_positive(self):
        self.assertEqual(top_words("a b c", n=0), [])
        self.assertEqual(top_words("a b c", n=-5), [])

    def test_empty_string(self):
        self.assertEqual(top_words(""), [])


class SummarizeTests(unittest.TestCase):
    def test_aggregate(self):
        result = summarize("one two two")
        self.assertEqual(result["words"], 3)
        self.assertEqual(result["chars"], 11)
        self.assertEqual(result["chars_no_ws"], 9)
        self.assertEqual(result["top_words"], [("two", 2), ("one", 1)])

    def test_empty(self):
        self.assertEqual(
            summarize(""),
            {"words": 0, "chars": 0, "chars_no_ws": 0, "top_words": []},
        )


if __name__ == "__main__":
    unittest.main()
