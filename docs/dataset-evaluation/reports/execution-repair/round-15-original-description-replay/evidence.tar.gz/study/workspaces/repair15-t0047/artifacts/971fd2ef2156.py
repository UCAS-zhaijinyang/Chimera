"""Small text statistics utilities.

Public API:
    word_count(text) -> int
    char_count(text, ignore_whitespace=False) -> int
    top_words(text, n=3) -> list[tuple[str, int]]
    summarize(text) -> dict
"""

from __future__ import annotations

import re
from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]

_WORD_RE = re.compile(r"[A-Za-z0-9']+")


def _require_str(text: str) -> str:
    if not isinstance(text, str):
        raise TypeError(f"expected str, got {type(text).__name__}")
    return text


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in *text*."""
    _require_str(text)
    return len(text.split())


def char_count(text: str, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in *text*.

    When *ignore_whitespace* is True, whitespace characters are excluded.
    """
    _require_str(text)
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def _normalized_words(text: str) -> list[str]:
    return [m.group(0).lower() for m in _WORD_RE.finditer(text)]


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the *n* most frequent words as (word, count) pairs.

    Counting is case-insensitive and surrounding punctuation is ignored.
    Ties are broken alphabetically. ``n <= 0`` yields an empty list.
    """
    _require_str(text)
    if n <= 0:
        return []
    counts = Counter(_normalized_words(text))
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ranked[:n]


def summarize(text: str) -> dict:
    """Return aggregate statistics for *text*."""
    _require_str(text)
    words = _normalized_words(text)
    return {
        "words": word_count(text),
        "chars": char_count(text),
        "unique_words": len(set(words)),
        "top_words": top_words(text),
    }
