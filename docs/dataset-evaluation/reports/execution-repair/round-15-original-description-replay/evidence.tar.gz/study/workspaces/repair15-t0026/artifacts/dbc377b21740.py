"""URL slug generation utility.

Public API:
    slugify(text: str) -> str
"""

from __future__ import annotations

import re
import unicodedata

__all__ = ["slugify"]

# Characters that NFKD does not decompose into ASCII letters.
_SPECIAL_MAP = {
    "\u00df": "ss",  # ß
    "\u00e6": "ae",  # æ
    "\u00c6": "AE",  # Æ
    "\u00f8": "o",   # ø
    "\u00d8": "O",   # Ø
    "\u0111": "d",   # đ
    "\u0110": "D",   # Đ
    "\u0142": "l",   # ł
    "\u0141": "L",   # Ł
    "\u00fe": "th",  # þ
    "\u00f0": "d",   # ð
}

_SEPARATOR_RE = re.compile(r"[^a-z0-9]+")


def _transliterate(text: str) -> str:
    """Best-effort transliteration of common Latin characters to ASCII."""
    text = "".join(_SPECIAL_MAP.get(ch, ch) for ch in text)
    decomposed = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch))


def slugify(text: str) -> str:
    """Convert arbitrary text into a URL-friendly slug.

    Rules:
      * lowercase the input
      * transliterate common Latin accented characters to ASCII
      * replace any run of non-alphanumeric characters with a single hyphen
      * strip leading/trailing hyphens
      * return "" for empty or whitespace-only input

    Raises:
        TypeError: if ``text`` is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError(f"slugify() expects str, got {type(text).__name__}")

    ascii_text = _transliterate(text).lower()
    slug = _SEPARATOR_RE.sub("-", ascii_text)
    return slug.strip("-")
