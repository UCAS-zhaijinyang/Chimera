# Simulation Data Report

Fixture variation: 0

## Source
- Query: simulation data
- Evidence level: simulation_only
- Business status: not_measured

## Transformed Data (grouped by week)
| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Summary
- Total count across weeks: 8
- Weeks covered: 2 (W1, W2)
- Highest week: W2 with 5

## Notes
This report is based on simulated data only. Values are not measured business
results and should not be used for production decisions.
