"""Unit tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_frequency, top_words, word_count  # noqa: E402


class TestWordCount:
    def test_empty(self):
        assert word_count("") == 0

    def test_whitespace_only(self):
        assert word_count("   \t\n ") == 0

    def test_simple(self):
        assert word_count("hello world") == 2

    def test_extra_whitespace(self):
        assert word_count("  a  b ") == 2

    def test_punctuation_attached(self):
        assert word_count("hello, world!") == 2

    def test_type_error(self):
        with pytest.raises(TypeError):
            word_count(None)


class TestCharFrequency:
    def test_empty(self):
        assert char_frequency("") == {}

    def test_lowercases(self):
        assert char_frequency("Aa") == {"a": 2}

    def test_ignores_non_alnum(self):
        assert char_frequency("a, b! c?") == {"a": 1, "b": 1, "c": 1}

    def test_counts(self):
        assert char_frequency("aab") == {"a": 2, "b": 1}

    def test_type_error(self):
        with pytest.raises(TypeError):
            char_frequency(123)


class TestTopWords:
    def test_empty(self):
        assert top_words("") == []

    def test_default_n(self):
        text = "a b c d"
        assert top_words(text) == [("a", 1), ("b", 1), ("c", 1)]

    def test_ordering_by_count(self):
        text = "b b a c c c"
        assert top_words(text, 2) == [("c", 3), ("b", 2)]

    def test_tie_break_alphabetical(self):
        text = "b a c"
        assert top_words(text, 3) == [("a", 1), ("b", 1), ("c", 1)]

    def test_case_insensitive(self):
        text = "Hello hello HELLO world"
        assert top_words(text, 1) == [("hello", 3)]

    def test_n_zero(self):
        assert top_words("a b c", 0) == []

    def test_n_negative(self):
        assert top_words("a b c", -5) == []

    def test_n_larger_than_vocab(self):
        assert top_words("a b", 10) == [("a", 1), ("b", 1)]

    def test_type_error(self):
        with pytest.raises(TypeError):
            top_words(None)
