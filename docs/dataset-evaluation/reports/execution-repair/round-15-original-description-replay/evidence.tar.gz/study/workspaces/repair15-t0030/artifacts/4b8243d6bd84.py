"""Unit tests for src/textstats.py (fixture variation 5)."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import textstats  # noqa: E402


def test_word_count_basic():
    assert textstats.word_count("hello world") == 2


def test_word_count_empty_and_whitespace():
    assert textstats.word_count("") == 0
    assert textstats.word_count("   \t\n ") == 0


def test_char_count_basic():
    assert textstats.char_count("abc") == 3


def test_char_count_ignore_whitespace():
    assert textstats.char_count("a b c") == 5
    assert textstats.char_count("a b c", ignore_whitespace=True) == 3


def test_top_words_basic():
    text = "the cat the dog the bird"
    assert textstats.top_words(text, 2) == [("the", 3), ("bird", 1)]


def test_top_words_tie_break_alphabetical():
    text = "b a c a b c"
    assert textstats.top_words(text, 3) == [("a", 2), ("b", 2), ("c", 2)]


def test_top_words_punctuation_and_case():
    text = "Cat, cat! CAT. dog"
    assert textstats.top_words(text, 2) == [("cat", 3), ("dog", 1)]


def test_top_words_n_non_positive():
    assert textstats.top_words("a b c", 0) == []
    assert textstats.top_words("a b c", -5) == []


def test_top_words_empty():
    assert textstats.top_words("") == []


def test_summarize():
    result = textstats.summarize("one two two")
    assert result["words"] == 3
    assert result["chars"] == len("one two two")
    assert result["chars_no_ws"] == len("onetwotwo")
    assert result["top"] == [("two", 2), ("one", 1)]


@pytest.mark.parametrize("func", [
    textstats.word_count,
    textstats.char_count,
    textstats.top_words,
    textstats.summarize,
])
def test_type_error_on_non_string(func):
    with pytest.raises(TypeError):
        func(123)
