"""Small text statistics helpers.

Bug (fixture variation 5): ``average_word_length`` divided by the number of
words *including* empty strings produced by splitting on repeated whitespace,
which raised ZeroDivisionError for whitespace-only input and skewed the
average for normal input.
"""

from __future__ import annotations


def average_word_length(text: str) -> float:
    """Return the average length of the words in ``text``.

    Words are whitespace-separated tokens. Empty tokens (produced by repeated
    or leading/trailing whitespace) are ignored. Whitespace-only or empty
    input yields ``0.0`` instead of raising ``ZeroDivisionError``.
    """
    words = text.split()
    if not words:
        return 0.0
    return sum(len(word) for word in words) / len(words)
