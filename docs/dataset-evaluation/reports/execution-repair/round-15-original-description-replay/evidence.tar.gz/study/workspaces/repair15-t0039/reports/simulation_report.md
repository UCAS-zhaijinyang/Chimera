# Simulation Data Report — Fixture Variation 2

## Source
- Query: simulation data fixture variation 2
- Evidence level: simulation_only
- Business status: not_measured

## Transformed Data (grouped by week)
| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Summary
- Total count across weeks: 8
- Weeks observed: 2 (W1, W2)
- Trend: count increased from W1 (3) to W2 (5), a rise of 2.

## Notes
All figures derive from simulated fixture data and are not measured business values.
