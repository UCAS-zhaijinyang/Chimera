"""Small arithmetic helpers used by the reporting pipeline.

Fixture variation 4: the bug lives in ``average`` which used integer
division (``//``) instead of true division, so averages of ints were
truncated (e.g. average([1, 2]) returned 1 instead of 1.5).
"""

from __future__ import annotations

from typing import Iterable


def add(a: float, b: float) -> float:
    """Return the sum of ``a`` and ``b``."""
    return a + b


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    items = list(values)
    if not items:
        raise ValueError("average() requires at least one value")
    # BUG (before fix): used ``//`` which truncated the result for ints.
    return sum(items) / len(items)
