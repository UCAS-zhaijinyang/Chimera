"""Small string utilities.

Fixture variation 0.
"""

from __future__ import annotations

__all__ = ["normalize_whitespace"]


def normalize_whitespace(text: str) -> str:
    """Collapse runs of whitespace into single spaces and strip the ends.

    Args:
        text: The string to normalize.

    Returns:
        The normalized string. Empty or whitespace-only input yields ``""``.

    Raises:
        TypeError: If ``text`` is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError(f"expected str, got {type(text).__name__}")
    return " ".join(text.split())
