"""Small statistics utilities.

Provides :func:`summarize`, which computes basic descriptive statistics
for a sequence of numbers.
"""

from __future__ import annotations

from typing import Iterable


def summarize(numbers: Iterable[float]) -> dict:
    """Return a summary of descriptive statistics for ``numbers``.

    Parameters
    ----------
    numbers:
        Any iterable of numeric values (list, tuple, generator, ...).

    Returns
    -------
    dict
        A mapping with keys ``count``, ``sum``, ``mean``, ``min`` and ``max``.

    Raises
    ------
    ValueError
        If ``numbers`` is empty.
    TypeError
        If any value is not a real number (``bool`` is rejected as well).
    """
    values = list(numbers)

    if not values:
        raise ValueError("summarize() requires at least one value")

    for value in values:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(
                f"summarize() expects numeric values, got {type(value).__name__!r}"
            )

    total = sum(values)
    count = len(values)

    return {
        "count": count,
        "sum": total,
        "mean": total / count,
        "min": min(values),
        "max": max(values),
    }
