import pytest

from src.calculator import add, average, divide, subtract


def test_add():
    assert add(2, 3) == 5


def test_subtract():
    assert subtract(5, 3) == 2


def test_divide():
    assert divide(6, 3) == 2


def test_divide_by_zero():
    with pytest.raises(ZeroDivisionError):
        divide(1, 0)


def test_average():
    assert average([1, 2, 3]) == 2


def test_average_empty_raises():
    with pytest.raises(ValueError):
        average([])
