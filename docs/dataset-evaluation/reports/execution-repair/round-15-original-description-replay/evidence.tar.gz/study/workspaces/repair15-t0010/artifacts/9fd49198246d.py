"""Unit tests for src/textstats.py (fixture variation 3)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n  "), 0)

    def test_single_word(self):
        self.assertEqual(word_count("hello"), 1)

    def test_multi_word(self):
        self.assertEqual(word_count("the quick brown fox"), 4)


class CharCountTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(char_count(""), 0)

    def test_includes_whitespace_by_default(self):
        self.assertEqual(char_count("a b"), 3)

    def test_ignore_whitespace(self):
        self.assertEqual(char_count("a b\nc", ignore_whitespace=True), 3)

    def test_ignore_whitespace_all_ws(self):
        self.assertEqual(char_count("   ", ignore_whitespace=True), 0)


class TopWordsTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(top_words(""), [])

    def test_basic_frequency(self):
        self.assertEqual(top_words("a b a c a b"), [("a", 3), ("b", 2), ("c", 1)])

    def test_case_insensitive(self):
        self.assertEqual(top_words("The the THE cat"), [("the", 3), ("cat", 1)])

    def test_punctuation_stripped(self):
        self.assertEqual(top_words("hi, hi! bye."), [("hi", 2), ("bye", 1)])

    def test_tie_broken_alphabetically(self):
        self.assertEqual(top_words("b a c"), [("a", 1), ("b", 1), ("c", 1)])

    def test_limit_n(self):
        self.assertEqual(top_words("a b a c a b", n=2), [("a", 3), ("b", 2)])

    def test_n_zero(self):
        self.assertEqual(top_words("a b c", n=0), [])

    def test_n_negative(self):
        self.assertEqual(top_words("a b c", n=-5), [])


class SummarizeTests(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(
            summarize(""),
            {"words": 0, "chars": 0, "chars_no_ws": 0, "top": []},
        )

    def test_aggregate(self):
        result = summarize("the cat the")
        self.assertEqual(result["words"], 3)
        self.assertEqual(result["chars"], 11)
        self.assertEqual(result["chars_no_ws"], 9)
        self.assertEqual(result["top"], [("the", 2), ("cat", 1)])


if __name__ == "__main__":
    unittest.main()
