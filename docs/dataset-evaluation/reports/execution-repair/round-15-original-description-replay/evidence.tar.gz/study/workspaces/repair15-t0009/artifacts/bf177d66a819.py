"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_frequency, normalize, top_words, word_count  # noqa: E402


class TestNormalize(unittest.TestCase):
    def test_normalize_lowercases_and_strips(self):
        self.assertEqual(normalize("  Hello World  "), "hello world")

    def test_normalize_rejects_non_str(self):
        with self.assertRaises(TypeError):
            normalize(123)


class TestWordCount(unittest.TestCase):
    def test_word_count_basic(self):
        self.assertEqual(word_count("the quick brown fox"), 4)

    def test_word_count_empty(self):
        self.assertEqual(word_count(""), 0)
        self.assertEqual(word_count("   \t\n "), 0)

    def test_word_count_punctuation_only(self):
        self.assertEqual(word_count("!!! ... ???"), 0)

    def test_word_count_mixed_punctuation(self):
        self.assertEqual(word_count("Hello, world! It's fine."), 4)

    def test_word_count_rejects_non_str(self):
        with self.assertRaises(TypeError):
            word_count(None)


class TestCharFrequency(unittest.TestCase):
    def test_char_frequency_basic(self):
        self.assertEqual(char_frequency("aab"), {"a": 2, "b": 1})

    def test_char_frequency_ignores_punctuation_and_case(self):
        self.assertEqual(char_frequency("Aa, b!"), {"a": 2, "b": 1})

    def test_char_frequency_empty(self):
        self.assertEqual(char_frequency(""), {})
        self.assertEqual(char_frequency("  ,.! "), {})


class TestTopWords(unittest.TestCase):
    def test_top_words_basic(self):
        text = "the cat the dog the bird cat"
        self.assertEqual(top_words(text, 2), [("the", 3), ("cat", 2)])

    def test_top_words_tie_break_alphabetical(self):
        text = "banana apple cherry"
        self.assertEqual(
            top_words(text, 3),
            [("apple", 1), ("banana", 1), ("cherry", 1)],
        )

    def test_top_words_n_larger_than_distinct(self):
        self.assertEqual(top_words("one two", 10), [("one", 1), ("two", 1)])

    def test_top_words_n_bounds(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -5), [])

    def test_top_words_empty(self):
        self.assertEqual(top_words("", 3), [])

    def test_top_words_case_insensitive(self):
        self.assertEqual(top_words("Go go GO stop", 1), [("go", 3)])


if __name__ == "__main__":
    unittest.main()
