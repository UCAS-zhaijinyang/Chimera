"""Small text statistics helpers.

Bug (fixture variation 5): ``average_word_length`` divided by the number of
words *including* empty strings produced by splitting on whitespace runs,
which raised ZeroDivisionError for empty input and skewed the average for
inputs with leading/trailing whitespace.
"""

from __future__ import annotations


def average_word_length(text: str) -> float:
    """Return the average length of words in ``text``.

    Words are whitespace-separated tokens. Empty input (or input containing
    only whitespace) yields ``0.0`` instead of raising ``ZeroDivisionError``.
    """
    words = text.split()
    if not words:
        return 0.0
    return sum(len(word) for word in words) / len(words)
