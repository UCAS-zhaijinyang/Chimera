"""Small arithmetic helpers used by the reporting pipeline.

Fixture variation 4: the bug is in ``average`` -- it divides by the
number of *non-zero* values instead of the total number of values,
which produces wrong results whenever the input contains zeros.
"""

from __future__ import annotations

from typing import Iterable, List


def _as_list(values: Iterable[float]) -> List[float]:
    return [float(v) for v in values]


def total(values: Iterable[float]) -> float:
    """Return the sum of ``values``."""
    return sum(_as_list(values))


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises ``ValueError`` for an empty input.
    """
    items = _as_list(values)
    if not items:
        raise ValueError("average() requires at least one value")
    # BUG (fixed): previously divided by the count of non-zero items,
    # e.g. average([0, 2]) returned 2.0 instead of 1.0.
    return sum(items) / len(items)


def median(values: Iterable[float]) -> float:
    """Return the median of ``values``."""
    items = sorted(_as_list(values))
    if not items:
        raise ValueError("median() requires at least one value")
    mid = len(items) // 2
    if len(items) % 2:
        return items[mid]
    return (items[mid - 1] + items[mid]) / 2
