"""Unit tests for :mod:`stats_utils`."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stats_utils import summarize  # noqa: E402


class TestSummarize(unittest.TestCase):
    def test_basic_ints(self):
        result = summarize([1, 2, 3, 4])
        self.assertEqual(result["count"], 4)
        self.assertEqual(result["sum"], 10)
        self.assertEqual(result["mean"], 2.5)
        self.assertEqual(result["min"], 1)
        self.assertEqual(result["max"], 4)

    def test_floats_and_negatives(self):
        result = summarize([-1.5, 0.0, 2.5])
        self.assertEqual(result["count"], 3)
        self.assertAlmostEqual(result["sum"], 1.0)
        self.assertAlmostEqual(result["mean"], 1.0 / 3.0)
        self.assertEqual(result["min"], -1.5)
        self.assertEqual(result["max"], 2.5)

    def test_single_element(self):
        result = summarize([42])
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["sum"], 42)
        self.assertEqual(result["mean"], 42)
        self.assertEqual(result["min"], 42)
        self.assertEqual(result["max"], 42)

    def test_generator_input(self):
        result = summarize(x for x in (1, 2, 3))
        self.assertEqual(result["count"], 3)
        self.assertEqual(result["sum"], 6)
        self.assertEqual(result["mean"], 2)

    def test_tuple_input(self):
        result = summarize((5, 10))
        self.assertEqual(result["count"], 2)
        self.assertEqual(result["mean"], 7.5)

    def test_empty_raises_value_error(self):
        with self.assertRaises(ValueError):
            summarize([])

    def test_non_numeric_raises_type_error(self):
        with self.assertRaises(TypeError):
            summarize([1, "two", 3])

    def test_bool_rejected(self):
        with self.assertRaises(TypeError):
            summarize([True, False])


if __name__ == "__main__":
    unittest.main()
