"""Tiny descriptive-statistics helpers (standard library only).

Public API:
    mean(values)      -> float
    median(values)    -> float
    stdev(values)     -> float   (sample standard deviation, n-1 denominator)
    summarize(values) -> dict

All functions raise ValueError on invalid input (empty sequence, or fewer than
two values for stdev). Input sequences are never mutated.
"""

from __future__ import annotations

from typing import Sequence

__all__ = ["mean", "median", "stdev", "summarize"]


def _as_list(values: Sequence[float]) -> list:
    """Return a shallow copy of ``values`` as a list, validating non-emptiness."""
    data = list(values)
    if not data:
        raise ValueError("values must not be empty")
    return data


def mean(values: Sequence[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = _as_list(values)
    return sum(data) / len(data)


def median(values: Sequence[float]) -> float:
    """Return the median of ``values``.

    For an even number of values the average of the two middle values is
    returned. The input is not mutated.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = sorted(_as_list(values))
    n = len(data)
    mid = n // 2
    if n % 2 == 1:
        return float(data[mid])
    return (data[mid - 1] + data[mid]) / 2.0


def stdev(values: Sequence[float]) -> float:
    """Return the sample standard deviation of ``values`` (n-1 denominator).

    Raises:
        ValueError: if ``values`` has fewer than two elements.
    """
    data = _as_list(values)
    n = len(data)
    if n < 2:
        raise ValueError("stdev requires at least two values")
    mu = sum(data) / n
    variance = sum((x - mu) ** 2 for x in data) / (n - 1)
    return variance ** 0.5


def summarize(values: Sequence[float]) -> dict:
    """Return count/mean/median/stdev for ``values`` as a dict.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = _as_list(values)
    return {
        "count": len(data),
        "mean": mean(data),
        "median": median(data),
        "stdev": stdev(data),
    }
