"""Small utility for splitting a sequence into fixed-size batches."""

from typing import List, Sequence, TypeVar

T = TypeVar("T")


def chunk(items: Sequence[T], size: int) -> List[List[T]]:
    """Split ``items`` into consecutive batches of at most ``size`` elements.

    The final batch may be shorter than ``size`` when the length of ``items``
    is not an exact multiple of ``size``.

    Raises:
        ValueError: if ``size`` is not a positive integer.
    """
    if size <= 0:
        raise ValueError("size must be a positive integer")

    return [list(items[i:i + size]) for i in range(0, len(items), size)]
