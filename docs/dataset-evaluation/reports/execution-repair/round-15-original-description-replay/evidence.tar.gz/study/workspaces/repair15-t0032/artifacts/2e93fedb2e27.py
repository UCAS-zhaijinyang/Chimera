"""Pagination helper.

Provides a small utility to compute the number of pages needed to
display ``total`` items with a fixed ``page_size``.
"""

from __future__ import annotations


def paginate(total: int, page_size: int) -> int:
    """Return the number of pages required for ``total`` items.

    The page count is ``ceil(total / page_size)``. A total of zero
    items yields zero pages. Exact multiples of ``page_size`` must not
    produce a trailing empty page.

    Raises:
        ValueError: if ``total`` is negative or ``page_size`` is not
            positive.
    """
    if total < 0:
        raise ValueError("total must be non-negative")
    if page_size <= 0:
        raise ValueError("page_size must be positive")

    if total == 0:
        return 0

    # Integer ceiling division without floating point rounding issues.
    return (total + page_size - 1) // page_size
