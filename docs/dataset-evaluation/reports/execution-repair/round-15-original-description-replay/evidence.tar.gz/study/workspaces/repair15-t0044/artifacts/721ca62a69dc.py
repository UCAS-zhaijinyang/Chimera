"""Source package for the slugify feature."""
