def compute(a, b):
    """Return the maximum of two finite numeric inputs."""
    return max(a, b)
