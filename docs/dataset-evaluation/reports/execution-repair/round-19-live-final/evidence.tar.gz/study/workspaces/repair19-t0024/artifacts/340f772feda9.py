def compute(a, b):
    """Return the maximum of two finite numeric inputs."""
    return a if a >= b else b
