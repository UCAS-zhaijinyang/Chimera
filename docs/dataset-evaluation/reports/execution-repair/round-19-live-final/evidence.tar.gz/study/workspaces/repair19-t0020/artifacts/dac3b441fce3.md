# Design: compute(a, b) in src/restricted.py

## Goal
Provide a function `compute(a, b)` that returns the maximum of two finite numeric inputs.

## Interface
- Module: `src/restricted.py`
- Signature: `def compute(a, b):`
- Returns: the larger of `a` and `b` (numeric).
- Example: `compute(2, 3) == 3`.

## Behavior
- Supports zero, negative, and fractional values.
- Inputs are finite numeric values (int/float); no NaN/inf handling required.
- Ties return the same value (e.g., `compute(5, 5) == 5`).

## Implementation
Use a simple comparison: `return a if a >= b else b`. This avoids relying on
`max()` semantics beyond the stated requirement and is deterministic for ties.

## Verification
- Public behavioral check: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
- Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Risks
- Non-numeric inputs are out of scope per the ticket.
