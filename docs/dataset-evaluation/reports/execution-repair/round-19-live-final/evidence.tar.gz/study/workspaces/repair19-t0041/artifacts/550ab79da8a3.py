"""Core module for the compute feature."""


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative, and fractional values.
    """
    return a + b
