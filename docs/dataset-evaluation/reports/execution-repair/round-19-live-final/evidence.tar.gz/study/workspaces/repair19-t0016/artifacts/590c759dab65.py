"""Helper utilities for numeric computations."""


def mean_values(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    return (a + b) / 2
