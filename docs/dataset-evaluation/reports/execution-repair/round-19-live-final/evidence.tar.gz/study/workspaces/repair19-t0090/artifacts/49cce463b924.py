"""Main entry point re-exporting the restricted compute helper."""

from restricted import compute

__all__ = ["compute"]
