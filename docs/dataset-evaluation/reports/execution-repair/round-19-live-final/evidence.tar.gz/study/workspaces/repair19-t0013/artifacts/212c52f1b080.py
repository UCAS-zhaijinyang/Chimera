"""Core numeric utilities."""

import math
import numbers


def _validate(value, name):
    """Validate that value is a finite real number (bool excluded)."""
    if isinstance(value, bool) or not isinstance(value, numbers.Real):
        raise TypeError(f"{name} must be a real number, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    6
    >>> compute(-2, 3)
    -6
    >>> compute(0.5, 4)
    2.0
    """
    _validate(a, "a")
    _validate(b, "b")
    return a * b
