"""Entry point exposing compute from restricted."""

from restricted import compute

__all__ = ["compute"]
