"""Main entry point exposing compute."""

from restricted import compute

__all__ = ["compute"]
