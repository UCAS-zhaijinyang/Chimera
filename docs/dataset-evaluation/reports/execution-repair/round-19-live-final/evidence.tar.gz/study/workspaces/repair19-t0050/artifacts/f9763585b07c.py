"""Public entry point re-exporting compute from src.restricted."""

from src.restricted import compute

__all__ = ["compute"]
