"""Main module exposing compute(a, b)."""

try:
    from helper import mean_values
except ImportError:  # pragma: no cover - package-style import fallback
    from .helper import mean_values


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    return mean_values(a, b)
