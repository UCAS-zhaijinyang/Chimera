def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs."""
    return (a + b) / 2
