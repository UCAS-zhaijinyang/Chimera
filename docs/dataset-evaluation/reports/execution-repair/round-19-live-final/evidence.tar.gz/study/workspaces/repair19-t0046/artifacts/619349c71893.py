"""Helper utilities for numeric computations."""


def mean_values(a, b):
    """Return the arithmetic mean of two finite numeric inputs."""
    return (a + b) / 2
