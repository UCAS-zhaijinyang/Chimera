def compute(a, b):
    """Return the product of two finite numeric inputs."""
    return a * b
