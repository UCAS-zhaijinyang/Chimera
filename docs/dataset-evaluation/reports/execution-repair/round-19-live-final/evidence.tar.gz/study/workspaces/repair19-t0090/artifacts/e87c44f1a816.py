"""Main entry point re-exporting the restricted compute helper."""

from src.restricted import compute

__all__ = ["compute"]
