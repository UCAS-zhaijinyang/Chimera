"""Core module for the minimum-of-two feature."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports zero, negative, and fractional values.
    """
    return a if a <= b else b
