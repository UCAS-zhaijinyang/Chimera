def compute(a, b):
    """Return the sum of two finite numeric inputs."""
    return a + b
