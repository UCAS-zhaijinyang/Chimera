def compute(a, b):
    """Return the minimum of two finite numeric inputs."""
    return min(a, b)
