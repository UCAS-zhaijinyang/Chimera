"""Core module for the compute feature."""


def compute(a, b):
    """Return the difference of two finite numeric inputs (a - b)."""
    return a - b
