"""Compatibility shim exposing compute from src.restricted."""

from src.restricted import compute

__all__ = ["compute"]
