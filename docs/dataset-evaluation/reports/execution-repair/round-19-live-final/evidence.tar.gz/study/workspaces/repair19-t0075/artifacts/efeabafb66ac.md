# Design: compute(a, b) minimum of two finite numeric inputs

## Goal
Implement `compute(a, b)` in `src/main.py` returning the minimum of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b):`
- Returns: the smaller of `a` and `b` (a numeric value).
- Example: `compute(2, 3) == 2`.

## Behavior requirements
- Works for integers, floats, zero, negative values, and fractional values.
- Inputs are finite numeric values (no NaN/inf handling required).
- Comparison uses standard numeric ordering; ties return the value (either is equal).

## Implementation plan
- In `src/main.py`, define `compute(a, b)` returning `a if a <= b else b`.
- Keep the module importable with no side effects.

## Verification
- Public behavioral check: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
- Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Edge cases to cover
- `compute(2, 3) == 2`
- `compute(3, 2) == 2`
- `compute(0, 0) == 0`
- `compute(-5, -2) == -5`
- `compute(-1.5, 2.5) == -1.5`
- `compute(0.25, 0.5) == 0.25`
