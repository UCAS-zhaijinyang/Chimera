"""Restricted numeric utilities."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    return max(a, b)
