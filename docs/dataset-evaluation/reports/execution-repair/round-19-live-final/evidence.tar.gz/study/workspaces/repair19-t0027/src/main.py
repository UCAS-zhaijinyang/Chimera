def compute(a, b):
    return None
