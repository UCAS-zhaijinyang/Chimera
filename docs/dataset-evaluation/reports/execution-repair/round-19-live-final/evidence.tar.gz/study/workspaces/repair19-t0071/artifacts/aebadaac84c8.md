# Design: compute(a, b)

## Goal
Provide `compute(a, b)` in `src/main.py` returning the sum of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b):`
- Returns: `a + b`
- Accepts int and float values, including zero, negative, and fractional numbers.

## Behavior
- `compute(2, 3) == 5`
- `compute(0, 0) == 0`
- `compute(-4, 2) == -2`
- `compute(1.5, 2.25) == 3.75`

## Validation
- Public behavioral check: `python checks/public_check.py`
- Build: `python -m compileall -q src`

## Files
- `src/main.py`: implementation of `compute`.
