def compute(a, b):
    """Return the minimum of two finite numeric inputs."""
    return a if a <= b else b
