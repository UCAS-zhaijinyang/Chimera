"""Core numeric utilities."""


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative, and fractional values.
    """
    return a * b
