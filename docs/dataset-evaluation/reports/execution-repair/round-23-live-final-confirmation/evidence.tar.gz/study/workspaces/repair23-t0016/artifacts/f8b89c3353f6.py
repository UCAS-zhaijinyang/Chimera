"""Main module exposing compute(a, b)."""

from helper import mean_values


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    return mean_values(a, b)


if __name__ == "__main__":
    print(compute(2, 3))
