"""Core numeric helpers."""


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values, e.g. compute(2, 3) == 6.
    """
    return a * b
