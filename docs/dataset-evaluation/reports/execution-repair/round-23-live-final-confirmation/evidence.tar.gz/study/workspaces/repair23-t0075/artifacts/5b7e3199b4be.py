"""Core module for the minimum-of-two feature."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        2
        >>> compute(-1, -5)
        -5
        >>> compute(1.5, 1.25)
        1.25
    """
    return a if a <= b else b
