"""Restricted numeric helpers.

This module provides :func:`compute`, which returns the maximum of two
finite numeric inputs.
"""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        3
        >>> compute(-1, -5)
        -1
        >>> compute(0.5, 0.25)
        0.5
    """
    return a if a >= b else b
