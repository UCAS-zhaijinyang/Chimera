import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from restricted import compute


def main():
    assert compute(2, 3) == 3
    assert compute(3, 2) == 3
    assert compute(0, 0) == 0
    assert compute(0, 5) == 5
    assert compute(-4, -2) == -2
    assert compute(-2, -4) == -2
    assert compute(1.5, 1.25) == 1.5
    assert compute(1.25, 1.5) == 1.5
    assert compute(-1.5, 0.5) == 0.5
    print("public check passed")


if __name__ == "__main__":
    main()
