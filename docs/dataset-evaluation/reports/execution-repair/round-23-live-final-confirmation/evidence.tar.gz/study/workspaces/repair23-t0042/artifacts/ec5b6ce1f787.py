"""Core numeric utilities."""


def compute(a, b):
    """Return the difference of two finite numeric inputs (a - b).

    Supports zero, negative and fractional values.
    Example: compute(2, 3) == -1.
    """
    return a - b
