# Design: compute(a, b) maximum of two finite numeric inputs

## Goal
Define `compute(a, b)` in `src/restricted.py` returning the maximum of two finite numeric inputs.

## Interface
- Module: `src/restricted.py`
- Function: `compute(a, b)`
- Returns: the larger of `a` and `b` (numeric).
- Example: `compute(2, 3) == 3`.

## Behavior
- Supports zero, negative, and fractional values.
- Inputs are finite numeric values (int/float).
- Ties return the same value (e.g., `compute(2, 2) == 2`).

## Implementation
Use a simple comparison: `return a if a >= b else b`. This avoids relying on `max` shadowing and handles all numeric orderings including negatives and fractions.

## Verification
- Public behavioral check: `python checks/public_check.py`.
- Build: `python -m compileall -q src`.

## Files
- `src/restricted.py` (new): contains `compute`.
