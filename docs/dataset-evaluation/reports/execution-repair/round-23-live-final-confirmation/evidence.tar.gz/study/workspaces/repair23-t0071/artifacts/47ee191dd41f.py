"""Core numeric utilities."""

import math


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.
    Raises TypeError for non-numeric inputs and ValueError for non-finite ones.
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"expected a finite number, got {type(value).__name__}")
        if not math.isfinite(value):
            raise ValueError(f"expected a finite number, got {value!r}")
    return a + b
