"""Small text statistics utilities.

This module provides dependency-free helpers for counting word frequencies
over an iterable of string tokens.
"""

from __future__ import annotations

from typing import Iterable


def _normalize(token: str) -> str:
    """Normalize a single token: strip surrounding whitespace and lowercase."""
    if not isinstance(token, str):
        raise TypeError(
            f"expected str token, got {type(token).__name__}: {token!r}"
        )
    return token.strip().lower()


def word_frequencies(words: Iterable[str]) -> dict[str, int]:
    """Return a mapping of normalized word -> count.

    Empty/whitespace-only tokens are ignored. Insertion order of first-seen
    keys is preserved.
    """
    counts: dict[str, int] = {}
    for token in words:
        word = _normalize(token)
        if not word:
            continue
        counts[word] = counts.get(word, 0) + 1
    return counts


def top_words(words: Iterable[str], n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` tuples.

    Ties are broken by first-seen order (stable). ``n <= 0`` returns an empty
    list; ``n`` larger than the number of distinct words returns all words.
    """
    if n <= 0:
        return []
    counts = word_frequencies(words)
    ordered = sorted(counts.items(), key=lambda item: item[1], reverse=True)
    return ordered[:n]


def summarize(words: Iterable[str]) -> dict[str, object]:
    """Return ``{"total": int, "unique": int, "top": list[tuple[str, int]]}``."""
    counts = word_frequencies(words)
    total = sum(counts.values())
    return {
        "total": total,
        "unique": len(counts),
        "top": top_words(counts.keys(), 3),
    }
