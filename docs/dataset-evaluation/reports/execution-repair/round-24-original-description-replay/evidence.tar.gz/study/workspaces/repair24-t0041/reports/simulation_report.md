# Simulation Data Report

Fixture variation: 4

## Source
- Query: simulation data
- Source artifact: 75f24ea546c7
- Evidence level: simulation_only
- Business status: not_measured

## Transformed Data (grouped by week)
| Group | Count |
|-------|-------|
| W1    | 3     |
| W2    | 5     |

## Summary
- Total count across groups: 8
- Number of groups: 2
- Highest count: W2 (5)
- Lowest count: W1 (3)

## Notes
This report is based on simulated data only. Values are not measured business
results and should be treated as illustrative.
