"""Small statistics helpers.

Bug (variation 4): ``mean`` divided by ``len(values) - 1`` instead of
``len(values)``, producing an incorrect average. Fixed below.
"""

from typing import Iterable, List


def _as_list(values: Iterable[float]) -> List[float]:
    return list(values)


def mean(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises ``ValueError`` for an empty input.
    """
    data = _as_list(values)
    if not data:
        raise ValueError("mean() requires at least one value")
    return sum(data) / len(data)


def median(values: Iterable[float]) -> float:
    """Return the median of ``values`` (average of middle pair if even)."""
    data = sorted(_as_list(values))
    if not data:
        raise ValueError("median() requires at least one value")
    n = len(data)
    mid = n // 2
    if n % 2 == 1:
        return data[mid]
    return (data[mid - 1] + data[mid]) / 2


def variance(values: Iterable[float]) -> float:
    """Return the population variance of ``values``."""
    data = _as_list(values)
    if not data:
        raise ValueError("variance() requires at least one value")
    mu = mean(data)
    return sum((x - mu) ** 2 for x in data) / len(data)
