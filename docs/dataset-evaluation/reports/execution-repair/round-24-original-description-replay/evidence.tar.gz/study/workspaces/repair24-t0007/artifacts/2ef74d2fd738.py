"""Small text statistics utilities.

Pure, dependency-free helpers for counting words and characters and for
finding the most frequent words in a block of text.
"""

from __future__ import annotations

from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Empty or whitespace-only input returns ``0``.
    """
    return len(text.split())


def char_count(text: str, *, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in ``text``.

    When ``ignore_whitespace`` is true, whitespace characters are excluded.
    """
    if ignore_whitespace:
        return sum(1 for ch in text if not ch.isspace())
    return len(text)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent lowercased words as ``(word, count)``.

    Results are sorted by descending count, then alphabetically so that ties
    are deterministic. Raises ``ValueError`` if ``n < 1``.
    """
    if n < 1:
        raise ValueError("n must be >= 1")
    counts = Counter(word.lower() for word in text.split())
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return an aggregate summary of ``text``."""
    words = text.split()
    return {
        "words": len(words),
        "chars": len(text),
        "unique_words": len({word.lower() for word in words}),
        "top_words": top_words(text),
    }
