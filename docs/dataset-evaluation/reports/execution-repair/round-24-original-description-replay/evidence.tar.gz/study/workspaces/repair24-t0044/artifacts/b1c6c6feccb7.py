"""Tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from textstats import char_frequency, most_common_char, word_count  # noqa: E402


class TestWordCount:
    def test_normal_sentence(self):
        assert word_count("the quick brown fox") == 4

    def test_empty_string(self):
        assert word_count("") == 0

    def test_whitespace_only(self):
        assert word_count("   \t\n  ") == 0

    def test_multiple_spaces(self):
        assert word_count("a   b\tc\nd") == 4


class TestCharFrequency:
    def test_mixed_text(self):
        assert char_frequency("aab") == {"a": 2, "b": 1}

    def test_whitespace_ignored(self):
        assert char_frequency("a a\nb") == {"a": 2, "b": 1}

    def test_empty_input(self):
        assert char_frequency("") == {}

    def test_whitespace_only(self):
        assert char_frequency(" \t\n") == {}


class TestMostCommonChar:
    def test_clear_winner(self):
        assert most_common_char("aaabbc") == "a"

    def test_tie_broken_by_first_appearance(self):
        assert most_common_char("b a a b") == "b"

    def test_empty_returns_none(self):
        assert most_common_char("") is None

    def test_whitespace_only_returns_none(self):
        assert most_common_char("   \n") is None


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
