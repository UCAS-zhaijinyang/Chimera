"""Tests for :mod:`stats_utils`.

Runnable with pytest (``python -m pytest -q``) or the standard library
(``python -m unittest discover -s tests``).
"""

from __future__ import annotations

import math
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stats_utils import RunningStats, mean, median, stdev  # noqa: E402


class MeanTests(unittest.TestCase):
    def test_basic(self):
        self.assertAlmostEqual(mean([1, 2, 3, 4]), 2.5)

    def test_single(self):
        self.assertEqual(mean([7]), 7.0)

    def test_floats_and_negatives(self):
        self.assertAlmostEqual(mean([-1.5, 0.5, 2.0]), 1.0 / 3.0)

    def test_accepts_generator(self):
        self.assertAlmostEqual(mean(x for x in [2, 4, 6]), 4.0)

    def test_empty_raises(self):
        with self.assertRaises(ValueError):
            mean([])


class MedianTests(unittest.TestCase):
    def test_odd_length(self):
        self.assertEqual(median([3, 1, 2]), 2.0)

    def test_even_length(self):
        self.assertEqual(median([4, 1, 3, 2]), 2.5)

    def test_single(self):
        self.assertEqual(median([5]), 5.0)

    def test_unsorted_with_negatives(self):
        self.assertEqual(median([-5, 10, 0, 3]), 1.5)

    def test_empty_raises(self):
        with self.assertRaises(ValueError):
            median([])


class StdevTests(unittest.TestCase):
    def test_known_value(self):
        # population stdev of [2, 4, 4, 4, 5, 5, 7, 9] is 2.0
        self.assertAlmostEqual(stdev([2, 4, 4, 4, 5, 5, 7, 9]), 2.0)

    def test_identical_values(self):
        self.assertAlmostEqual(stdev([3, 3, 3]), 0.0)

    def test_two_values(self):
        self.assertAlmostEqual(stdev([0, 2]), 1.0)

    def test_too_few_raises(self):
        with self.assertRaises(ValueError):
            stdev([1])
        with self.assertRaises(ValueError):
            stdev([])


class RunningStatsTests(unittest.TestCase):
    def test_empty_defaults(self):
        rs = RunningStats()
        self.assertEqual(rs.count, 0)
        self.assertEqual(rs.mean, 0.0)
        self.assertEqual(rs.variance, 0.0)
        self.assertEqual(rs.stdev, 0.0)

    def test_single_value(self):
        rs = RunningStats().add(5)
        self.assertEqual(rs.count, 1)
        self.assertEqual(rs.mean, 5.0)
        self.assertEqual(rs.variance, 0.0)

    def test_matches_batch(self):
        data = [2, 4, 4, 4, 5, 5, 7, 9]
        rs = RunningStats().extend(data)
        self.assertEqual(rs.count, len(data))
        self.assertAlmostEqual(rs.mean, mean(data))
        self.assertAlmostEqual(rs.variance, stdev(data) ** 2)
        self.assertAlmostEqual(rs.stdev, stdev(data))

    def test_add_returns_self_for_chaining(self):
        rs = RunningStats()
        self.assertIs(rs.add(1), rs)

    def test_merge_matches_combined_batch(self):
        left = [1, 2, 3, 4]
        right = [10, 20, 30]
        a = RunningStats().extend(left)
        b = RunningStats().extend(right)
        a.merge(b)
        combined = left + right
        self.assertEqual(a.count, len(combined))
        self.assertAlmostEqual(a.mean, mean(combined))
        self.assertAlmostEqual(a.variance, stdev(combined) ** 2)

    def test_merge_into_empty(self):
        a = RunningStats()
        b = RunningStats().extend([1, 2, 3])
        a.merge(b)
        self.assertEqual(a.count, 3)
        self.assertAlmostEqual(a.mean, 2.0)

    def test_merge_with_empty_other(self):
        a = RunningStats().extend([1, 2, 3])
        a.merge(RunningStats())
        self.assertEqual(a.count, 3)
        self.assertAlmostEqual(a.mean, 2.0)

    def test_merge_type_error(self):
        with self.assertRaises(TypeError):
            RunningStats().merge([1, 2, 3])

    def test_numerical_stability_large_offset(self):
        data = [1e9 + i for i in range(100)]
        rs = RunningStats().extend(data)
        self.assertAlmostEqual(rs.mean, mean(data), places=6)
        self.assertAlmostEqual(rs.stdev, stdev(data), places=6)
        self.assertTrue(math.isfinite(rs.variance))


if __name__ == "__main__":
    unittest.main()
