"""Small arithmetic helpers used by the repair fixture.

The original implementation of :func:`average` divided by the number of
*values* instead of the number of *items*, which raised ``ZeroDivisionError``
for an empty input and produced wrong results whenever the caller passed a
non-empty iterable whose length differed from the count of values.  The fix
below validates the input and divides by the actual number of items.
"""

from __future__ import annotations

from typing import Iterable


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    items = list(values)
    if not items:
        raise ValueError("average() requires at least one value")
    return sum(items) / len(items)


def add(a: float, b: float) -> float:
    """Return the sum of ``a`` and ``b``."""
    return a + b


def divide(a: float, b: float) -> float:
    """Return ``a`` divided by ``b``.

    Raises:
        ZeroDivisionError: if ``b`` is zero.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b
