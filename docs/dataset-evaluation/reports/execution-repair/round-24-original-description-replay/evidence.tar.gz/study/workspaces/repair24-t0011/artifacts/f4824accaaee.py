"""Tests for src/textstats.py.

Runnable with pytest, or directly via ``python tests/test_textstats.py``.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from textstats import (  # noqa: E402
    char_frequency,
    normalize,
    summarize,
    top_words,
    word_count,
)


def test_normalize_case_and_whitespace():
    assert normalize("  Hello   World  ") == "hello world"
    assert normalize("A\tB\nC") == "a b c"


def test_normalize_empty():
    assert normalize("") == ""
    assert normalize("   \t\n ") == ""


def test_normalize_idempotent():
    sample = "  The   Quick  Brown Fox "
    assert normalize(normalize(sample)) == normalize(sample)


def test_normalize_type_error():
    try:
        normalize(123)  # type: ignore[arg-type]
    except TypeError:
        pass
    else:
        raise AssertionError("expected TypeError for non-str input")


def test_word_count():
    assert word_count("") == 0
    assert word_count("   ") == 0
    assert word_count("hello") == 1
    assert word_count("hello world") == 2
    assert word_count("  a   b\tc\nd ") == 4


def test_char_frequency_excludes_spaces_and_sorts():
    freq = char_frequency("a b a")
    assert freq == {"a": 2, "b": 1}
    assert list(freq.keys()) == sorted(freq.keys())


def test_char_frequency_empty():
    assert char_frequency("") == {}
    assert char_frequency("   ") == {}


def test_top_words_ordering_and_ties():
    text = "b a b c a b"
    assert top_words(text, 2) == [("b", 3), ("a", 2)]
    # tie on count -> alphabetical
    assert top_words("z y", 2) == [("y", 1), ("z", 1)]


def test_top_words_clamping_and_non_positive():
    assert top_words("one two three", 10) == [("one", 1), ("three", 1), ("two", 1)]
    assert top_words("one two three", 0) == []
    assert top_words("one two three", -5) == []
    assert top_words("", 3) == []


def test_summarize_consistency():
    text = "The cat and the hat"
    result = summarize(text)
    assert result["words"] == word_count(text) == 5
    assert result["unique_words"] == 4
    assert result["chars"] == sum(char_frequency(text).values())
    assert result["top"] == top_words(text)


def test_summarize_empty():
    assert summarize("") == {"words": 0, "unique_words": 0, "chars": 0, "top": []}


def _run_all():
    failures = 0
    for name, func in sorted(globals().items()):
        if name.startswith("test_") and callable(func):
            try:
                func()
            except Exception as exc:  # pragma: no cover - reporting path
                failures += 1
                print(f"FAIL {name}: {exc!r}")
            else:
                print(f"PASS {name}")
    if failures:
        raise SystemExit(f"{failures} test(s) failed")
    print("All tests passed.")


if __name__ == "__main__":
    _run_all()
