# Design Summary — Small Python Feature (Fixture Variation 1)

Source issue artifact: 28a0aec52aa9
Design artifact: f2a51482d960

## Feature
`src/textstats.py` — dependency-free text statistics helpers.

### Public API
- `word_count(text: str) -> int` — number of whitespace-separated tokens; `0` for empty/whitespace-only.
- `char_frequency(text: str) -> dict[str, int]` — counts of non-whitespace characters; `{}` for empty input.
- `most_common_char(text: str) -> str | None` — most frequent non-whitespace char, ties broken by first appearance; `None` when no non-whitespace chars.

## Files
- `src/textstats.py` — implementation.
- `tests/test_textstats.py` — pytest tests (imports via `sys.path` insertion of `src/`).
- `reports/design.md` — this summary.

## Verification
- Tests: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m pytest tests -q`
- Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Non-goals
No external dependencies, no I/O, no CLI, no packaging.
