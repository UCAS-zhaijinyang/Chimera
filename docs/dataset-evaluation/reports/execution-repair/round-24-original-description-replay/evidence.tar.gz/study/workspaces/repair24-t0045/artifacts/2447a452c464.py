"""Tests for src/stats_accumulator.py."""

import math

import pytest

from stats_accumulator import StatsAccumulator, mean_of


def test_empty_accumulator_basics():
    acc = StatsAccumulator()
    assert acc.count == 0
    assert len(acc) == 0
    assert acc.total == 0.0


@pytest.mark.parametrize(
    "accessor",
    [
        lambda a: a.mean,
        lambda a: a.min,
        lambda a: a.max,
        lambda a: a.variance(),
        lambda a: a.variance(sample=False),
        lambda a: a.stdev(),
    ],
)
def test_empty_accessors_raise_value_error(accessor):
    with pytest.raises(ValueError):
        accessor(StatsAccumulator())


def test_single_sample():
    acc = StatsAccumulator()
    acc.add(5)
    assert acc.count == 1
    assert acc.total == 5.0
    assert acc.mean == 5.0
    assert acc.min == 5.0
    assert acc.max == 5.0
    assert acc.variance(sample=False) == 0.0
    with pytest.raises(ValueError):
        acc.variance(sample=True)


def test_multiple_samples_known_values():
    acc = StatsAccumulator()
    for value in [2, 4, 4, 4, 5, 5, 7, 9]:
        acc.add(value)
    assert acc.count == 8
    assert acc.total == 40.0
    assert acc.mean == pytest.approx(5.0)
    assert acc.min == 2.0
    assert acc.max == 9.0


def test_sample_vs_population_variance():
    acc = StatsAccumulator()
    for value in [2, 4, 4, 4, 5, 5, 7, 9]:
        acc.add(value)
    assert acc.variance(sample=False) == pytest.approx(4.0)
    assert acc.variance(sample=True) == pytest.approx(32.0 / 7.0)


def test_stdev_matches_sqrt_variance():
    acc = StatsAccumulator()
    for value in [1, 2, 3, 4, 5]:
        acc.add(value)
    assert acc.stdev(sample=False) == pytest.approx(
        math.sqrt(acc.variance(sample=False))
    )
    assert acc.stdev(sample=True) == pytest.approx(
        math.sqrt(acc.variance(sample=True))
    )


@pytest.mark.parametrize("bad", ["x", None, True, False, [1], object()])
def test_non_numeric_input_raises_type_error(bad):
    acc = StatsAccumulator()
    with pytest.raises(TypeError):
        acc.add(bad)
    assert acc.count == 0


def test_reset_clears_state():
    acc = StatsAccumulator()
    acc.add(1)
    acc.add(2)
    acc.reset()
    assert acc.count == 0
    assert acc.total == 0.0
    with pytest.raises(ValueError):
        acc.mean


def test_mean_of_helper():
    assert mean_of([1, 2, 3, 4]) == pytest.approx(2.5)
    assert mean_of([]) if False else True  # placeholder guard
    with pytest.raises(ValueError):
        mean_of([])


def test_mean_of_accepts_generator():
    assert mean_of(x for x in [10, 20, 30]) == pytest.approx(20.0)
