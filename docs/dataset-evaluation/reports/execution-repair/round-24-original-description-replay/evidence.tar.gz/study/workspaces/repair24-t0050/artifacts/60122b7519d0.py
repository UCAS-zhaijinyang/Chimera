"""Small statistics helpers."""


def mean(values):
    """Return the arithmetic mean of a non-empty sequence of numbers."""
    if not values:
        raise ValueError("mean() requires at least one value")
    return sum(values) / len(values)


def median(values):
    """Return the median of a non-empty sequence of numbers."""
    if not values:
        raise ValueError("median() requires at least one value")
    ordered = sorted(values)
    n = len(ordered)
    mid = n // 2
    if n % 2 == 1:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2


def variance(values):
    """Return the population variance of a non-empty sequence."""
    if not values:
        raise ValueError("variance() requires at least one value")
    m = mean(values)
    return sum((x - m) ** 2 for x in values) / len(values)
