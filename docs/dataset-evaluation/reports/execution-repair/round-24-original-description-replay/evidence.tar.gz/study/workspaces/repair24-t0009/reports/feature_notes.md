# Feature Notes — textstats (fixture variation 2)

## Summary
Added a small, dependency-free text statistics module.

## Files
- `src/textstats.py` — `word_count`, `char_frequency`, `top_words`.
- `tests/test_textstats.py` — 14 unit tests (unittest, pytest-compatible).

## Behavior
- `word_count(text)`: whitespace-separated token count; empty/whitespace-only -> 0.
- `char_frequency(text)`: non-whitespace char counts, keys ordered by first appearance.
- `top_words(text, n=3)`: case-insensitive top-n words, lowercased, sorted by
  descending count then alphabetically; `n <= 0` -> `[]`.

## Verification
- Tests: `python -m unittest discover -s tests -v`
- Build: `python -m compileall -q src`

## Review Notes
- No external dependencies; deterministic outputs.
- Punctuation is intentionally not stripped (kept minimal per design).
