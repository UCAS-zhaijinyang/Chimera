"""Tests for :mod:`textstats`."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, summarize, top_words, word_count  # noqa: E402


# --- Happy path -----------------------------------------------------------


def test_word_count_basic():
    assert word_count("the quick brown fox") == 4


def test_word_count_handles_extra_whitespace():
    assert word_count("  the   quick\tbrown\nfox  ") == 4


def test_char_count_total_and_no_whitespace():
    assert char_count("abc def") == 7
    assert char_count("abc def", ignore_whitespace=True) == 6


def test_top_words_basic_ordering():
    assert top_words("a b a c a b", n=2) == [("a", 3), ("b", 2)]


def test_top_words_default_n_is_three():
    text = "a a a b b c d"
    assert top_words(text) == [("a", 3), ("b", 2), ("c", 1)]


def test_summarize_aggregate():
    text = "the cat the dog"
    assert summarize(text) == {
        "words": 4,
        "chars": 16,
        "chars_no_whitespace": 13,
        "top_words": [("the", 2), ("cat", 1), ("dog", 1)],
    }


# --- Edge / error cases ---------------------------------------------------


def test_empty_string():
    assert word_count("") == 0
    assert char_count("") == 0
    assert top_words("") == []
    assert summarize("") == {
        "words": 0,
        "chars": 0,
        "chars_no_whitespace": 0,
        "top_words": [],
    }


def test_whitespace_only_string():
    assert word_count("   \t\n ") == 0
    assert top_words("   \t\n ") == []


def test_punctuation_and_case_folding():
    assert top_words("Hello, hello! HELLO.") == [("hello", 3)]


def test_punctuation_only_tokens_are_dropped():
    assert top_words("... !!! ???") == []


def test_tie_break_is_alphabetical():
    assert top_words("b a c", n=3) == [("a", 1), ("b", 1), ("c", 1)]


def test_top_words_n_zero_returns_empty():
    assert top_words("a b c", n=0) == []


def test_top_words_negative_n_raises():
    with pytest.raises(ValueError):
        top_words("a b c", n=-1)


def test_non_str_input_raises_type_error():
    with pytest.raises(TypeError):
        word_count(123)
    with pytest.raises(TypeError):
        char_count(None)
    with pytest.raises(TypeError):
        top_words(["a", "b"])
    with pytest.raises(TypeError):
        summarize(3.14)


def test_top_words_non_int_n_raises_type_error():
    with pytest.raises(TypeError):
        top_words("a b c", n="2")
