"""Small utility package for the repair fixture (variation 3)."""

from .stats import mean, median, running_total

__all__ = ["mean", "median", "running_total"]
