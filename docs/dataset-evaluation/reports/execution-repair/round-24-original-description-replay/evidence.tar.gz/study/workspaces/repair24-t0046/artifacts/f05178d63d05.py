"""Tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import (  # noqa: E402
    char_frequency,
    most_common_char,
    normalize_whitespace,
    word_count,
)


class TestWordCount:
    def test_normal_sentence(self):
        assert word_count("the quick brown fox") == 4

    def test_empty_string(self):
        assert word_count("") == 0

    def test_whitespace_only(self):
        assert word_count("   \t\n  ") == 0

    def test_multiple_spaces(self):
        assert word_count("a   b\tc\nd") == 4

    def test_non_str_raises(self):
        with pytest.raises(TypeError):
            word_count(123)


class TestCharFrequency:
    def test_counts(self):
        assert char_frequency("aabbbc") == {"a": 2, "b": 3, "c": 1}

    def test_ignores_whitespace(self):
        assert char_frequency("a a\tb\nb") == {"a": 2, "b": 2}

    def test_insertion_order(self):
        assert list(char_frequency("cbaabc").keys()) == ["c", "b", "a"]

    def test_empty(self):
        assert char_frequency("") == {}

    def test_non_str_raises(self):
        with pytest.raises(TypeError):
            char_frequency(None)


class TestMostCommonChar:
    def test_most_frequent(self):
        assert most_common_char("aabbbc") == "b"

    def test_tie_break_first_appearance(self):
        assert most_common_char("abba") == "a"

    def test_none_for_empty(self):
        assert most_common_char("") is None

    def test_none_for_whitespace_only(self):
        assert most_common_char("   \t") is None

    def test_unicode(self):
        assert most_common_char("ééü") == "é"


class TestNormalizeWhitespace:
    def test_collapses_and_strips(self):
        assert normalize_whitespace("  hello \t world\n\n") == "hello world"

    def test_empty(self):
        assert normalize_whitespace("") == ""

    def test_whitespace_only(self):
        assert normalize_whitespace(" \t\n ") == ""

    def test_non_str_raises(self):
        with pytest.raises(TypeError):
            normalize_whitespace(["not", "a", "str"])
