"""Fixture package for repair task (variation 4)."""
