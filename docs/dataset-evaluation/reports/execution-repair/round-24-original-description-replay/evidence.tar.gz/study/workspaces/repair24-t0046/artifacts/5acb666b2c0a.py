"""Small text statistics helpers.

Self-contained utility module providing word counting, character frequency,
most-common-character lookup, and whitespace normalization.
"""

from __future__ import annotations

__all__ = [
    "word_count",
    "char_frequency",
    "most_common_char",
    "normalize_whitespace",
]


def _require_str(text: str) -> str:
    if not isinstance(text, str):
        raise TypeError(f"expected str, got {type(text).__name__}")
    return text


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Empty or whitespace-only input returns 0.
    """
    _require_str(text)
    return len(text.split())


def char_frequency(text: str) -> dict[str, int]:
    """Return a mapping of non-whitespace characters to their counts.

    Insertion order follows first appearance in ``text``.
    """
    _require_str(text)
    counts: dict[str, int] = {}
    for ch in text:
        if ch.isspace():
            continue
        counts[ch] = counts.get(ch, 0) + 1
    return counts


def most_common_char(text: str) -> str | None:
    """Return the most frequent non-whitespace character.

    Ties are broken by first appearance. Returns ``None`` when there are no
    non-whitespace characters.
    """
    counts = char_frequency(text)
    if not counts:
        return None
    best_char = None
    best_count = -1
    for ch, count in counts.items():
        if count > best_count:
            best_char = ch
            best_count = count
    return best_char


def normalize_whitespace(text: str) -> str:
    """Collapse runs of whitespace into single spaces and strip the ends."""
    _require_str(text)
    return " ".join(text.split())
