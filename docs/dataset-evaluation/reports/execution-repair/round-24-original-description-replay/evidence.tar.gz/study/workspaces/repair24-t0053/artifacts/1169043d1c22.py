import math

import pytest

from src.stats import mean, median, variance


def test_mean_basic():
    assert mean([1, 2, 3, 4]) == 2.5


def test_mean_single_value():
    assert mean([7]) == 7


def test_mean_empty_raises():
    with pytest.raises(ValueError):
        mean([])


def test_median_odd():
    assert median([3, 1, 2]) == 2


def test_median_even():
    assert median([4, 1, 3, 2]) == 2.5


def test_variance_population():
    assert variance([1, 2, 3, 4]) == pytest.approx(1.25)


def test_variance_constant_is_zero():
    assert math.isclose(variance([5, 5, 5]), 0.0)
