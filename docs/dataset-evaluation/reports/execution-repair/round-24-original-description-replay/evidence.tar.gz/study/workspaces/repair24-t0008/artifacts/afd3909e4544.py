"""Tests for :mod:`textstats`."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import summarize  # noqa: E402


def test_normal_input():
    result = summarize("Hello world\nHello there")
    assert result["chars"] == len("Hello world\nHello there")
    assert result["words"] == 4
    assert result["lines"] == 2
    assert result["unique_words"] == 3  # hello, world, there


def test_empty_string():
    assert summarize("") == {
        "chars": 0,
        "words": 0,
        "lines": 0,
        "unique_words": 0,
    }


def test_none_raises_type_error():
    with pytest.raises(TypeError):
        summarize(None)


def test_non_str_raises_type_error():
    with pytest.raises(TypeError):
        summarize(123)


def test_unique_words_case_insensitive():
    result = summarize("Apple apple APPLE banana")
    assert result["words"] == 4
    assert result["unique_words"] == 2  # apple, banana


def test_trailing_newline_does_not_add_line():
    assert summarize("a\nb\n")["lines"] == 2
    assert summarize("a\nb")["lines"] == 2


def test_blank_line_counts():
    assert summarize("a\n\nb")["lines"] == 3


def test_single_line_no_newline():
    assert summarize("just one line")["lines"] == 1
