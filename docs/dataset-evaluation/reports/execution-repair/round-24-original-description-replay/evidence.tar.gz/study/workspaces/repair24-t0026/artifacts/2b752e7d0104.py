"""Small text statistics utility.

Pure standard-library helpers for counting words/characters and finding the
most frequent words in a piece of text.
"""

from __future__ import annotations

from collections import Counter

__all__ = ["word_count", "char_count", "top_words"]


def _normalize(text: str) -> str:
    """Return ``text`` as a string, treating ``None`` as empty text."""
    if text is None:
        return ""
    return text


def word_count(text: str) -> int:
    """Return the number of whitespace-separated words in ``text``."""
    return len(_normalize(text).split())


def char_count(text: str) -> int:
    """Return the number of non-whitespace characters in ``text``."""
    return sum(1 for ch in _normalize(text) if not ch.isspace())


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent lowercased words.

    Results are sorted by descending count, then alphabetically for ties.
    ``n <= 0`` or empty input yields an empty list.
    """
    if n <= 0:
        return []
    words = _normalize(text).lower().split()
    if not words:
        return []
    counts = Counter(words)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]
