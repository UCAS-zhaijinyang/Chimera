"""Small calculator utilities used by the repair fixture.

The bug being fixed: ``average`` divided by the length of the input
sequence without guarding against an empty sequence, raising
``ZeroDivisionError`` instead of returning a sensible value.
"""

from __future__ import annotations

from typing import Iterable, List


def add(a: float, b: float) -> float:
    """Return the sum of ``a`` and ``b``."""
    return a + b


def subtract(a: float, b: float) -> float:
    """Return ``a`` minus ``b``."""
    return a - b


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    An empty input yields ``0.0`` rather than raising ``ZeroDivisionError``.
    """
    items: List[float] = list(values)
    if not items:
        return 0.0
    return sum(items) / len(items)
