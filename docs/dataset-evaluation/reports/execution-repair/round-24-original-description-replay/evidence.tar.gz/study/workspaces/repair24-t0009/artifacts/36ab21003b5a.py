"""Unit tests for src/textstats.py."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_frequency, top_words, word_count  # noqa: E402


class WordCountTests(unittest.TestCase):
    def test_empty_string(self):
        self.assertEqual(word_count(""), 0)

    def test_whitespace_only(self):
        self.assertEqual(word_count("   \t\n  "), 0)

    def test_single_word(self):
        self.assertEqual(word_count("hello"), 1)

    def test_multiple_words_irregular_spacing(self):
        self.assertEqual(word_count("  one   two\tthree\nfour "), 4)


class CharFrequencyTests(unittest.TestCase):
    def test_counts(self):
        self.assertEqual(char_frequency("aab"), {"a": 2, "b": 1})

    def test_whitespace_excluded(self):
        self.assertEqual(char_frequency("a b\tc"), {"a": 1, "b": 1, "c": 1})

    def test_deterministic_key_order(self):
        self.assertEqual(list(char_frequency("bca").keys()), ["b", "c", "a"])

    def test_empty(self):
        self.assertEqual(char_frequency(""), {})


class TopWordsTests(unittest.TestCase):
    def test_default_n(self):
        text = "a b b c c c d d d d"
        self.assertEqual(top_words(text), [("d", 4), ("c", 3), ("b", 2)])

    def test_tie_break_alphabetical(self):
        text = "beta alpha beta alpha gamma"
        self.assertEqual(top_words(text, 2), [("alpha", 2), ("beta", 2)])

    def test_case_insensitive(self):
        text = "Hello hello HELLO world"
        self.assertEqual(top_words(text, 1), [("hello", 3)])

    def test_n_non_positive(self):
        self.assertEqual(top_words("a b c", 0), [])
        self.assertEqual(top_words("a b c", -5), [])

    def test_n_larger_than_vocabulary(self):
        self.assertEqual(top_words("a b", 10), [("a", 1), ("b", 1)])

    def test_empty_text(self):
        self.assertEqual(top_words(""), [])


if __name__ == "__main__":
    unittest.main()
