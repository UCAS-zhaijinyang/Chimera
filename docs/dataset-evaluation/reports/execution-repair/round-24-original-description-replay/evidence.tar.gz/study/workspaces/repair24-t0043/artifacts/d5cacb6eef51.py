"""Lightweight, dependency-free text statistics utilities.

This module provides a small public API for computing basic statistics over
plain-text strings. All functions are deterministic and have no third-party
runtime dependencies.

Public API
----------
- :func:`word_count` -- count whitespace-separated tokens.
- :func:`char_count` -- count characters, optionally ignoring whitespace.
- :func:`top_words` -- most frequent normalized words, deterministically ordered.
- :func:`summarize` -- aggregate summary combining the above.
"""

from __future__ import annotations

import string
from collections import Counter

__all__ = ["word_count", "char_count", "top_words", "summarize"]

_PUNCTUATION = string.punctuation


def _require_str(text: object, name: str = "text") -> str:
    """Return ``text`` if it is a ``str``, otherwise raise ``TypeError``."""
    if not isinstance(text, str):
        raise TypeError(f"{name} must be a str, got {type(text).__name__}")
    return text


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Leading, trailing, and repeated whitespace are ignored.

    Raises:
        TypeError: If ``text`` is not a ``str``.
    """
    return len(_require_str(text).split())


def char_count(text: str, *, ignore_whitespace: bool = False) -> int:
    """Return the number of characters in ``text``.

    Args:
        text: The input string.
        ignore_whitespace: When ``True``, whitespace characters are excluded
            from the count.

    Raises:
        TypeError: If ``text`` is not a ``str``.
    """
    value = _require_str(text)
    if ignore_whitespace:
        return sum(1 for ch in value if not ch.isspace())
    return len(value)


def _normalize(token: str) -> str:
    """Lowercase ``token`` and strip surrounding punctuation."""
    return token.lower().strip(_PUNCTUATION)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent normalized words in ``text``.

    Words are lowercased and have surrounding punctuation stripped. Tokens that
    become empty after normalization are dropped. Ordering is deterministic:
    descending by count, then ascending alphabetically by word.

    Args:
        text: The input string.
        n: Maximum number of results to return. ``n == 0`` returns an empty
            list.

    Raises:
        TypeError: If ``text`` is not a ``str``.
        ValueError: If ``n`` is negative.
    """
    value = _require_str(text)
    if not isinstance(n, int) or isinstance(n, bool):
        raise TypeError(f"n must be an int, got {type(n).__name__}")
    if n < 0:
        raise ValueError("n must be non-negative")
    if n == 0:
        return []

    counts: Counter[str] = Counter()
    for token in value.split():
        normalized = _normalize(token)
        if normalized:
            counts[normalized] += 1

    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return an aggregate summary of ``text``.

    The returned mapping contains:
        - ``words``: number of whitespace-separated tokens.
        - ``chars``: total character count.
        - ``chars_no_whitespace``: character count excluding whitespace.
        - ``top_words``: the three most frequent normalized words.

    Raises:
        TypeError: If ``text`` is not a ``str``.
    """
    value = _require_str(text)
    return {
        "words": word_count(value),
        "chars": char_count(value),
        "chars_no_whitespace": char_count(value, ignore_whitespace=True),
        "top_words": top_words(value, n=3),
    }
