"""Small, dependency-free text statistics helpers.

Public API:
    word_count(text) -> int
    char_frequency(text) -> dict[str, int]
    most_common_char(text) -> str | None
"""

from __future__ import annotations


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Empty or whitespace-only input returns ``0``.
    """
    return len(text.split())


def char_frequency(text: str) -> dict[str, int]:
    """Return a mapping of each non-whitespace character to its count.

    Whitespace characters are ignored. Empty input returns ``{}``.
    """
    counts: dict[str, int] = {}
    for ch in text:
        if ch.isspace():
            continue
        counts[ch] = counts.get(ch, 0) + 1
    return counts


def most_common_char(text: str) -> str | None:
    """Return the most frequent non-whitespace character.

    Ties are broken by first appearance in ``text``. Returns ``None`` when
    there are no non-whitespace characters.
    """
    counts = char_frequency(text)
    if not counts:
        return None
    best: str | None = None
    best_count = -1
    for ch in text:
        if ch.isspace():
            continue
        count = counts[ch]
        if count > best_count:
            best = ch
            best_count = count
    return best
