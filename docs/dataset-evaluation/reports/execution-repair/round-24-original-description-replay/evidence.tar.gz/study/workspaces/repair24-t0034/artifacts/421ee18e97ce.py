"""Regression tests for src/stats.py (fixture variation 3)."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stats import mean, median, running_total  # noqa: E402


def test_mean_basic():
    assert mean([1, 2, 3, 4]) == 2.5


def test_mean_empty_raises():
    with pytest.raises(ValueError):
        mean([])


def test_median_odd():
    assert median([3, 1, 2]) == 2


def test_median_even_averages_middle_pair():
    # Regression: previously returned the upper middle element (3).
    assert median([1, 2, 3, 4]) == 2.5
    assert median([10, 2, 8, 4]) == 6.0


def test_median_empty_raises():
    with pytest.raises(ValueError):
        median([])


def test_running_total_values():
    assert running_total([1, 2, 3]) == [1.0, 3.0, 6.0]


def test_running_total_does_not_mutate_input():
    data = [1, 2, 3]
    running_total(data)
    assert data == [1, 2, 3]
