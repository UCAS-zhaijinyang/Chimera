"""Small self-contained text statistics utilities.

Pure standard-library module providing word counting, character frequency,
top-word extraction, and an aggregate summary.
"""

from __future__ import annotations

import re
from collections import Counter

_WORD_RE = re.compile(r"[a-z0-9]+")


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``."""
    if not text:
        return 0
    return len(text.split())


def char_frequency(text: str) -> dict[str, int]:
    """Return frequency of alphanumeric characters, lowercased.

    Whitespace and punctuation are ignored. The returned mapping is ordered
    by descending frequency then alphabetically for deterministic output.
    """
    if not text:
        return {}
    counts = Counter(ch for ch in text.lower() if ch.isalnum())
    return dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])))


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most common words as ``(word, count)`` pairs.

    Words are lowercased and stripped of punctuation. Ties are broken
    alphabetically. ``n <= 0`` yields an empty list.
    """
    if n <= 0 or not text:
        return []
    words = _WORD_RE.findall(text.lower())
    counts = Counter(words)
    ordered = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return an aggregate summary of ``text``."""
    return {
        "word_count": word_count(text),
        "char_frequency": char_frequency(text),
        "top_words": top_words(text),
    }
