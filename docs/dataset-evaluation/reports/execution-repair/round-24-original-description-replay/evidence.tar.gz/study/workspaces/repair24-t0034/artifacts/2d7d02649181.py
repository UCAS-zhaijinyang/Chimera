"""Simple statistics helpers.

Bug (variation 3): ``median`` returned the wrong value for even-length
sequences because it indexed the upper middle element instead of averaging
the two middle elements. ``running_total`` also mutated its input list.
"""

from __future__ import annotations

from typing import Iterable, List, Sequence


def mean(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises ``ValueError`` for an empty input.
    """
    items = list(values)
    if not items:
        raise ValueError("mean() requires at least one value")
    return sum(items) / len(items)


def median(values: Iterable[float]) -> float:
    """Return the median of ``values``.

    For an even number of values the median is the average of the two
    middle values. Raises ``ValueError`` for an empty input.
    """
    items = sorted(values)
    if not items:
        raise ValueError("median() requires at least one value")
    n = len(items)
    mid = n // 2
    if n % 2 == 1:
        return items[mid]
    return (items[mid - 1] + items[mid]) / 2


def running_total(values: Sequence[float]) -> List[float]:
    """Return the cumulative sums of ``values`` without mutating the input."""
    total = 0.0
    result: List[float] = []
    for value in values:
        total += value
        result.append(total)
    return result
