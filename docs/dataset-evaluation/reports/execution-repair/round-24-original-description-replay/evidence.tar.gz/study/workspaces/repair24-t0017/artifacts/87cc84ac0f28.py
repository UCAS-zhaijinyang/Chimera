"""Tests for the repaired arithmetic helpers."""

from __future__ import annotations

import pytest

from src.calculator import add, average


def test_add() -> None:
    assert add(2, 3) == 5
    assert add(-1, 1) == 0


def test_average_of_list() -> None:
    assert average([1, 2, 3, 4]) == 2.5


def test_average_of_generator() -> None:
    assert average(x for x in (2, 4, 6)) == 4.0


def test_average_of_tuple() -> None:
    assert average((10, 20)) == 15.0


def test_average_empty_raises_value_error() -> None:
    with pytest.raises(ValueError):
        average([])
