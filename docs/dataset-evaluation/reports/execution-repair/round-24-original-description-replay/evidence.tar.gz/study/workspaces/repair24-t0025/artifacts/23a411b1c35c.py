"""Small text statistics utility."""

from __future__ import annotations

__all__ = ["summarize"]


def summarize(text: str) -> dict:
    """Return basic statistics for ``text``.

    Returns a dict with keys:
        chars: number of characters (whitespace included)
        words: number of whitespace-separated tokens
        lines: number of lines (1 for the empty string)
        unique_words: number of distinct lowercased tokens

    Raises:
        TypeError: if ``text`` is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")

    tokens = text.split()
    lines = 1 if text == "" else len(text.split("\n"))

    return {
        "chars": len(text),
        "words": len(tokens),
        "lines": lines,
        "unique_words": len({token.lower() for token in tokens}),
    }
