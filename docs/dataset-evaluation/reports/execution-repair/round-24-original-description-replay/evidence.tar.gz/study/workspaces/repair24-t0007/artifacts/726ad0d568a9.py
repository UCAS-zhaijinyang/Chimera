"""Tests for src/textstats.py."""

import pytest

from textstats import char_count, summarize, top_words, word_count


def test_word_count_empty_and_whitespace():
    assert word_count("") == 0
    assert word_count("   \n\t ") == 0


def test_word_count_basic():
    assert word_count("hello world") == 2
    assert word_count("  one   two\tthree\nfour ") == 4


def test_char_count_basic():
    assert char_count("abc") == 3
    assert char_count("") == 0


def test_char_count_ignore_whitespace():
    assert char_count("a b\tc\n", ignore_whitespace=True) == 3
    assert char_count("a b\tc\n") == 6


def test_top_words_ordering_and_tie_break():
    text = "b a b c a d"
    assert top_words(text, 2) == [("a", 2), ("b", 2)]
    assert top_words(text, 3) == [("a", 2), ("b", 2), ("c", 1)]


def test_top_words_case_insensitive():
    assert top_words("Hello hello HELLO world", 1) == [("hello", 3)]


def test_top_words_default_n():
    text = "a b c d"
    assert top_words(text) == [("a", 1), ("b", 1), ("c", 1)]


def test_top_words_invalid_n():
    with pytest.raises(ValueError):
        top_words("a b c", 0)
    with pytest.raises(ValueError):
        top_words("a b c", -1)


def test_summarize_shape_and_values():
    text = "the cat the dog"
    result = summarize(text)
    assert result["words"] == 4
    assert result["chars"] == len(text)
    assert result["unique_words"] == 3
    assert result["top_words"] == [("the", 2), ("cat", 1), ("dog", 1)]


def test_summarize_empty():
    result = summarize("")
    assert result == {
        "words": 0,
        "chars": 0,
        "unique_words": 0,
        "top_words": [],
    }
