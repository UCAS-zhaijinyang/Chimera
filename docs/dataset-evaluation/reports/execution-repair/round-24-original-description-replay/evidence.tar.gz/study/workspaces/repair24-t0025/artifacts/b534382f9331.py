"""Tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import summarize  # noqa: E402


def test_empty_string():
    assert summarize("") == {
        "chars": 0,
        "words": 0,
        "lines": 1,
        "unique_words": 0,
    }


def test_single_line():
    assert summarize("hello world") == {
        "chars": 11,
        "words": 2,
        "lines": 1,
        "unique_words": 2,
    }


def test_multi_line():
    text = "first line\nsecond line\nthird"
    assert summarize(text) == {
        "chars": len(text),
        "words": 5,
        "lines": 3,
        "unique_words": 4,
    }


def test_case_and_punctuation():
    text = "Hello, hello! HELLO world"
    assert summarize(text) == {
        "chars": len(text),
        "words": 4,
        "lines": 1,
        "unique_words": 4,
    }


def test_whitespace_only():
    assert summarize("   \n\t ") == {
        "chars": 6,
        "words": 0,
        "lines": 2,
        "unique_words": 0,
    }


@pytest.mark.parametrize("bad", [None, 123, ["a"], b"bytes"])
def test_type_error(bad):
    with pytest.raises(TypeError):
        summarize(bad)
