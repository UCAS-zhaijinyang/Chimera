"""Small self-contained text statistics utilities.

Public API:
    word_count(text) -> int
    char_frequency(text) -> dict[str, int]
    top_words(text, n=3) -> list[tuple[str, int]]
"""

from __future__ import annotations

__all__ = ["word_count", "char_frequency", "top_words"]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``.

    Empty or whitespace-only input returns ``0``.
    """
    if not text:
        return 0
    return len(text.split())


def char_frequency(text: str) -> dict[str, int]:
    """Return a mapping of each non-whitespace character to its count.

    Keys are ordered by first appearance so the result is deterministic.
    """
    counts: dict[str, int] = {}
    for ch in text:
        if ch.isspace():
            continue
        counts[ch] = counts.get(ch, 0) + 1
    return counts


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` pairs.

    Matching is case-insensitive and output words are lowercased. Results are
    sorted by descending count, then alphabetically for ties. ``n <= 0``
    returns an empty list.
    """
    if n <= 0:
        return []

    counts: dict[str, int] = {}
    for token in text.split():
        word = token.lower()
        counts[word] = counts.get(word, 0) + 1

    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]
