import pytest

from src.stats import mean, median, stdev, variance


def test_mean_basic():
    assert mean([1, 2, 3, 4]) == 2.5


def test_mean_empty_raises():
    with pytest.raises(ValueError):
        mean([])


def test_median_odd():
    assert median([3, 1, 2]) == 2


def test_median_even():
    assert median([4, 1, 3, 2]) == 2.5


def test_median_empty_raises():
    with pytest.raises(ValueError):
        median([])


def test_variance_population():
    assert variance([2, 4, 4, 4, 5, 5, 7, 9]) == 4.0


def test_stdev_population():
    assert stdev([2, 4, 4, 4, 5, 5, 7, 9]) == 2.0


def test_variance_empty_raises():
    with pytest.raises(ValueError):
        variance([])
