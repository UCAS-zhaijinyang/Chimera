"""Small arithmetic helpers used by the repair fixture.

The bug being fixed: ``average`` divided by the number of *values* instead of
the number of *items*, so it raised ``ZeroDivisionError`` for an empty list and
returned a wrong result whenever the caller passed a non-list iterable whose
length differed from the number of consumed items.
"""

from __future__ import annotations

from typing import Iterable


def add(a: float, b: float) -> float:
    """Return the sum of ``a`` and ``b``."""
    return a + b


def average(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises ``ValueError`` when ``values`` is empty.
    """
    items = list(values)
    if not items:
        raise ValueError("average() requires at least one value")
    return sum(items) / len(items)
