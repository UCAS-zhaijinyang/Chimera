"""Tests for :mod:`src.calculator` covering the repaired ``average`` helper."""

from __future__ import annotations

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from calculator import add, average, divide  # noqa: E402


def test_average_of_ints():
    assert average([1, 2, 3, 4]) == 2.5


def test_average_of_single_value():
    assert average([7]) == 7


def test_average_accepts_generator():
    assert average(x for x in (2, 4, 6)) == 4


def test_average_of_empty_raises_value_error():
    with pytest.raises(ValueError):
        average([])


def test_add():
    assert add(2, 3) == 5


def test_divide():
    assert divide(9, 3) == 3


def test_divide_by_zero_raises():
    with pytest.raises(ZeroDivisionError):
        divide(1, 0)
