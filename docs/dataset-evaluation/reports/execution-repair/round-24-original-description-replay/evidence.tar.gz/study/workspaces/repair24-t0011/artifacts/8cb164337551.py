"""Small text statistics utility.

Self-contained, standard-library-only feature providing deterministic text
statistics: normalization, word counting, character frequency, top words and a
combined summary.
"""

from __future__ import annotations

__all__ = [
    "normalize",
    "word_count",
    "char_frequency",
    "top_words",
    "summarize",
]


def normalize(text: str) -> str:
    """Lowercase ``text`` and collapse all whitespace runs to single spaces.

    Leading and trailing whitespace is removed. The function is idempotent.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return " ".join(text.lower().split())


def word_count(text: str) -> int:
    """Return the number of whitespace-separated words after normalization."""
    normalized = normalize(text)
    if not normalized:
        return 0
    return len(normalized.split(" "))


def char_frequency(text: str) -> dict[str, int]:
    """Count characters after normalization, excluding spaces.

    Keys are returned in alphabetical order for deterministic output.
    """
    normalized = normalize(text)
    counts: dict[str, int] = {}
    for char in normalized:
        if char == " ":
            continue
        counts[char] = counts.get(char, 0) + 1
    return {char: counts[char] for char in sorted(counts)}


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` pairs.

    Ordering is by count descending, then word ascending. ``n <= 0`` yields an
    empty list, and the result never exceeds the number of distinct words.
    """
    if n <= 0:
        return []
    normalized = normalize(text)
    if not normalized:
        return []
    counts: dict[str, int] = {}
    for word in normalized.split(" "):
        counts[word] = counts.get(word, 0) + 1
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict:
    """Return aggregate statistics for ``text``.

    Keys: ``words``, ``unique_words``, ``chars`` (excluding spaces) and ``top``.
    """
    normalized = normalize(text)
    words = normalized.split(" ") if normalized else []
    return {
        "words": len(words),
        "unique_words": len(set(words)),
        "chars": sum(char_frequency(normalized).values()),
        "top": top_words(normalized),
    }
