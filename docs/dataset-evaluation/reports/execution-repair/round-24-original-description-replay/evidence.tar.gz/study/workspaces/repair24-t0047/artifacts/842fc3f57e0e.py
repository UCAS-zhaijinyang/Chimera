"""Small self-contained text statistics utilities.

Public API:
    word_frequencies(text) -> dict[str, int]
    top_words(text, n=3) -> list[tuple[str, int]]
    summarize(text) -> dict[str, object]
"""

from __future__ import annotations

import re
from collections import Counter

__all__ = ["word_frequencies", "top_words", "summarize"]

_TOKEN_RE = re.compile(r"[a-z0-9']+")


def _tokenize(text: str) -> list[str]:
    """Lowercase ``text`` and return the list of word tokens."""
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    return _TOKEN_RE.findall(text.lower())


def word_frequencies(text: str) -> dict[str, int]:
    """Return a mapping of word token -> occurrence count.

    Tokens are lowercased and matched with ``[a-z0-9']+``. Empty or
    whitespace-only input yields an empty dict.
    """
    return dict(Counter(_tokenize(text)))


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` tuples.

    Results are ordered by descending count, then alphabetically ascending
    for ties. ``n <= 0`` returns an empty list.
    """
    if n <= 0:
        return []
    counts = word_frequencies(text)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def summarize(text: str) -> dict[str, object]:
    """Return a summary dict for ``text``.

    Keys: ``word_count`` (total tokens), ``unique_words`` (distinct tokens),
    ``top_words`` (list of ``(word, count)`` tuples).
    """
    tokens = _tokenize(text)
    counts = Counter(tokens)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return {
        "word_count": len(tokens),
        "unique_words": len(counts),
        "top_words": ordered[:3],
    }
