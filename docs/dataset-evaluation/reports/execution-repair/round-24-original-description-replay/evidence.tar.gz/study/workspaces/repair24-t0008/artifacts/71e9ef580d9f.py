"""Small text statistics utility.

Provides :func:`summarize`, which returns basic statistics about a string.
"""

from __future__ import annotations

__all__ = ["summarize"]


def summarize(text: str) -> dict:
    """Return basic statistics for ``text``.

    Parameters
    ----------
    text:
        The text to analyze. Must be a ``str``.

    Returns
    -------
    dict
        A mapping with the keys ``chars``, ``words``, ``lines`` and
        ``unique_words``.

    Raises
    ------
    TypeError
        If ``text`` is not a ``str``.
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be str, got {type(text).__name__}")

    if text == "":
        return {"chars": 0, "words": 0, "lines": 0, "unique_words": 0}

    words = text.split()
    lines = text.count("\n") + (0 if text.endswith("\n") else 1)
    unique_words = len({word.lower() for word in words})

    return {
        "chars": len(text),
        "words": len(words),
        "lines": lines,
        "unique_words": unique_words,
    }
