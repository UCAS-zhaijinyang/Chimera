"""Tests for the calculator repair fixture."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from calculator import add, average, subtract  # noqa: E402


def test_add():
    assert add(2, 3) == 5


def test_subtract():
    assert subtract(5, 3) == 2


def test_average_basic():
    assert average([1, 2, 3, 4]) == 2.5


def test_average_empty_returns_zero():
    # Regression: previously raised ZeroDivisionError.
    assert average([]) == 0.0


def test_average_accepts_generator():
    assert average(x for x in (2, 4, 6)) == 4.0
