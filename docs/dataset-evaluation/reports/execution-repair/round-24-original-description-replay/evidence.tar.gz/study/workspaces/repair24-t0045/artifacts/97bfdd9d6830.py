"""Running statistics accumulator.

A small, self-contained feature providing incremental statistics over a
stream of numeric samples. No third-party dependencies.
"""

from __future__ import annotations

import math
from typing import Iterable, List

__all__ = ["StatsAccumulator", "mean_of"]


def _validate(value: float) -> float:
    """Return ``value`` as a float, rejecting non-numeric and bool inputs."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(
            f"value must be a real number, got {type(value).__name__!r}"
        )
    return float(value)


class StatsAccumulator:
    """Accumulate numeric samples and expose running statistics."""

    def __init__(self) -> None:
        self._values: List[float] = []

    # -- mutation ---------------------------------------------------------
    def add(self, value: float) -> None:
        """Add a numeric sample to the accumulator."""
        self._values.append(_validate(value))

    def reset(self) -> None:
        """Remove all samples."""
        self._values.clear()

    # -- basic accessors --------------------------------------------------
    @property
    def count(self) -> int:
        return len(self._values)

    @property
    def total(self) -> float:
        return float(sum(self._values))

    @property
    def mean(self) -> float:
        if not self._values:
            raise ValueError("mean is undefined for an empty accumulator")
        return self.total / self.count

    @property
    def min(self) -> float:
        if not self._values:
            raise ValueError("min is undefined for an empty accumulator")
        return min(self._values)

    @property
    def max(self) -> float:
        if not self._values:
            raise ValueError("max is undefined for an empty accumulator")
        return max(self._values)

    # -- dispersion -------------------------------------------------------
    def variance(self, sample: bool = True) -> float:
        """Return the variance of the samples.

        ``sample=True`` (default) uses the unbiased n-1 denominator;
        ``sample=False`` uses the population n denominator.
        """
        n = self.count
        if sample:
            if n < 2:
                raise ValueError(
                    "sample variance requires at least two samples"
                )
            denominator = n - 1
        else:
            if n < 1:
                raise ValueError(
                    "population variance requires at least one sample"
                )
            denominator = n

        mu = self.mean
        return sum((x - mu) ** 2 for x in self._values) / denominator

    def stdev(self, sample: bool = True) -> float:
        """Return the standard deviation of the samples."""
        return math.sqrt(self.variance(sample=sample))

    # -- dunder -----------------------------------------------------------
    def __len__(self) -> int:
        return self.count

    def __repr__(self) -> str:  # pragma: no cover - trivial
        return f"StatsAccumulator(count={self.count}, total={self.total!r})"


def mean_of(values: Iterable[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises ``ValueError`` when ``values`` is empty.
    """
    acc = StatsAccumulator()
    for value in values:
        acc.add(value)
    return acc.mean
