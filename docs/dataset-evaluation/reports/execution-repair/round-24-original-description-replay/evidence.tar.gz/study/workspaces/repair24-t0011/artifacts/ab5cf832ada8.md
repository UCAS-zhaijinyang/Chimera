# Design Document — Small Python Feature (fixture variation 4)

## 1. Objective
Implement a small, self-contained Python feature under `src/`, with tests, a successful
build via Python bytecode compilation, and a simulated review.

## 2. Feature Selection
Feature: **`TextStats`** — a small text statistics utility.

Rationale: self-contained, deterministic, no third-party dependencies, easy to test
exhaustively, and small enough to fit a single module.

## 3. Module Layout
```
src/
  textstats.py        # feature implementation
tests/
  test_textstats.py   # unit tests
reports/
  design.md           # this document (business copy)
```

## 4. Public API
`src/textstats.py` exposes:

- `normalize(text: str) -> str`
  - Lowercases, strips leading/trailing whitespace, and collapses internal
    whitespace runs to a single space.
- `word_count(text: str) -> int`
  - Number of whitespace-separated tokens after normalization; `0` for empty input.
- `char_frequency(text: str) -> dict[str, int]`
  - Counts characters after normalization, excluding spaces; keys sorted
    alphabetically for deterministic output.
- `top_words(text: str, n: int = 3) -> list[tuple[str, int]]`
  - Most frequent words after normalization, sorted by count descending then
    word ascending; ties broken deterministically. `n <= 0` returns `[]`.
- `summarize(text: str) -> dict`
  - Returns `{"words": int, "unique_words": int, "chars": int, "top": list}`.

## 5. Behavior Rules
1. `normalize` is idempotent: `normalize(normalize(t)) == normalize(t)`.
2. All functions accept `str`; empty/whitespace-only input yields zero counts and
   empty collections rather than raising.
3. `top_words` never returns more than `n` entries and never more than the number
   of distinct words.
4. Output ordering is deterministic (no reliance on dict/set iteration order).

## 6. Test Plan
`tests/test_textstats.py` (pytest-style, also runnable via plain asserts):
- normalize: case folding, whitespace collapsing, idempotence, empty input.
- word_count: empty, single word, multiple words, extra whitespace.
- char_frequency: excludes spaces, counts repeats, sorted keys, empty input.
- top_words: ordering by count then alphabetically, `n` clamping, `n <= 0`.
- summarize: consistent aggregate values against the individual functions.

## 7. Build
Default build command (bytecode compilation):
```
/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src
```
Success = exit code 0 with no syntax errors.

## 8. Constraints
- No writes to `artifacts/`, `manifest.jsonl`, `manifest.lock`, or `execution.log`.
- Business files only under `reports/`, `shared/`, or `src/`.
- No third-party dependencies; standard library only.
- Do not invent requirements beyond the ticket scope.

## 9. Review Checklist
- [ ] Feature module present under `src/` and compiles.
- [ ] Tests present and passing.
- [ ] Build command exits 0.
- [ ] Deterministic outputs verified by tests.
