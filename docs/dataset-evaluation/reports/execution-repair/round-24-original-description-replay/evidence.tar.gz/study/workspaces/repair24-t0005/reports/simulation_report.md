# Simulation Data Report — Fixture Variation 4

## Source
- Query: simulation data report fixture variation 4
- Evidence level: simulation_only
- Business status: not_measured

## Transformed Data (grouped by week)
| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Summary
- Total count across weeks: 8
- Weeks observed: 2 (W1, W2)
- Highest week: W2 with 5

## Notes
This report is based on simulated data only. Values are not measured business
results and should not be treated as production metrics.
