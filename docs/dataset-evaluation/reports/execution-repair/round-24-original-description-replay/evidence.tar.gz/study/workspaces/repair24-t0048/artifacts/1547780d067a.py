"""Small text statistics utilities.

Provides tokenization and word-frequency helpers used by the feature
described in the design document.
"""

from __future__ import annotations

__all__ = [
    "normalize",
    "word_counts",
    "top_words",
    "unique_word_count",
]


def normalize(text: str) -> list[str]:
    """Split ``text`` into lowercase alphanumeric tokens.

    Any character that is not alphanumeric acts as a separator. The order of
    tokens is preserved. Non-string input raises ``TypeError``.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")

    tokens: list[str] = []
    current: list[str] = []
    for ch in text:
        if ch.isalnum():
            current.append(ch.lower())
        elif current:
            tokens.append("".join(current))
            current = []
    if current:
        tokens.append("".join(current))
    return tokens


def word_counts(text: str) -> dict[str, int]:
    """Return a token -> count mapping in first-seen order."""
    counts: dict[str, int] = {}
    for token in normalize(text):
        counts[token] = counts.get(token, 0) + 1
    return counts


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent tokens as ``(token, count)`` tuples.

    Ties are broken by first appearance order, then alphabetically for
    determinism. ``n <= 0`` yields an empty list; ``n`` larger than the number
    of distinct tokens simply returns all of them.
    """
    if not isinstance(n, int) or isinstance(n, bool):
        raise TypeError("n must be an int")
    if n <= 0:
        return []

    counts = word_counts(text)
    first_seen = {token: index for index, token in enumerate(counts)}
    ordered = sorted(
        counts.items(),
        key=lambda item: (-item[1], first_seen[item[0]], item[0]),
    )
    return ordered[:n]


def unique_word_count(text: str) -> int:
    """Return the number of distinct tokens in ``text``."""
    return len(word_counts(text))
