"""Tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import summarize, top_words, word_frequencies  # noqa: E402


def test_word_frequencies_basic():
    assert word_frequencies("the cat the dog") == {"the": 2, "cat": 1, "dog": 1}


def test_word_frequencies_case_insensitive():
    assert word_frequencies("The THE tHe") == {"the": 3}


def test_word_frequencies_punctuation():
    assert word_frequencies("Hello, world! Hello...") == {"hello": 2, "world": 1}


def test_word_frequencies_empty():
    assert word_frequencies("") == {}
    assert word_frequencies("   \n\t ") == {}


def test_word_frequencies_type_error():
    with pytest.raises(TypeError):
        word_frequencies(None)


def test_top_words_ordering():
    text = "a b b c c c"
    assert top_words(text, 2) == [("c", 3), ("b", 2)]


def test_top_words_tie_break_alphabetical():
    text = "b a c"
    assert top_words(text, 3) == [("a", 1), ("b", 1), ("c", 1)]


def test_top_words_n_larger_than_vocab():
    assert top_words("a b", 10) == [("a", 1), ("b", 1)]


def test_top_words_non_positive_n():
    assert top_words("a b c", 0) == []
    assert top_words("a b c", -5) == []


def test_top_words_default_n():
    text = "a a a b b c d"
    assert top_words(text) == [("a", 3), ("b", 2), ("c", 1)]


def test_summarize():
    text = "one two two three three three"
    result = summarize(text)
    assert result["word_count"] == 6
    assert result["unique_words"] == 3
    assert result["top_words"] == [("three", 3), ("two", 2), ("one", 1)]


def test_summarize_empty():
    result = summarize("")
    assert result["word_count"] == 0
    assert result["unique_words"] == 0
    assert result["top_words"] == []
