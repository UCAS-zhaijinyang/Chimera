# Simulation Data Report — Fixture Variation 5

## Source
- Query: simulation data fixture variation 5
- Input artifact: d87f0c9ecf71
- Transformed artifact: 2f9556156f3a
- Evidence level: simulation_only (not measured)

## Transformed Data (grouped by week)
| Group | Count |
|-------|-------|
| W1    | 3     |
| W2    | 5     |

## Summary
- Total count across groups: 8
- Number of groups: 2
- Highest count: W2 (5)
- Lowest count: W1 (3)

## Notes
This report is based on simulated fixture data only. Values are not measured
business results and should not be used for operational decisions.
