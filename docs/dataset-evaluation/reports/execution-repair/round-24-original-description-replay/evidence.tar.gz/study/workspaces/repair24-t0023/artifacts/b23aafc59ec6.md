# Simulation Data Report — Fixture Variation 4

## Source
- Query: simulation data fixture variation 4
- Source artifact: 0febf2f83334
- Transformed artifact: 0885902ca018
- Evidence level: simulation_only
- Business status: not_measured

## Raw Data
| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Transformed Data (grouped by week)
| Group | Count |
|-------|-------|
| W1    | 3     |
| W2    | 5     |

## Summary
- Total count across weeks: 8
- Weeks observed: 2 (W1, W2)
- Week-over-week change: +2 (from 3 to 5)

## Notes
This report is based on simulated fixture data only. Values are not measured
business results and should be treated as illustrative.
