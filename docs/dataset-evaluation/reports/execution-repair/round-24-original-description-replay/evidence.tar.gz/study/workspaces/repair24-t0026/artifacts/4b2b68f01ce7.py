"""Tests for the text statistics utility."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import char_count, top_words, word_count  # noqa: E402


class TestWordCount:
    def test_simple_sentence(self):
        assert word_count("the quick brown fox") == 4

    def test_extra_whitespace(self):
        assert word_count("  hello   world \n\t") == 2

    def test_empty_string(self):
        assert word_count("") == 0

    def test_whitespace_only(self):
        assert word_count("   \n\t ") == 0

    def test_none_is_treated_as_empty(self):
        assert word_count(None) == 0


class TestCharCount:
    def test_excludes_whitespace(self):
        assert char_count("a b c") == 3

    def test_newlines_and_tabs(self):
        assert char_count("ab\ncd\tef") == 6

    def test_empty_string(self):
        assert char_count("") == 0

    def test_none_is_treated_as_empty(self):
        assert char_count(None) == 0


class TestTopWords:
    def test_default_n(self):
        text = "a b b c c c d d d d"
        assert top_words(text) == [("d", 4), ("c", 3), ("b", 2)]

    def test_case_insensitive(self):
        assert top_words("The the THE cat", n=2) == [("the", 3), ("cat", 1)]

    def test_tie_break_alphabetical(self):
        assert top_words("b a c", n=3) == [("a", 1), ("b", 1), ("c", 1)]

    def test_n_larger_than_unique(self):
        assert top_words("one two", n=10) == [("one", 1), ("two", 1)]

    def test_n_zero(self):
        assert top_words("a b c", n=0) == []

    def test_n_negative(self):
        assert top_words("a b c", n=-5) == []

    def test_empty_string(self):
        assert top_words("") == []

    def test_none_is_treated_as_empty(self):
        assert top_words(None) == []


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
