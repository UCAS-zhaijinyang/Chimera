"""Tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import (  # noqa: E402
    normalize,
    top_words,
    unique_word_count,
    word_counts,
)


def test_normalize_basic():
    assert normalize("Hello, World!") == ["hello", "world"]


def test_normalize_preserves_order_and_splits_punctuation():
    assert normalize("a-b_c.d") == ["a", "b", "c", "d"]


def test_normalize_empty_and_punctuation_only():
    assert normalize("") == []
    assert normalize("   ") == []
    assert normalize("!!! ... ???") == []


def test_normalize_unicode_alnum():
    assert normalize("Café déjà") == ["café", "déjà"]


def test_normalize_rejects_non_str():
    with pytest.raises(TypeError):
        normalize(123)


def test_word_counts_case_insensitive():
    assert word_counts("The the THE") == {"the": 3}


def test_word_counts_first_seen_order():
    counts = word_counts("b a b c a b")
    assert list(counts.keys()) == ["b", "a", "c"]
    assert counts == {"b": 3, "a": 2, "c": 1}


def test_word_counts_empty():
    assert word_counts("") == {}


def test_top_words_default_n():
    assert top_words("a b a c a b") == [("a", 3), ("b", 2), ("c", 1)]


def test_top_words_tie_break_by_first_appearance():
    assert top_words("x y z", n=2) == [("x", 1), ("y", 1)]


def test_top_words_n_zero_or_negative():
    assert top_words("a b c", n=0) == []
    assert top_words("a b c", n=-5) == []


def test_top_words_n_larger_than_distinct():
    assert top_words("a b", n=10) == [("a", 1), ("b", 1)]


def test_top_words_rejects_bad_n():
    with pytest.raises(TypeError):
        top_words("a b", n="2")


def test_unique_word_count():
    assert unique_word_count("a b a c") == 3
    assert unique_word_count("") == 0
