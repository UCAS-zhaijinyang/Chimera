"""Tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from textstats import (  # noqa: E402
    char_frequency,
    most_common_words,
    normalize_whitespace,
    word_count,
)


class TestWordCount:
    def test_normal_sentence(self):
        assert word_count("the quick brown fox") == 4

    def test_empty_string(self):
        assert word_count("") == 0

    def test_whitespace_only(self):
        assert word_count("   \t\n  ") == 0

    def test_extra_whitespace(self):
        assert word_count("  a   b\tc\n") == 3


class TestCharFrequency:
    def test_counts(self):
        assert char_frequency("aab") == {"a": 2, "b": 1}

    def test_ignores_whitespace(self):
        assert char_frequency("a a\nb") == {"a": 2, "b": 1}

    def test_preserves_case(self):
        assert char_frequency("aA") == {"a": 1, "A": 1}

    def test_empty(self):
        assert char_frequency("") == {}


class TestMostCommonWords:
    def test_ordering(self):
        text = "b b b a a c"
        assert most_common_words(text, 2) == [("b", 3), ("a", 2)]

    def test_tie_break_alphabetical(self):
        text = "b a c"
        assert most_common_words(text, 3) == [("a", 1), ("b", 1), ("c", 1)]

    def test_case_insensitive(self):
        text = "The the THE cat"
        assert most_common_words(text, 1) == [("the", 3)]

    def test_n_larger_than_vocabulary(self):
        assert most_common_words("a b", 10) == [("a", 1), ("b", 1)]

    def test_n_non_positive(self):
        assert most_common_words("a b c", 0) == []
        assert most_common_words("a b c", -1) == []

    def test_empty_text(self):
        assert most_common_words("", 3) == []

    def test_default_n(self):
        text = "a a a b b c d"
        assert most_common_words(text) == [("a", 3), ("b", 2), ("c", 1)]


class TestNormalizeWhitespace:
    def test_collapses_and_strips(self):
        assert normalize_whitespace("  hello \t world \n") == "hello world"

    def test_empty(self):
        assert normalize_whitespace("   ") == ""

    def test_already_normalized(self):
        assert normalize_whitespace("a b c") == "a b c"


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
