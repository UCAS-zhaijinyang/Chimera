"""Small, dependency-free running statistics helpers.

Provides batch helpers (:func:`mean`, :func:`median`, :func:`stdev`) and an
incremental accumulator (:class:`RunningStats`) implemented with Welford's
online algorithm for numerical stability.
"""

from __future__ import annotations

import math
from typing import Iterable, Sequence

__all__ = ["mean", "median", "stdev", "RunningStats"]


def _as_list(values: Iterable[float]) -> list[float]:
    """Materialize ``values`` into a list of floats."""
    return [float(v) for v in values]


def mean(values: Sequence[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = _as_list(values)
    if not data:
        raise ValueError("mean() requires at least one value")
    return sum(data) / len(data)


def median(values: Sequence[float]) -> float:
    """Return the median of ``values``.

    For an even number of values the average of the two middle values is
    returned.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = sorted(_as_list(values))
    if not data:
        raise ValueError("median() requires at least one value")
    n = len(data)
    mid = n // 2
    if n % 2 == 1:
        return data[mid]
    return (data[mid - 1] + data[mid]) / 2.0


def stdev(values: Sequence[float]) -> float:
    """Return the population standard deviation of ``values``.

    Raises:
        ValueError: if fewer than two values are supplied.
    """
    data = _as_list(values)
    if len(data) < 2:
        raise ValueError("stdev() requires at least two values")
    m = sum(data) / len(data)
    variance = sum((x - m) ** 2 for x in data) / len(data)
    return math.sqrt(variance)


class RunningStats:
    """Incrementally accumulate count, mean and variance.

    Uses Welford's online algorithm so that results stay numerically stable
    even for large inputs. Two accumulators can be combined with
    :meth:`merge`.
    """

    __slots__ = ("_n", "_mean", "_m2")

    def __init__(self) -> None:
        self._n = 0
        self._mean = 0.0
        self._m2 = 0.0

    # -- properties -----------------------------------------------------
    @property
    def count(self) -> int:
        """Number of values added so far."""
        return self._n

    @property
    def mean(self) -> float:
        """Current arithmetic mean (``0.0`` when empty)."""
        return self._mean

    @property
    def variance(self) -> float:
        """Population variance (``0.0`` when fewer than two values)."""
        if self._n < 2:
            return 0.0
        return self._m2 / self._n

    @property
    def stdev(self) -> float:
        """Population standard deviation (``0.0`` when fewer than two)."""
        return math.sqrt(self.variance)

    # -- mutation -------------------------------------------------------
    def add(self, value: float) -> "RunningStats":
        """Add a single observation and return ``self`` for chaining."""
        x = float(value)
        self._n += 1
        delta = x - self._mean
        self._mean += delta / self._n
        self._m2 += delta * (x - self._mean)
        return self

    def extend(self, values: Iterable[float]) -> "RunningStats":
        """Add every value from ``values`` and return ``self``."""
        for v in values:
            self.add(v)
        return self

    def merge(self, other: "RunningStats") -> "RunningStats":
        """Combine ``other`` into ``self`` and return ``self``.

        Raises:
            TypeError: if ``other`` is not a :class:`RunningStats`.
        """
        if not isinstance(other, RunningStats):
            raise TypeError("merge() requires a RunningStats instance")
        if other._n == 0:
            return self
        if self._n == 0:
            self._n = other._n
            self._mean = other._mean
            self._m2 = other._m2
            return self

        total = self._n + other._n
        delta = other._mean - self._mean
        self._m2 += other._m2 + delta * delta * self._n * other._n / total
        self._mean += delta * other._n / total
        self._n = total
        return self

    # -- dunder ---------------------------------------------------------
    def __repr__(self) -> str:  # pragma: no cover - trivial
        return (
            f"RunningStats(count={self._n}, mean={self._mean!r}, "
            f"m2={self._m2!r})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, RunningStats):
            return NotImplemented
        return (
            self._n == other._n
            and self._mean == other._mean
            and self._m2 == other._m2
        )
