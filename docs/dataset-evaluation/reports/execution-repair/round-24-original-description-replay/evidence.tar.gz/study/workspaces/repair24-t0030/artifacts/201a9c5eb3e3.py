"""Tests for src/textstats.py."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from textstats import char_frequency, summarize, top_words, word_count


def test_word_count_normal():
    assert word_count("the quick brown fox") == 4


def test_word_count_empty_and_whitespace():
    assert word_count("") == 0
    assert word_count("   \t\n ") == 0


def test_word_count_punctuation_only():
    assert word_count("!!! ???") == 2


def test_char_frequency_case_folding_and_filtering():
    result = char_frequency("Aa b! B")
    assert result == {"a": 2, "b": 2}


def test_char_frequency_ordering():
    result = char_frequency("aabbbc")
    assert list(result.items()) == [("b", 3), ("a", 2), ("c", 1)]


def test_char_frequency_empty():
    assert char_frequency("") == {}


def test_top_words_ordering_by_count():
    text = "apple apple banana banana banana cherry"
    assert top_words(text) == [("banana", 3), ("apple", 2), ("cherry", 1)]


def test_top_words_alphabetical_tie_break():
    text = "dog cat bird dog cat bird"
    assert top_words(text, 3) == [("bird", 2), ("cat", 2), ("dog", 2)]


def test_top_words_strips_punctuation_and_case():
    text = "Hello, hello! HELLO world."
    assert top_words(text, 2) == [("hello", 3), ("world", 1)]


def test_top_words_n_larger_than_vocabulary():
    assert top_words("one two", 10) == [("one", 1), ("two", 1)]


def test_top_words_non_positive_n():
    assert top_words("one two three", 0) == []
    assert top_words("one two three", -5) == []


def test_top_words_empty_text():
    assert top_words("") == []


def test_summarize_keys_and_consistency():
    text = "the cat the dog"
    summary = summarize(text)
    assert set(summary) == {"word_count", "char_frequency", "top_words"}
    assert summary["word_count"] == word_count(text)
    assert summary["char_frequency"] == char_frequency(text)
    assert summary["top_words"] == top_words(text)
    assert summary["top_words"][0] == ("the", 2)
