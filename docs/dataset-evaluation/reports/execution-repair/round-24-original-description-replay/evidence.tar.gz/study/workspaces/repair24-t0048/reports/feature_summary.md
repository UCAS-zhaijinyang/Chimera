# Feature Summary — textstats (fixture variation 5)

## Change
Added `src/textstats.py`, a small self-contained text statistics module, with
pytest coverage in `tests/test_textstats.py`.

## Public API
| Function | Description |
| --- | --- |
| `normalize(text)` | Lowercase alphanumeric tokenization, order preserved. |
| `word_counts(text)` | Token -> count mapping in first-seen order. |
| `top_words(text, n=3)` | Top `n` tokens as `(token, count)`; ties by first appearance then alphabetical. |
| `unique_word_count(text)` | Number of distinct tokens. |

## Behavior notes
- Case-insensitive; non-alphanumeric characters are separators.
- Empty / whitespace-only / punctuation-only input returns empty results.
- `top_words` handles `n <= 0` (returns `[]`) and `n` larger than the distinct count.
- Invalid types raise `TypeError`.

## Verification
- Tests: `python -m pytest tests -q`
- Build: `python -m compileall -q src`

## Risk / review focus
- Tie-breaking determinism in `top_words`.
- Unicode handling via `str.isalnum`.
