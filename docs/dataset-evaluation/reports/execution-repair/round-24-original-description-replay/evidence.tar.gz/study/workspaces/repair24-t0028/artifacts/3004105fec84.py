"""Small text statistics utilities.

Provides word normalization, frequency counting, top-word extraction and
unique-word counting. Standard library only; deterministic output.
"""

from __future__ import annotations

import re
import string

__all__ = [
    "normalize",
    "word_frequencies",
    "top_words",
    "unique_word_count",
]

_PUNCT_TABLE = str.maketrans({ch: " " for ch in string.punctuation})
_WHITESPACE_RE = re.compile(r"\s+")


def normalize(text: str) -> str:
    """Lowercase ``text``, strip punctuation and collapse whitespace.

    Returns a single space separated string with no leading/trailing spaces.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    lowered = text.lower()
    depunctuated = lowered.translate(_PUNCT_TABLE)
    collapsed = _WHITESPACE_RE.sub(" ", depunctuated).strip()
    return collapsed


def _words(text: str) -> list[str]:
    normalized = normalize(text)
    if not normalized:
        return []
    return normalized.split(" ")


def word_frequencies(text: str) -> dict[str, int]:
    """Return word -> count, ordered by descending count then alphabetically."""
    counts: dict[str, int] = {}
    for word in _words(text):
        counts[word] = counts.get(word, 0) + 1
    return dict(sorted(counts.items(), key=lambda item: (-item[1], item[0])))


def top_words(text: str, n: int = 5) -> list[tuple[str, int]]:
    """Return the ``n`` most frequent words as ``(word, count)`` tuples.

    Raises ``ValueError`` if ``n`` is negative.
    """
    if n < 0:
        raise ValueError("n must be non-negative")
    return list(word_frequencies(text).items())[:n]


def unique_word_count(text: str) -> int:
    """Return the number of distinct normalized words in ``text``."""
    return len(word_frequencies(text))
