"""Small, dependency-free text statistics utilities.

Public API:
    word_count(text) -> int
    char_frequency(text) -> dict[str, int]
    most_common_words(text, n=3) -> list[tuple[str, int]]
    normalize_whitespace(text) -> str
"""

from __future__ import annotations

from collections import Counter

__all__ = [
    "word_count",
    "char_frequency",
    "most_common_words",
    "normalize_whitespace",
]


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in *text*.

    Empty or whitespace-only input returns 0.
    """
    if not text:
        return 0
    return len(text.split())


def char_frequency(text: str) -> dict[str, int]:
    """Return a mapping of character -> count, ignoring whitespace.

    Case is preserved. The returned dict is ordered by first appearance.
    """
    counts: dict[str, int] = {}
    for ch in text:
        if ch.isspace():
            continue
        counts[ch] = counts.get(ch, 0) + 1
    return counts


def most_common_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the *n* most frequent lowercased words as (word, count) tuples.

    Ordering is by descending count, then alphabetically ascending for ties.
    ``n <= 0`` returns an empty list.
    """
    if n <= 0:
        return []
    words = [w.lower() for w in text.split()]
    if not words:
        return []
    counter = Counter(words)
    ordered = sorted(counter.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]


def normalize_whitespace(text: str) -> str:
    """Collapse runs of whitespace into single spaces and strip the ends."""
    return " ".join(text.split())
