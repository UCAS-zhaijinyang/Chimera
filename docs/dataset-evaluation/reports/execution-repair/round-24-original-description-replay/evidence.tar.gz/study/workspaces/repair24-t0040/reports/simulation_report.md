# Simulation Data Report — Fixture Variation 3

## Source
- Query: simulation data fixture variation 3
- Evidence level: simulation_only
- Business status: not_measured

## Raw Data
| Week | Count |
|------|-------|
| W1   | 3     |
| W2   | 5     |

## Transformed Data (grouped by week)
| Group | Count |
|-------|-------|
| W1    | 3     |
| W2    | 5     |

## Summary
- Total count across weeks: 8
- Weeks observed: 2 (W1, W2)
- Highest week: W2 with count 5
- Lowest week: W1 with count 3

## Notes
This report is based on simulated fixture data (variation 3). Values are
simulation-only and have not been measured in a production environment.
