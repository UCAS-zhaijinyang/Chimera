"""Tiny descriptive-statistics helpers.

Pure, dependency-free functions for computing common descriptive statistics
over a sequence of numbers. All functions validate their input and raise
``ValueError`` for empty (or otherwise insufficient) input. Inputs are never
mutated.
"""

from __future__ import annotations

import math
from typing import Dict, Sequence

__all__ = ["mean", "median", "variance", "stdev", "summary"]


def _as_floats(values: Sequence[float]) -> list:
    """Return a new list of floats, raising ValueError if empty."""
    data = [float(v) for v in values]
    if not data:
        raise ValueError("values must not be empty")
    return data


def mean(values: Sequence[float]) -> float:
    """Return the arithmetic mean of ``values``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = _as_floats(values)
    return sum(data) / len(data)


def median(values: Sequence[float]) -> float:
    """Return the median of ``values`` without mutating the input.

    For an even number of values, returns the average of the two middle values.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = sorted(_as_floats(values))
    n = len(data)
    mid = n // 2
    if n % 2 == 1:
        return data[mid]
    return (data[mid - 1] + data[mid]) / 2.0


def variance(values: Sequence[float], sample: bool = True) -> float:
    """Return the variance of ``values``.

    Args:
        values: sequence of numbers.
        sample: when True (default) use the sample variance (n-1 denominator);
            when False use the population variance (n denominator).

    Raises:
        ValueError: if ``values`` is empty, or if ``sample`` is True and fewer
            than two values are supplied.
    """
    data = _as_floats(values)
    n = len(data)
    if sample and n < 2:
        raise ValueError("sample variance requires at least two values")
    mu = sum(data) / n
    denominator = (n - 1) if sample else n
    return sum((x - mu) ** 2 for x in data) / denominator


def stdev(values: Sequence[float], sample: bool = True) -> float:
    """Return the standard deviation of ``values``.

    See :func:`variance` for the meaning of ``sample`` and the raised errors.
    """
    return math.sqrt(variance(values, sample=sample))


def summary(values: Sequence[float]) -> Dict[str, float]:
    """Return a dictionary of descriptive statistics for ``values``.

    Keys: ``count``, ``min``, ``max``, ``mean``, ``median``, ``stdev``.

    Raises:
        ValueError: if ``values`` is empty.
    """
    data = _as_floats(values)
    return {
        "count": len(data),
        "min": min(data),
        "max": max(data),
        "mean": mean(data),
        "median": median(data),
        "stdev": stdev(data),
    }
