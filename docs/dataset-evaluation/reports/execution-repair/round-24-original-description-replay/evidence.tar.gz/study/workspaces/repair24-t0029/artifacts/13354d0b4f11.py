"""Tests for src/textstats.py.

Runnable with pytest or directly via ``python src/test_textstats.py``.
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from textstats import summarize, top_words, word_frequencies  # noqa: E402


def test_word_frequencies_counts_and_normalizes():
    words = ["The", "quick", "the", "QUICK", "brown"]
    assert word_frequencies(words) == {"the": 2, "quick": 2, "brown": 1}


def test_word_frequencies_ignores_blank_tokens():
    words = ["a", "   ", "", "\t", "a"]
    assert word_frequencies(words) == {"a": 2}


def test_word_frequencies_preserves_first_seen_order():
    words = ["b", "a", "b", "c"]
    assert list(word_frequencies(words).keys()) == ["b", "a", "c"]


def test_top_words_orders_by_count():
    words = ["a", "b", "b", "c", "c", "c"]
    assert top_words(words, 2) == [("c", 3), ("b", 2)]


def test_top_words_ties_broken_by_first_seen():
    words = ["x", "y", "x", "y", "z"]
    assert top_words(words, 2) == [("x", 2), ("y", 2)]


def test_top_words_non_positive_n():
    words = ["a", "a", "b"]
    assert top_words(words, 0) == []
    assert top_words(words, -5) == []


def test_top_words_n_larger_than_distinct():
    words = ["a", "b"]
    assert top_words(words, 10) == [("a", 1), ("b", 1)]


def test_summarize_consistency():
    words = ["a", "a", "b", "c", "c", "c"]
    result = summarize(words)
    assert result["total"] == 6
    assert result["unique"] == 3
    assert result["top"] == [("c", 3), ("a", 2), ("b", 1)]


def test_summarize_empty_input():
    assert summarize([]) == {"total": 0, "unique": 0, "top": []}


def test_non_string_token_raises_type_error():
    try:
        word_frequencies(["ok", 123])
    except TypeError:
        pass
    else:  # pragma: no cover
        raise AssertionError("expected TypeError for non-string token")


def test_generator_input_is_consumed():
    gen = (w for w in ["a", "b", "a"])
    assert word_frequencies(gen) == {"a": 2, "b": 1}


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
            except Exception as exc:  # noqa: BLE001
                failures += 1
                print(f"FAIL {name}: {exc!r}")
            else:
                print(f"PASS {name}")
    if failures:
        raise SystemExit(f"{failures} test(s) failed")
    print("all tests passed")
