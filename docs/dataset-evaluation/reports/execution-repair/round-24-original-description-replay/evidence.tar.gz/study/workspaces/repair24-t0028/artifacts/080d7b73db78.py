"""Tests for src/textstats.py."""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import textstats  # noqa: E402


def test_normalize_lowercases_and_strips_punctuation():
    assert textstats.normalize("Hello, World!") == "hello world"


def test_normalize_collapses_whitespace():
    assert textstats.normalize("  a\t b\n\nc  ") == "a b c"


def test_normalize_empty_and_punctuation_only():
    assert textstats.normalize("") == ""
    assert textstats.normalize("   ") == ""
    assert textstats.normalize("!!! ... ???") == ""


def test_normalize_rejects_non_str():
    with pytest.raises(TypeError):
        textstats.normalize(123)


def test_word_frequencies_counts_and_orders():
    text = "the cat the dog the bird cat"
    assert textstats.word_frequencies(text) == {
        "the": 3,
        "cat": 2,
        "bird": 1,
        "dog": 1,
    }


def test_word_frequencies_tie_break_alphabetical():
    result = textstats.word_frequencies("b a c a b")
    assert list(result.items()) == [("a", 2), ("b", 2), ("c", 1)]


def test_word_frequencies_empty():
    assert textstats.word_frequencies("") == {}
    assert textstats.word_frequencies("   ") == {}


def test_top_words_default_and_truncation():
    text = "a a a b b c"
    assert textstats.top_words(text, 2) == [("a", 3), ("b", 2)]
    assert textstats.top_words(text) == [("a", 3), ("b", 2), ("c", 1)]


def test_top_words_zero_and_larger_than_vocab():
    text = "x y"
    assert textstats.top_words(text, 0) == []
    assert textstats.top_words(text, 10) == [("x", 1), ("y", 1)]


def test_top_words_negative_raises():
    with pytest.raises(ValueError):
        textstats.top_words("a b", -1)


def test_unique_word_count():
    assert textstats.unique_word_count("a b a c b a") == 3
    assert textstats.unique_word_count("") == 0
    assert textstats.unique_word_count("!!! ???") == 0
