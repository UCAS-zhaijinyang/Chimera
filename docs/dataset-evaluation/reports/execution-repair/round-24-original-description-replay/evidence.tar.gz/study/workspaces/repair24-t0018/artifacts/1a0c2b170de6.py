import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src import main


def test_main_returns_ok():
    assert main() == "ok"
