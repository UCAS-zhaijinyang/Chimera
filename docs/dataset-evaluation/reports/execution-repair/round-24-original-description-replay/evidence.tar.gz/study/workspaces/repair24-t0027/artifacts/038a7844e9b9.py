"""Tests for src/stats_tool.py."""

import math
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from stats_tool import mean, median, stdev, summary, variance  # noqa: E402


class TestMean:
    def test_typical(self):
        assert mean([1, 2, 3, 4]) == 2.5

    def test_single_value(self):
        assert mean([7]) == 7.0

    def test_accepts_ints_and_floats(self):
        assert mean([1, 2.5]) == 1.75

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            mean([])


class TestMedian:
    def test_odd_length(self):
        assert median([3, 1, 2]) == 2

    def test_even_length(self):
        assert median([4, 1, 3, 2]) == 2.5

    def test_unsorted_input(self):
        assert median([10, -5, 0, 3, 8]) == 3

    def test_does_not_mutate_input(self):
        data = [3, 1, 2]
        median(data)
        assert data == [3, 1, 2]

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            median([])


class TestVariance:
    def test_sample_variance(self):
        assert variance([2, 4, 4, 4, 5, 5, 7, 9]) == pytest.approx(4.571428571428571)

    def test_population_variance(self):
        assert variance([2, 4, 4, 4, 5, 5, 7, 9], sample=False) == pytest.approx(4.0)

    def test_single_value_sample_raises(self):
        with pytest.raises(ValueError):
            variance([1])

    def test_single_value_population_is_zero(self):
        assert variance([1], sample=False) == 0.0

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            variance([])


class TestStdev:
    def test_sample_stdev(self):
        assert stdev([2, 4, 4, 4, 5, 5, 7, 9]) == pytest.approx(math.sqrt(4.571428571428571))

    def test_population_stdev(self):
        assert stdev([2, 4, 4, 4, 5, 5, 7, 9], sample=False) == pytest.approx(2.0)

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            stdev([])


class TestSummary:
    def test_keys_and_values(self):
        result = summary([1, 2, 3, 4])
        assert set(result) == {"count", "min", "max", "mean", "median", "stdev"}
        assert result["count"] == 4
        assert result["min"] == 1
        assert result["max"] == 4
        assert result["mean"] == 2.5
        assert result["median"] == 2.5
        assert result["stdev"] == pytest.approx(math.sqrt(5.0 / 3.0))

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            summary([])
