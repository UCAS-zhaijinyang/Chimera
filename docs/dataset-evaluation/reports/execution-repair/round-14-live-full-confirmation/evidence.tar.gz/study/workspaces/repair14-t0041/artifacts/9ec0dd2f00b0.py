"""Core numeric utilities."""

import math


def _validate_finite_number(value, name):
    """Validate that value is a finite numeric input (int or float)."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be an int or float, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    5
    >>> compute(0, 0)
    0
    >>> compute(-4, 2)
    -2
    >>> compute(1.5, 2.25)
    3.75
    """
    _validate_finite_number(a, "a")
    _validate_finite_number(b, "b")
    return a + b
