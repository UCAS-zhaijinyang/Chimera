"""Core numeric utilities for the compute feature."""

import math


def _validate_finite(value, name):
    """Ensure value is a finite numeric input."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a numeric value, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    5
    >>> compute(0, 0)
    0
    >>> compute(-1, 1)
    0
    >>> compute(1.5, 2.25)
    3.75
    """
    _validate_finite(a, "a")
    _validate_finite(b, "b")
    return a + b
