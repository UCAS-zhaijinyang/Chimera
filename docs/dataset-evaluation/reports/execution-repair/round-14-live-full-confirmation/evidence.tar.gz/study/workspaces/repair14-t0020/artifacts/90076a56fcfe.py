"""Public entry point re-exporting compute."""

from restricted import compute

__all__ = ["compute"]
