"""Core numeric utilities."""

import math


def compute(a, b):
    """Return the difference of two finite numeric inputs (a - b).

    Supports zero, negative and fractional values.

    Raises:
        TypeError: if either input is not a real number.
        ValueError: if either input is non-finite (NaN or +/-inf).
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"expected a real number, got {type(value).__name__}")
        if not math.isfinite(value):
            raise ValueError("inputs must be finite")

    return a - b
