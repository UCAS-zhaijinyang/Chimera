# Design: compute(a, b) in src/restricted.py

## Goal
Provide a function `compute(a, b)` that returns the maximum of two finite numeric inputs.

## Interface
- Module: `src/restricted.py`
- Signature: `def compute(a, b):`
- Returns: the larger of `a` and `b`.

## Behavior
- `compute(2, 3) == 3`
- Supports zero: `compute(0, 0) == 0`, `compute(0, 5) == 5`
- Supports negatives: `compute(-4, -2) == -2`
- Supports fractional values: `compute(1.5, 1.25) == 1.5`
- Mixed int/float comparisons work via Python's numeric comparison.

## Implementation
Use a simple comparison: `return a if a >= b else b`. This avoids relying on
`max()` semantics differences and is explicit. Ties return `a`, which equals `b`
numerically.

## Verification
- Public behavioral check: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
- Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Constraints
- Only finite numeric inputs are in scope; no NaN/inf handling required.
