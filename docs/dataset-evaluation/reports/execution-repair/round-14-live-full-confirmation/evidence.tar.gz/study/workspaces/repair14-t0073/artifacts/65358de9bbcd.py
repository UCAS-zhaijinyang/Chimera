"""Core numeric feature module.

Provides :func:`compute`, which returns the product of two finite numeric
inputs.
"""

from __future__ import annotations

import math
import numbers

__all__ = ["compute"]


def _validate(value, name):
    """Validate that *value* is a finite real number.

    Raises:
        TypeError: if *value* is not a real number.
        ValueError: if *value* is not finite (NaN or +/-inf).
    """
    if isinstance(value, bool) or not isinstance(value, numbers.Real):
        raise TypeError(f"{name} must be a real number, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        6
        >>> compute(0, 5)
        0
        >>> compute(-2, 3)
        -6
        >>> compute(0.5, 4)
        2.0
    """
    _validate(a, "a")
    _validate(b, "b")
    return a * b
