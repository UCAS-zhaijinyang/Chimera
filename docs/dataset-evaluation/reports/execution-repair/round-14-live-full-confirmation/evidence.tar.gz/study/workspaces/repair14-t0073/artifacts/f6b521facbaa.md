# Design: compute(a, b) product feature

## Goal
Provide `compute(a, b)` in `src/main.py` returning the product of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b) -> float | int`
- Returns `a * b`.
- Accepts int and float (including bool? treat as numeric via numbers.Real).
- Supports zero, negative, and fractional values.

## Validation
- Reject non-numeric inputs (raise TypeError).
- Reject non-finite values (NaN, inf) (raise ValueError).
- Use `math.isfinite` and `numbers.Real` checks.

## Examples
- compute(2, 3) == 6
- compute(0, 5) == 0
- compute(-2, 3) == -6
- compute(0.5, 4) == 2.0

## Verification
- Public behavioral check: `checks/public_check.py`
- Build: `python -m compileall -q src`

## Files
- `src/main.py` (implementation)
