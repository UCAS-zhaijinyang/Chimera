"""Main module for the compute feature."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Example:
        >>> compute(2, 3)
        3
    """
    return max(a, b)
