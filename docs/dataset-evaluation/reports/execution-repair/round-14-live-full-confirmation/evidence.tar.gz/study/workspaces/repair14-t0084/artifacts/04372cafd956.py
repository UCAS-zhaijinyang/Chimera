"""Core numeric helpers."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    if a >= b:
        return a
    return b
