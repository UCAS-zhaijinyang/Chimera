{
  "path": "shared/out.md",
  "source": "e539c48f69a7"
}