{
  "path": "shared/out.md",
  "source": "4ea555d838d8"
}