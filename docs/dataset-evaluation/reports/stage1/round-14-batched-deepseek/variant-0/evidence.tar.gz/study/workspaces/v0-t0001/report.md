# Simulation Data Analysis Report — Fixture Variation 0

## Scope
Analysis of simulation data for fixture variation 0.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
The dataset was acquired and transformed successfully. Because the source is
simulation-only and no measurement was performed, results are indicative of
model behavior only and must not be treated as validated physical or business
measurements.

## Recommendation
Treat all figures as preliminary. Re-run against measured data before any
decision-making use.
