# Simulation Data Analysis Report — Fixture Variation 1

## Scope
Analysis of simulation data for fixture variation 1.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
The dataset was acquired and transformed successfully. Because the evidence is
simulation-only and the business status is "not_measured", the results should be
treated as indicative rather than validated against real-world measurements.

## Recommendation
Re-run against measured production data before using these results for
operational decisions.

## Artifacts
- Source: artifacts/69de6ba58926.json
- Transformed: artifacts/d3361d36a66e.json
