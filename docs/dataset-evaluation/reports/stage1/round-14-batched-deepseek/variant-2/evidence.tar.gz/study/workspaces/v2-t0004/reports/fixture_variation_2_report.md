# Simulation Analysis Report — Fixture Variation 2

## Scope
Analysis of simulation data for fixture variation 2.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
Results are derived from simulated data only. No measured or production data was used, so the findings are indicative and must not be treated as validated business results.

## Recommendation
Treat all figures as provisional. Re-run the analysis against measured data before any decision-making.

## Deliverable
Report saved to reports/fixture_variation_2_report.md
