# Simulation Report — Fixture Variation 5

## Scope
Analysis of simulation data for fixture variation 5.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
Results are derived from simulated data only. No physical measurements were taken, so
values should be treated as indicative model output rather than validated performance.

## Recommendation
Treat conclusions as provisional. Confirm with measured data before any production or
design decision.

## Artifacts
- Source: artifacts/8f6c748dcba2.json
- Transformed: artifacts/523c78fcda4e.json
