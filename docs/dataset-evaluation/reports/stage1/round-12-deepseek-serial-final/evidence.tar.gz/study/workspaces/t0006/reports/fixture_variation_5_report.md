# Simulation Report — Fixture Variation 5

## Scope
Analysis of simulation data for fixture variation 5.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
Results are derived from simulated data only. No physical measurement or
production validation was performed, so the numbers below must not be
treated as measured performance.

## Recommendation
Treat this report as a simulation-based indication. Confirm with physical
testing before any decision that depends on measured behavior.

## Artifacts
- Source data: artifacts/79ec4fe2181c.json
- Transformed data: artifacts/e08995ef1bc3.json
