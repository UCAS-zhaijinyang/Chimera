{
  "path": "shared/out.md",
  "source": "ccf964a748b8"
}