def main():
    return 9
