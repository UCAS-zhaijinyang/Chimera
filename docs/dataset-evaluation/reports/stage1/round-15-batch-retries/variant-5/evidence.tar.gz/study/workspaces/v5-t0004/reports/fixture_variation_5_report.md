# Simulation Report — Fixture Variation 5

## Scope
Analysis of simulation data for fixture variation 5.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
The dataset for fixture variation 5 was acquired and transformed successfully. All results are derived from simulated data only; no physical measurements were taken, so the figures below should be treated as indicative rather than validated.

## Caveats
- No measured (real-world) data backs these results.
- Conclusions are limited to the simulated fixture variation 5 scenario.

## Recommendation
Re-run against measured data before using these results for any production or engineering decision.
