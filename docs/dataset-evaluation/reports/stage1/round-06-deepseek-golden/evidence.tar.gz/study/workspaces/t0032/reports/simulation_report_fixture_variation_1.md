# Simulation Data Analysis Report — Fixture Variation 1

## Scope
Analysis of simulation data for fixture variation 1.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
Results are derived from simulated data only. No measured or production data was used, so
findings should be treated as indicative and not as validated business results.

## Recommendation
Re-run the analysis against measured data before using these results for any decision.

## Artifacts
- Source data: 862e1fafb3e7
- Transformed data: d4a782724a84
