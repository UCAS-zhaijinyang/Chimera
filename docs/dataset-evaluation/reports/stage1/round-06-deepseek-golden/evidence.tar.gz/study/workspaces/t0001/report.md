# Simulation Data Analysis Report — Fixture Variation 0

## Scope
Analysis of simulation data for fixture variation 0.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
The dataset was acquired and transformed successfully. Because the evidence is
simulation-only and the business status is "not_measured", the results should be
treated as indicative rather than as validated measurements. No production or
field measurements back these numbers.

## Recommendation
Re-run the analysis against measured data before using these results for any
business decision.

## Artifacts
- Source: artifacts/4a634bc3884c.json
- Transformed: artifacts/e013a17e09b3.json
