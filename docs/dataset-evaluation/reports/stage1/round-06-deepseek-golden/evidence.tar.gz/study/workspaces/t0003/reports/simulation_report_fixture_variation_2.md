# Simulation Report — Fixture Variation 2

## Scope
Analysis of simulation data for fixture variation 2.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
The dataset was acquired and transformed successfully. Because the evidence is
simulation-only and the business status is not_measured, results should be
treated as indicative rather than validated against real-world measurements.

## Recommendation
Re-run against measured fixture data before using these results for any
production or business decision.
