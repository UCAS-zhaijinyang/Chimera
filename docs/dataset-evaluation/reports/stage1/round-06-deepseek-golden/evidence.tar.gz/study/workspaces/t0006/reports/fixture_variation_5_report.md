# Simulation Report — Fixture Variation 5

## Scope
Analysis of simulation data for fixture variation 5.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
Results are derived from simulated data only. No physical measurement or
production validation was performed, so the figures below should be treated
as indicative rather than as verified performance.

## Recommendation
Treat all conclusions as provisional. Confirm with measured data before any
design or production decision.

## Artifacts
- Source data: artifacts/5eae73fd5226.json
- Transformed data: artifacts/50f82a464db2.json
