# Simulation Report — Fixture Variation 3

## Scope
Analysis of simulation data for fixture variation 3.

## Evidence status
- Evidence level: **simulation_only**
- Business status: **not_measured**

## Findings
Results are derived from simulated inputs only. No physical measurement or
production validation was performed, so figures should be treated as
indicative rather than as verified performance data.

## Recommendation
Treat all conclusions as provisional. Confirm with measured data from a
physical fixture before making any design or release decision.

## Artifacts
- Source data: artifacts/9224aaf9110a.json
- Transformed data: artifacts/9d8acf192c29.json
