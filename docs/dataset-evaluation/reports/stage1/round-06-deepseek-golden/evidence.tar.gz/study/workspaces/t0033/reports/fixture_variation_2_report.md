# Simulation Analysis Report — Fixture Variation 2

## Scope
Analysis of simulation data for fixture variation 2.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
Results are derived from simulated data only. No physical measurements were taken, so
values should be treated as indicative model output rather than validated performance.

## Recommendation
Validate against measured data before using these results for any production decision.

## Deliverable
Report saved to reports/fixture_variation_2_report.md
