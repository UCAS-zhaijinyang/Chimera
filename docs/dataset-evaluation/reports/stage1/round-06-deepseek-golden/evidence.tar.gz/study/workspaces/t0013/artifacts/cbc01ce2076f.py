"""Small text statistics utilities.

Pure, dependency-free helpers for counting words and characters.
"""

from __future__ import annotations

from collections import Counter

__all__ = ["word_count", "char_frequency", "top_words"]


def _require_str(value: object, name: str = "text") -> str:
    if not isinstance(value, str):
        raise TypeError(f"{name} must be str, got {type(value).__name__}")
    return value


def word_count(text: str) -> int:
    """Return the number of whitespace-separated tokens in ``text``."""
    return len(_require_str(text).split())


def char_frequency(text: str) -> dict[str, int]:
    """Return case-insensitive character counts, ignoring whitespace."""
    text = _require_str(text)
    counts: Counter[str] = Counter()
    for ch in text:
        if not ch.isspace():
            counts[ch.lower()] += 1
    return dict(counts)


def top_words(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Return the ``n`` most common lowercased words.

    Ties are broken alphabetically for deterministic output.
    """
    text = _require_str(text)
    if not isinstance(n, int) or isinstance(n, bool):
        raise TypeError(f"n must be int, got {type(n).__name__}")
    if n < 0:
        raise ValueError("n must be non-negative")

    counts: Counter[str] = Counter(word.lower() for word in text.split())
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return ordered[:n]
