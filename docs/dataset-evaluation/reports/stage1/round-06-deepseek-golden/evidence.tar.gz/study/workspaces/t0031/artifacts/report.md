# Simulation Data Analysis Report — Fixture Variation 0

## Scope
Analysis of simulation data for fixture variation 0.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
The dataset was acquired and transformed successfully. Because the source is
simulation-only and no business measurement was performed, results should be
treated as indicative rather than validated against production behavior.

## Caveats
- No real-world measurement backs these numbers.
- Fixture variation 0 represents a single configuration; no cross-variation
  comparison was performed.

## Recommendation
Re-run against measured data before using these results for decisions.
