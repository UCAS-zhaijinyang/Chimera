# Simulation Analysis Report — Fixture Variation 1

## Scope
Analysis of simulation data for fixture variation 1, derived from source artifact 830495526095 and transformed artifact df35d9da4db0.

## Evidence status
- Evidence level: simulation_only
- Business status: not_measured

## Findings
The dataset was acquired and transformed successfully. Because the evidence is simulation-only and the business status is not_measured, no production or business conclusions can be drawn from this variation. Results should be treated as indicative of model behavior only.

## Recommendation
Re-run the analysis against measured data before using these results for any decision. If simulation-only results are acceptable, document the model assumptions and parameters used for fixture variation 1.

## Deliverable
Report saved to artifacts/report_fixture_variation_1.md
