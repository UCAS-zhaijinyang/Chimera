{
  "path": "shared/out.md",
  "source": "9c09d44c624f"
}