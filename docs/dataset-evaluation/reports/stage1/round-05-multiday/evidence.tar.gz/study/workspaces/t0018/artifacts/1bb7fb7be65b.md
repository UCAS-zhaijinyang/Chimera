{
  "path": "shared/out.md",
  "source": "50e27d36cd6c"
}