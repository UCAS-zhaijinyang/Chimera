{
  "path": "shared/out.md",
  "source": "4ccb6e8a456c"
}