{
  "path": "shared/out.md",
  "source": "f6101759f308"
}