{
  "path": "shared/out.md",
  "source": "d065fc4593b4"
}