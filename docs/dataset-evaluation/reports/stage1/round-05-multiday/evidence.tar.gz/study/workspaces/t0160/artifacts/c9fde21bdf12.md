{
  "path": "shared/out.md",
  "source": "c696dcdbb072"
}