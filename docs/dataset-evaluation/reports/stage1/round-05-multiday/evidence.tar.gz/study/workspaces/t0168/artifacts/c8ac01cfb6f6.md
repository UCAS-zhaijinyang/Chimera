{
  "path": "shared/out.md",
  "source": "1d7071ff53dc"
}