{
  "path": "shared/out.md",
  "source": "fa6aeda83e40"
}