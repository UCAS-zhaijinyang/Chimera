{
  "path": "shared/out.md",
  "source": "0ebfa14a677f"
}