{
  "path": "shared/out.md",
  "source": "6ae2c2fd99cc"
}