{
  "path": "shared/out.md",
  "source": "c0de51512889"
}