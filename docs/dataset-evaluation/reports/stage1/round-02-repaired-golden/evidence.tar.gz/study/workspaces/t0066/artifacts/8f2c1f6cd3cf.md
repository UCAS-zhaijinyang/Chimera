{
  "path": "shared/out.md",
  "source": "076d2861e88c"
}