{
  "path": "shared/out.md",
  "source": "b2d1bc2e26e2"
}