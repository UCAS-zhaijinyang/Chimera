{
  "path": "shared/out.md",
  "source": "5b794072a4bf"
}