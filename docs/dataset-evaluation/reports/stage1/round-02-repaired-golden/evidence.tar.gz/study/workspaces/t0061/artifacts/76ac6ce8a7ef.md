{
  "path": "shared/out.md",
  "source": "0def85d71367"
}