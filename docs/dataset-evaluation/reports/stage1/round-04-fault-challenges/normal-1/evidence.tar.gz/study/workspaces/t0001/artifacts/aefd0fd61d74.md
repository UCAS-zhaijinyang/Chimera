{
  "path": "shared/out.md",
  "source": "0d6052de7d1a"
}