{
  "path": "shared/out.md",
  "source": "c38121c82295"
}