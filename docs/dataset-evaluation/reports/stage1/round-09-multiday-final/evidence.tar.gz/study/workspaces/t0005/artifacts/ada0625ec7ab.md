{
  "path": "shared/out.md",
  "source": "09c1df579a16"
}