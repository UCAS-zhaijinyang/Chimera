{
  "path": "shared/out.md",
  "source": "e85cb7e4d398"
}