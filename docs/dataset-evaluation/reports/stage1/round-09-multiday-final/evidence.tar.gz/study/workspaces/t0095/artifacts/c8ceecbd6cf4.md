{
  "path": "shared/out.md",
  "source": "f04f3992c9d3"
}