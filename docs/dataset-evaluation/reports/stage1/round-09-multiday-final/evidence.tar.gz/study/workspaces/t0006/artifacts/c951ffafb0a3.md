{
  "path": "shared/out.md",
  "source": "d4dd4c745024"
}