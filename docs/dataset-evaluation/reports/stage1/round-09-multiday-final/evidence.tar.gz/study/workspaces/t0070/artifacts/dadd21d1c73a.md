{
  "path": "shared/out.md",
  "source": "250dffa9fefb"
}