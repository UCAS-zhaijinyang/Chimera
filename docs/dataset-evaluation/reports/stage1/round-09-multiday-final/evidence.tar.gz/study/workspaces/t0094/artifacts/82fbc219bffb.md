{
  "path": "shared/out.md",
  "source": "fd8e227ed8df"
}