{
  "path": "shared/out.md",
  "source": "170f41af4a55"
}