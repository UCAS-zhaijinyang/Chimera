{
  "path": "shared/out.md",
  "source": "f16eb68bebda"
}