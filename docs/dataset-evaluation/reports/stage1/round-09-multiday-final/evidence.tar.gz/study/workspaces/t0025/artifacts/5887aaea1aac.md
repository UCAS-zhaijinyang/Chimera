{
  "path": "shared/out.md",
  "source": "8fe7c8e2c96f"
}