{
  "path": "shared/out.md",
  "source": "8bd4b23fec15"
}