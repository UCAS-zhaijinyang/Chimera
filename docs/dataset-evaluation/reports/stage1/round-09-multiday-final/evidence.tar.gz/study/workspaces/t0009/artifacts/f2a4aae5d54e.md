{
  "path": "shared/out.md",
  "source": "f25042cd628c"
}