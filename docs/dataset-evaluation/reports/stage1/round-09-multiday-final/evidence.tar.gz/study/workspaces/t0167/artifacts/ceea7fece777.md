{
  "path": "shared/out.md",
  "source": "f4e72277a639"
}