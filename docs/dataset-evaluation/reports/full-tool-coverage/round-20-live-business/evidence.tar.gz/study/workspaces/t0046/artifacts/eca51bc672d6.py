"""Unit tests for compute(a, b)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from main import compute  # noqa: E402


class TestCompute(unittest.TestCase):
    def test_compute_mean(self):
        self.assertEqual(compute(2, 3), 2.5)

    def test_zero(self):
        self.assertEqual(compute(0, 0), 0.0)

    def test_negative(self):
        self.assertEqual(compute(-2, 2), 0.0)
        self.assertEqual(compute(-3, -5), -4.0)

    def test_fractional(self):
        self.assertEqual(compute(1.5, 2.5), 2.0)


if __name__ == "__main__":
    unittest.main()
