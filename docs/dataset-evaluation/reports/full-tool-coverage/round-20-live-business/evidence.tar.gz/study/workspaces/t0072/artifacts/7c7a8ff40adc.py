"""Main module providing the compute function."""


def compute(a, b):
    """Return the difference of two finite numeric inputs (a - b).

    Supports zero, negative and fractional values.
    """
    return a - b
