"""Core module for the maximum-of-two feature."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative, and fractional values. The larger operand is
    returned unchanged, preserving its original type.
    """
    return max(a, b)
