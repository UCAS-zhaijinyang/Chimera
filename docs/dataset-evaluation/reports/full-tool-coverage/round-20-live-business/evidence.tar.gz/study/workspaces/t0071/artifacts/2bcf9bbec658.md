# Design: compute(a, b) sum feature

## Goal
Provide `compute(a, b)` in `src/main.py` that returns the arithmetic sum of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b):`
- Returns: `a + b`
- Accepts int and float values, including zero, negative, and fractional values.
- Example: `compute(2, 3) == 5`.

## Behavior
- `compute(2, 3)` -> 5
- `compute(0, 0)` -> 0
- `compute(-4, 1)` -> -3
- `compute(1.5, 2.25)` -> 3.75

## Implementation
Simple module-level function in `src/main.py` performing `return a + b`. No external dependencies.

## Verification
- Public behavioral check: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
- Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`
