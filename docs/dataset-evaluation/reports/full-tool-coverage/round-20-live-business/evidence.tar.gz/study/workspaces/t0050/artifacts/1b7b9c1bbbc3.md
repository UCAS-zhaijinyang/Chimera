# Design: compute(a, b) maximum of two finite numeric inputs

## Goal
Provide `compute(a, b)` in `src/restricted.py` that returns the maximum of two finite numeric inputs.

## Interface
- Module: `src/restricted.py`
- Function: `compute(a, b)`
- Returns: the larger of `a` and `b` (numeric).
- Example: `compute(2, 3) == 3`.

## Behavior
- Supports zero, negative, and fractional values.
- Inputs are finite numeric values (int/float).
- Symmetric: `compute(a, b) == compute(b, a)`.
- Idempotent on equal inputs: `compute(x, x) == x`.

## Implementation
Use a simple comparison: `return a if a >= b else b`. This preserves the original numeric type and handles negatives, zero, and fractions correctly.

## Verification
- Public behavioral check: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
- Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Risks
- Non-numeric or non-finite inputs are out of scope per requirements.
