# Design: compute(a, b) product feature

## Goal
Provide `compute(a, b)` in `src/main.py` returning the product of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b) -> float | int`
- Returns: `a * b`
- Behavior:
  - `compute(2, 3) == 6`
  - Supports zero: `compute(0, 5) == 0`
  - Supports negatives: `compute(-2, 3) == -6`
  - Supports fractions: `compute(0.5, 4) == 2.0`

## Validation
- Reject non-numeric inputs (bool excluded as it is not a general numeric input) with `TypeError`.
- Reject non-finite values (NaN, inf) with `ValueError`.
- Use `math.isfinite` for float checks.

## Files
- `src/main.py`: implementation of `compute`.
- `checks/public_check.py`: provided public behavioral check (read-only, run as-is).

## Verification
1. Run `checks/public_check.py` with the venv python.
2. Build with `python -m compileall -q src`.
