"""Main module exposing compute(a, b)."""

try:
    from src.helper import mean_values
except ImportError:  # pragma: no cover - fallback when src is on sys.path
    from helper import mean_values


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Examples:
        compute(2, 3) == 2.5
    """
    return mean_values(a, b)
