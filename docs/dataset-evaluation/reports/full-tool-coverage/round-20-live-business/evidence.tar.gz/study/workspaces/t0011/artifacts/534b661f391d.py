"""Core numeric utilities for the compute feature."""

import math

__all__ = ["compute"]


def _is_finite_number(value):
    """Return True if value is a finite real number (int or float)."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    if isinstance(value, float):
        return math.isfinite(value)
    return False


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    5
    >>> compute(0, 0)
    0
    >>> compute(-4, 1)
    -3
    >>> compute(1.5, 2.25)
    3.75
    """
    if not _is_finite_number(a):
        raise ValueError("a must be a finite numeric value")
    if not _is_finite_number(b):
        raise ValueError("b must be a finite numeric value")
    return a + b
