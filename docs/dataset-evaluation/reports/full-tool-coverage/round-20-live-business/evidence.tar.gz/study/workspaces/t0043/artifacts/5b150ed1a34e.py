"""Main module for the compute feature."""

import math


def _validate(value, name):
    """Validate that value is a finite numeric input."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a numeric value, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    6
    >>> compute(-2, 3.5)
    -7.0
    >>> compute(0, 5)
    0
    """
    a = _validate(a, "a")
    b = _validate(b, "b")
    return a * b
