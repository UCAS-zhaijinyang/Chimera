"""Core numeric utilities."""


def compute(a, b):
    """Return the difference of two finite numeric inputs (a - b).

    Supports zero, negative, and fractional values.

    Examples:
        >>> compute(2, 3)
        -1
        >>> compute(0.5, 0.25)
        0.25
    """
    return a - b
