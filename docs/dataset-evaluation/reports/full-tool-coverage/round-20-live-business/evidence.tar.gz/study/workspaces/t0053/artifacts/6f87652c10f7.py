"""Core numeric helpers."""

import math


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values. Raises TypeError for
    non-numeric inputs and ValueError for non-finite (inf/nan) inputs.
    """
    if isinstance(a, bool) or isinstance(b, bool):
        raise TypeError("compute() requires numeric inputs, not bool")
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError("compute() requires numeric inputs")
    if not math.isfinite(a) or not math.isfinite(b):
        raise ValueError("compute() requires finite numeric inputs")
    return a * b
