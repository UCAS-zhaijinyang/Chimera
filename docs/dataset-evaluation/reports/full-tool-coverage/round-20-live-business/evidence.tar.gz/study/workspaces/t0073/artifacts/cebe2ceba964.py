"""Core numeric utilities."""

import math


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative, and fractional values.

    Args:
        a: A finite numeric value (int or float).
        b: A finite numeric value (int or float).

    Returns:
        The product ``a * b``.

    Raises:
        TypeError: If either input is not a real number.
        ValueError: If either input is not finite (NaN or infinity).
    """
    for name, value in (("a", a), ("b", b)):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{name} must be a real number, got {type(value).__name__}")
        if not math.isfinite(value):
            raise ValueError(f"{name} must be finite, got {value!r}")
    return a * b
