"""Module providing compute(a, b), returning the maximum of two finite numeric inputs."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative, and fractional values.

    Examples:
        >>> compute(2, 3)
        3
        >>> compute(-5, -2)
        -2
        >>> compute(1.5, 2.25)
        2.25
    """
    return max(a, b)
