import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from restricted import compute


def main():
    assert compute(2, 3) == 3, "compute(2, 3) should be 3"
    assert compute(3, 2) == 3, "compute(3, 2) should be 3"
    assert compute(0, 0) == 0, "compute(0, 0) should be 0"
    assert compute(-5, -2) == -2, "compute(-5, -2) should be -2"
    assert compute(-2, -5) == -2, "compute(-2, -5) should be -2"
    assert compute(1.5, 1.25) == 1.5, "compute(1.5, 1.25) should be 1.5"
    assert compute(0, -1) == 0, "compute(0, -1) should be 0"
    assert compute(-1, 0) == 0, "compute(-1, 0) should be 0"
    print("public check passed")


if __name__ == "__main__":
    main()
