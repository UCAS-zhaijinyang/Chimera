"""Feature module: compute(a, b) returns the minimum of two finite numeric inputs."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    return min(a, b)
