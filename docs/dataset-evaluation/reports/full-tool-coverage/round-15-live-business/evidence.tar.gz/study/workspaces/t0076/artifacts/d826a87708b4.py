"""Main module exposing the ``compute`` arithmetic-mean feature."""

try:  # Package-style import (e.g. ``from src.main import compute``).
    from .helper import mean_values
except ImportError:  # Script-style import (e.g. running from ``src``).
    from helper import mean_values

__all__ = ["compute"]


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    2.5
    >>> compute(0, 0)
    0.0
    >>> compute(-2, 2)
    0.0
    >>> compute(1.5, 2.5)
    2.0
    """
    return mean_values(a, b)


if __name__ == "__main__":  # pragma: no cover - manual smoke check.
    print(compute(2, 3))
