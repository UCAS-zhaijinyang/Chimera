"""Core module providing the compute function."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports zero, negative, and fractional values. Ties return ``a``.
    """
    return a if a <= b else b
