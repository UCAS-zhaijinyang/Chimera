"""Core module providing the compute function."""

import math


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Raises:
        TypeError: if either argument is not a real number (bool excluded).
        ValueError: if either argument is not finite (inf or nan).
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("compute() expects numeric arguments")
        if not math.isfinite(value):
            raise ValueError("compute() expects finite numeric arguments")
    return a + b
