"""Helper utilities for numeric computations."""

import math


def _validate_finite_number(value, name):
    """Validate that ``value`` is a finite real number.

    Booleans are rejected even though ``bool`` is a subclass of ``int``.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def mean_values(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> mean_values(2, 3)
    2.5
    >>> mean_values(-2, 2)
    0.0
    """
    _validate_finite_number(a, "a")
    _validate_finite_number(b, "b")
    return (a + b) / 2
