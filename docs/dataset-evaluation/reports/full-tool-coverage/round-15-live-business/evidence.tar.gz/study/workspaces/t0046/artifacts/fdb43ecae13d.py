"""Main module exposing compute(a, b)."""

try:
    from helper import mean_values
except ImportError:  # pragma: no cover - package-style import fallback
    from .helper import mean_values


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Examples:
        compute(2, 3) == 2.5
    """
    return mean_values(a, b)


if __name__ == "__main__":  # pragma: no cover
    print(compute(2, 3))
