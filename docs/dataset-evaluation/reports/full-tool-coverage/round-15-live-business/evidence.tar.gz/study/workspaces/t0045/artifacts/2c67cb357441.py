"""Core module providing the compute function."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        2
        >>> compute(-1, 5)
        -1
        >>> compute(1.5, 1.25)
        1.25
    """
    return a if a <= b else b
