"""Unit tests for the ``compute`` arithmetic-mean feature."""

import os
import sys
import unittest

# Make ``src`` importable regardless of the working directory.
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_SRC = os.path.join(_ROOT, "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

from main import compute  # noqa: E402
from helper import mean_values  # noqa: E402


class TestCompute(unittest.TestCase):
    def test_compute_mean(self):
        self.assertEqual(compute(2, 3), 2.5)

    def test_zero_values(self):
        self.assertEqual(compute(0, 0), 0.0)

    def test_negative_values(self):
        self.assertEqual(compute(-2, 2), 0.0)
        self.assertEqual(compute(-3, -5), -4.0)

    def test_fractional_values(self):
        self.assertEqual(compute(1.5, 2.5), 2.0)
        self.assertAlmostEqual(compute(0.1, 0.2), 0.15)

    def test_helper_mean_values(self):
        self.assertEqual(mean_values(2, 3), 2.5)

    def test_non_numeric_raises(self):
        with self.assertRaises(TypeError):
            compute("2", 3)

    def test_non_finite_raises(self):
        with self.assertRaises(ValueError):
            compute(float("inf"), 3)


if __name__ == "__main__":
    unittest.main()
