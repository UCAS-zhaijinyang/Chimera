"""Core numeric utilities."""

import math


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Raises:
        TypeError: if either argument is not a real number.
        ValueError: if either argument is not finite (inf/nan).
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"expected a real number, got {type(value).__name__}")
        if not math.isfinite(value):
            raise ValueError(f"expected a finite number, got {value!r}")
    return a * b
