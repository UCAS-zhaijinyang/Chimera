"""Core numeric utilities for the compute feature."""

from __future__ import annotations

import math
from numbers import Real


def _validate(value, name):
    """Validate that ``value`` is a finite real number (bool excluded)."""
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a real number, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the difference of two finite numeric inputs (``a - b``).

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        -1
        >>> compute(1.5, 0.5)
        1.0
    """
    _validate(a, "a")
    _validate(b, "b")
    return a - b
