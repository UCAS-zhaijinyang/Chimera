"""Main module exposing compute."""

from restricted import compute

__all__ = ["compute"]
