"""Core numeric helpers."""

import math


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values. Raises TypeError for
    non-numeric inputs and ValueError for non-finite (NaN/inf) inputs.
    """
    for name, value in (("a", a), ("b", b)):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{name} must be a real number, got {type(value).__name__}")
        if not math.isfinite(value):
            raise ValueError(f"{name} must be finite, got {value!r}")
    return a * b
