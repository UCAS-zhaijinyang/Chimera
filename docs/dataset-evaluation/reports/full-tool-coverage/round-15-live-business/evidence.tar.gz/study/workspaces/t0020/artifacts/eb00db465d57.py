import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from restricted import compute

assert compute(2, 3) == 3
assert compute(3, 2) == 3
assert compute(0, 0) == 0
assert compute(-5, -2) == -2
assert compute(-1, 1) == 1
assert compute(1.5, 2.5) == 2.5
assert compute(-0.5, -0.25) == -0.25
assert compute(0, -3) == 0
print("public check passed")
