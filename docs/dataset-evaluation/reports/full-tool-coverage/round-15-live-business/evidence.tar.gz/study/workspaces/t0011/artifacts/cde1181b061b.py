"""Core numeric utilities for the compute feature."""

import math

__all__ = ["compute"]


def _is_finite_number(value):
    """Return True if value is a finite real number (int/float, not bool)."""
    if isinstance(value, bool):
        return False
    if not isinstance(value, (int, float)):
        return False
    return math.isfinite(value)


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    5
    >>> compute(-1.5, 0.5)
    -1.0
    """
    if not _is_finite_number(a):
        raise TypeError("a must be a finite numeric value")
    if not _is_finite_number(b):
        raise TypeError("b must be a finite numeric value")
    return a + b
