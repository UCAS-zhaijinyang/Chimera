"""Restricted numeric helpers.

This module provides :func:`compute`, which returns the maximum of two
finite numeric inputs.
"""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports integers, floats, zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        3
        >>> compute(-5, -2)
        -2
        >>> compute(1.5, 1.25)
        1.5
    """
    return max(a, b)
