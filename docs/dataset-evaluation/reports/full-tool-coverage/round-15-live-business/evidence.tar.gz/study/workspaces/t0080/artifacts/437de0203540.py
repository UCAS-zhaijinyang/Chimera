"""Compatibility shim exposing :func:`compute` from :mod:`src.restricted`."""

from src.restricted import compute

__all__ = ["compute"]
