# Design: compute(a, b) maximum of two finite numeric inputs

## Goal
Implement `compute(a, b)` in `src/main.py` returning the maximum of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b):`
- Returns: the larger of `a` and `b`.
- Example: `compute(2, 3) == 3`.

## Requirements
- Support zero, negative, and fractional values (ints and floats).
- Inputs are finite numeric values; no NaN/inf handling required.

## Implementation
Use Python's built-in `max(a, b)` which returns the larger argument and preserves
the original value/type. This handles zero, negatives, and fractions correctly.

```python
def compute(a, b):
    return max(a, b)
```

## Verification
- Public behavioral check: `python checks/public_check.py`
- Build: `python -m compileall -q src`

## Files
- `src/main.py`: contains `compute`.
