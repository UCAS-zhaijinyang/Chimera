# Design: compute(a, b) -> maximum of two finite numeric inputs

## Goal
Provide `compute(a, b)` in `src/main.py` returning the larger of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b):`
- Returns: the maximum of `a` and `b`.
- Behavior: `compute(2, 3) == 3`; supports zero, negative, and fractional values.

## Approach
Use Python's built-in `max(a, b)`. This handles ints, floats, zero, negatives, and fractions uniformly, and returns the first argument when values are equal (acceptable for a maximum).

## Edge cases
- `compute(0, 0) == 0`
- `compute(-5, -2) == -2`
- `compute(1.5, 1.25) == 1.5`
- `compute(-0.5, 0) == 0`

## Verification
- Public behavioral check: `python checks/public_check.py`
- Build: `python -m compileall -q src`

## Files
- `src/main.py`: implementation of `compute`.
