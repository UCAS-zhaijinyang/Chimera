import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from main import compute


def main():
    assert compute(2, 3) == 3
    assert compute(0, 0) == 0
    assert compute(-5, -2) == -2
    assert compute(1.5, 1.25) == 1.5
    assert compute(-1.5, 2.5) == 2.5
    print("public_check passed")


if __name__ == "__main__":
    main()
