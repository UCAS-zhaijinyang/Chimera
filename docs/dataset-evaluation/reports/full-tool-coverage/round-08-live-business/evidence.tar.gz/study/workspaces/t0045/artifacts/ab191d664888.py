"""Feature module: compute the minimum of two finite numeric inputs."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports zero, negative, and fractional values.

    Examples:
        compute(2, 3) -> 2
        compute(0, -3) -> -3
        compute(0.5, 0.25) -> 0.25
    """
    return min(a, b)
