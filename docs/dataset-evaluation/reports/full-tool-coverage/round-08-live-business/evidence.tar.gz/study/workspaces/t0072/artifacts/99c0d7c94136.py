"""Core numeric utilities."""


def compute(a, b):
    """Return the difference of two finite numeric inputs (a - b).

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        -1
        >>> compute(0, 0)
        0
        >>> compute(-5, -3)
        -2
        >>> compute(1.5, 0.5)
        1.0
    """
    return a - b
