"""Core numeric utilities for the compute feature."""

from __future__ import annotations

import math
import numbers


def _validate(value, name):
    """Ensure ``value`` is a finite real number."""
    if isinstance(value, bool) or not isinstance(value, numbers.Real):
        raise TypeError(f"{name} must be a real number, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    5
    >>> compute(0, 0)
    0
    >>> compute(-2, 3)
    1
    >>> compute(0.5, 0.25)
    0.75
    """
    _validate(a, "a")
    _validate(b, "b")
    return a + b
