"""Tests for compute(a, b) arithmetic mean."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from main import compute  # noqa: E402


class TestCompute(unittest.TestCase):
    def test_mean_of_two_and_three(self):
        self.assertEqual(compute(2, 3), 2.5)

    def test_zero(self):
        self.assertEqual(compute(0, 0), 0.0)

    def test_negative(self):
        self.assertEqual(compute(-2, 2), 0.0)
        self.assertEqual(compute(-4, -6), -5.0)

    def test_fractional(self):
        self.assertEqual(compute(1.5, 2.5), 2.0)

    def test_non_numeric_raises(self):
        with self.assertRaises(TypeError):
            compute("a", 1)

    def test_non_finite_raises(self):
        with self.assertRaises(ValueError):
            compute(float("inf"), 1)


if __name__ == "__main__":
    unittest.main()
