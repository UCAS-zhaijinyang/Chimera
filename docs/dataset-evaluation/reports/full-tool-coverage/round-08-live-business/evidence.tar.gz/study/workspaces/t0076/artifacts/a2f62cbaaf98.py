"""Main module exposing compute(a, b)."""

try:  # pragma: no cover - import style depends on how the module is loaded
    from src.helper import mean_values
except ImportError:  # pragma: no cover
    from helper import mean_values


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Examples:
        compute(2, 3) == 2.5
        compute(0, 0) == 0.0
        compute(-2, 2) == 0.0
        compute(1.5, 2.5) == 2.0
    """
    return mean_values(a, b)


if __name__ == "__main__":  # pragma: no cover
    print(compute(2, 3))
