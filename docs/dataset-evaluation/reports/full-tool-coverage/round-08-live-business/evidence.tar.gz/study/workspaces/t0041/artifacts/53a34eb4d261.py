"""Core numeric utilities for the compute feature."""

import math

__all__ = ["compute"]


def _is_finite_number(value):
    """Return True if value is a finite int or float (bool excluded)."""
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    if isinstance(value, float):
        return math.isfinite(value)
    return False


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    5
    >>> compute(0, 0)
    0
    >>> compute(-1, 1)
    0
    >>> compute(0.5, 0.25)
    0.75
    """
    if not _is_finite_number(a) or not _is_finite_number(b):
        raise TypeError("compute() requires two finite numeric inputs")
    return a + b
