"""Tests for compute(a, b)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from main import compute  # noqa: E402


class TestCompute(unittest.TestCase):
    def test_compute_mean(self):
        self.assertEqual(compute(2, 3), 2.5)

    def test_zero(self):
        self.assertEqual(compute(0, 0), 0)

    def test_negative(self):
        self.assertEqual(compute(-2, -4), -3)

    def test_fractional(self):
        self.assertEqual(compute(0.5, 1.5), 1.0)


if __name__ == "__main__":
    unittest.main()
