"""Feature module: compute the maximum of two finite numeric inputs."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values. Ties return ``a``.
    """
    return a if a >= b else b
