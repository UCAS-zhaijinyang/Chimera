"""Unit tests for compute(a, b)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.main import compute  # noqa: E402


class TestCompute(unittest.TestCase):
    def test_mean_of_two_and_three(self):
        self.assertEqual(compute(2, 3), 2.5)

    def test_zero_values(self):
        self.assertEqual(compute(0, 0), 0.0)

    def test_negative_values(self):
        self.assertEqual(compute(-2, 2), 0.0)
        self.assertEqual(compute(-4, -6), -5.0)

    def test_fractional_values(self):
        self.assertEqual(compute(1.5, 2.5), 2.0)
        self.assertEqual(compute(0.5, 0.25), 0.375)

    def test_mixed_int_and_float(self):
        self.assertEqual(compute(1, 2.0), 1.5)

    def test_non_numeric_raises_type_error(self):
        with self.assertRaises(TypeError):
            compute("2", 3)
        with self.assertRaises(TypeError):
            compute(True, 3)

    def test_non_finite_raises_value_error(self):
        with self.assertRaises(ValueError):
            compute(float("nan"), 3)
        with self.assertRaises(ValueError):
            compute(float("inf"), 3)


if __name__ == "__main__":
    unittest.main()
