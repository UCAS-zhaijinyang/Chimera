"""Helper utilities for numeric computations."""

import math


def _validate_finite_number(value, name):
    """Ensure value is a finite real number (int/float, not bool)."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a real number, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def mean_values(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    _validate_finite_number(a, "a")
    _validate_finite_number(b, "b")
    return (a + b) / 2
