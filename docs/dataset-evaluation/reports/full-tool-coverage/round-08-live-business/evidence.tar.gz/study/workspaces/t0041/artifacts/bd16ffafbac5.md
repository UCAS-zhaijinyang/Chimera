# Design: compute(a, b) sum of two finite numeric inputs

## Goal
Provide `compute(a, b)` in `src/main.py` returning the sum of two finite numeric inputs.

## Interface
- Module: `src/main.py`
- Function: `compute(a, b) -> number`
- Returns `a + b` for finite numeric inputs (int/float, including zero, negative, fractional).

## Behavior
- `compute(2, 3) == 5`
- `compute(0, 0) == 0`
- `compute(-1, 1) == 0`
- `compute(0.5, 0.25) == 0.75`
- `compute(-2.5, 1.0) == -1.5`

## Validation
- Reject non-numeric inputs (TypeError) and non-finite values (ValueError) to honor "finite numeric inputs".
- Use `math.isfinite` for float checks; bool is a subclass of int but treated as numeric — accept ints/floats only.

## Verification
1. Behavioral: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
2. Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Files
- `src/main.py` (implementation)
