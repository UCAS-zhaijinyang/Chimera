{
  "path": "shared/out.md",
  "source": "29c828b55e52"
}