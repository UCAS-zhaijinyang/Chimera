{
  "path": "shared/out.md",
  "source": "56c5e1611bd7"
}