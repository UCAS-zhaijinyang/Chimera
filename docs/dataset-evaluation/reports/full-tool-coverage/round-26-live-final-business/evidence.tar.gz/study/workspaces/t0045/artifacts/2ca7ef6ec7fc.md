# Design: compute(a, b) minimum of two finite numeric inputs

## Goal
Provide `compute(a, b)` in `src/main.py` returning the smaller of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b):`
- Returns: the minimum of `a` and `b` (numeric).
- Behavior: `compute(2, 3) == 2`; supports zero, negative, and fractional values.

## Implementation
Use Python's built-in `min(a, b)` which handles ints, floats, zero, negatives, and fractions correctly.

```python
def compute(a, b):
    """Return the minimum of two finite numeric inputs."""
    return min(a, b)
```

## Verification
- Public behavioral check: `python checks/public_check.py`
- Build: `python -m compileall -q src`

## Edge cases
- `compute(0, 0) == 0`
- `compute(-5, -2) == -5`
- `compute(1.5, 1.25) == 1.25`
- `compute(-1, 0) == -1`
