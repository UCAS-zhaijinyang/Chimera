"""Entry point exposing compute from the sibling restricted module."""

from restricted import compute

__all__ = ["compute"]
