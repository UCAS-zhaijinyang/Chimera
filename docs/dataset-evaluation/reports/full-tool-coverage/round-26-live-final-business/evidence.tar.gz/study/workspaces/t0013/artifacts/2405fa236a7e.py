"""Core module for the compute feature."""

import math


def _validate(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a numeric value, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    _validate(a, "a")
    _validate(b, "b")
    return a * b
