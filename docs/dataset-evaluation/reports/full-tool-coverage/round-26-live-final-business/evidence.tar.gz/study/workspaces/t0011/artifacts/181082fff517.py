"""Core numeric utilities for the compute feature."""

import math


def _is_finite_number(value):
    """Return True if value is a finite int or float (bool excluded)."""
    if isinstance(value, bool):
        return False
    if not isinstance(value, (int, float)):
        return False
    return math.isfinite(value)


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Raises:
        TypeError: if either argument is not an int or float.
        ValueError: if either argument is non-finite (NaN or infinity).
    """
    if not _is_finite_number(a):
        raise TypeError("a must be a finite int or float")
    if not _is_finite_number(b):
        raise TypeError("b must be a finite int or float")
    return a + b
