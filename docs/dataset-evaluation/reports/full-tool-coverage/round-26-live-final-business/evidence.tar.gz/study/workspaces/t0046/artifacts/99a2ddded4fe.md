# Design: compute(a, b) arithmetic mean

## Goal
Provide `compute(a, b)` in `src/main.py` returning the arithmetic mean of two finite numeric inputs.

## Files
1. `src/helper.py` — define `mean_values(a, b)` returning `(a + b) / 2`.
2. `src/main.py` — import `mean_values` from helper and define `compute(a, b)` delegating to it.
3. `tests/test_compute.py` — unittest TestCase asserting `compute(2, 3) == 2.5`, plus zero/negative/fractional cases.

## Behavior
- compute(2, 3) == 2.5
- compute(0, 0) == 0.0
- compute(-2, 2) == 0.0
- compute(1.5, 2.5) == 2.0

## Verification
- Public behavioral check: `python checks/public_check.py`
- Build: `python -m compileall -q src`
