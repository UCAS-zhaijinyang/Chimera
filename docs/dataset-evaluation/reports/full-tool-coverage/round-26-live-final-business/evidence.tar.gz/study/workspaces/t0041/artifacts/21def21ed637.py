"""Core numeric utilities."""

import math
import numbers


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, numbers.Real):
            raise TypeError("compute() expects numeric inputs")
        if not math.isfinite(value):
            raise ValueError("compute() expects finite inputs")
    return a + b
