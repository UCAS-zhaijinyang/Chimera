"""Core numeric feature module.

Provides :func:`compute`, which returns the difference of two finite
numeric inputs.
"""

import math

__all__ = ["compute"]


def _validate(value, name):
    """Validate that *value* is a finite numeric input.

    Booleans are rejected because they are not intended numeric inputs
    for this feature even though ``bool`` is a subclass of ``int``.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(
            f"{name} must be an int or float, got {type(value).__name__}"
        )
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the difference ``a - b`` of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    -1
    >>> compute(0, 0)
    0
    >>> compute(-5, -2)
    -3
    >>> compute(1.5, 0.5)
    1.0
    """
    _validate(a, "a")
    _validate(b, "b")
    return a - b
