"""Core module for the compute feature."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative, and fractional values. Ties return the
    first operand, which is numerically equal to the second.
    """
    return a if a >= b else b
