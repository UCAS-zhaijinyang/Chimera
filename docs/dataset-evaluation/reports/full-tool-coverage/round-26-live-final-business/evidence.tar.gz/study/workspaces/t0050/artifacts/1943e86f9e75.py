"""Module providing compute(a, b), returning the maximum of two finite numeric inputs."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        3
        >>> compute(-1, -5)
        -1
        >>> compute(0, 0)
        0
        >>> compute(1.5, 1.25)
        1.5
    """
    return max(a, b)
