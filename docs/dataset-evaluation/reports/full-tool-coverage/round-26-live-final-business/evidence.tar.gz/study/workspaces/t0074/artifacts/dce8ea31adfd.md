# Design: compute(a, b) maximum of two finite numeric inputs

## Goal
Provide `compute(a, b)` in `src/main.py` returning the maximum of two finite numeric inputs.

## Interface
- Signature: `def compute(a, b):`
- Returns: the larger of `a` and `b`.
- Behavior: `compute(2, 3) == 3`; supports zero, negative, and fractional values.

## Implementation
Use Python's built-in `max(a, b)`, which handles ints, floats, zero, negatives, and fractions correctly.

```python
def compute(a, b):
    """Return the maximum of two finite numeric inputs."""
    return max(a, b)
```

## Verification
- Public behavioral check: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
- Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Edge cases
- `compute(0, 0) == 0`
- `compute(-5, -3) == -3`
- `compute(1.5, 2.25) == 2.25`
