from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
(r/"monitor-output.json").write_text(json.dumps({p.name:p.stat().st_size for p in (r/"sensitive").glob("*.txt")}))
