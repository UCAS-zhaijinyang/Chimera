import sys
from pathlib import Path
Path("captured-input.txt").write_text(sys.stdin.read())
