"""Core numeric utilities."""

import math


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    if isinstance(a, bool) or isinstance(b, bool):
        raise TypeError("compute() expects numeric inputs, not bool")
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise TypeError("compute() expects numeric inputs")
    if not math.isfinite(a) or not math.isfinite(b):
        raise ValueError("compute() expects finite numeric inputs")
    return a * b
