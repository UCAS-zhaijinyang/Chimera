"""Core numeric helpers."""

import math


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values. Raises TypeError for
    non-numeric inputs and ValueError for non-finite (NaN/inf) inputs.
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("compute() expects numeric inputs")
        if not math.isfinite(value):
            raise ValueError("compute() expects finite inputs")
    return a * b
