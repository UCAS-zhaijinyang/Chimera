"""Core module for the compute feature."""

import math


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.

    Raises:
        TypeError: if either argument is not a real number.
        ValueError: if either argument is not finite (NaN or infinity).
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("compute() expects numeric inputs")
        if not math.isfinite(value):
            raise ValueError("compute() expects finite inputs")
    return a + b
