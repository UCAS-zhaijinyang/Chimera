"""Unit tests for compute(a, b)."""

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from main import compute  # noqa: E402


class TestCompute(unittest.TestCase):
    def test_mean_of_two_and_three(self):
        self.assertEqual(compute(2, 3), 2.5)

    def test_zero_values(self):
        self.assertEqual(compute(0, 0), 0.0)

    def test_negative_values(self):
        self.assertEqual(compute(-4, 2), -1.0)

    def test_fractional_values(self):
        self.assertEqual(compute(0.5, 1.5), 1.0)

    def test_negative_fractional(self):
        self.assertEqual(compute(-1.5, -0.5), -1.0)


if __name__ == "__main__":
    unittest.main()
