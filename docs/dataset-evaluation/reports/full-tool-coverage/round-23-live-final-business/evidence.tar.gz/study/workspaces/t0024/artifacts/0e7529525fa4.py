def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    return a if a >= b else b
