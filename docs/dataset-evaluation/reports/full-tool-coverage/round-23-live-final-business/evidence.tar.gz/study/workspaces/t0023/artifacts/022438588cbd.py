"""Core numeric helpers."""

import math


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values. Raises ValueError for
    non-numeric or non-finite inputs.
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("compute() requires finite numeric inputs")
        if not math.isfinite(value):
            raise ValueError("compute() requires finite numeric inputs")
    return a * b
