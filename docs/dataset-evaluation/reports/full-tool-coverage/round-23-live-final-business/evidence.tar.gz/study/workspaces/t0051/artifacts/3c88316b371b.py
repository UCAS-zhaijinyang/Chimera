"""Core numeric helpers."""

import math


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values. Raises ValueError for
    non-numeric or non-finite inputs.
    """
    if isinstance(a, bool) or isinstance(b, bool):
        raise ValueError("compute() expects finite numeric inputs, not bool")
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        raise ValueError("compute() expects finite numeric inputs")
    if not math.isfinite(a) or not math.isfinite(b):
        raise ValueError("compute() expects finite numeric inputs")
    return a + b
