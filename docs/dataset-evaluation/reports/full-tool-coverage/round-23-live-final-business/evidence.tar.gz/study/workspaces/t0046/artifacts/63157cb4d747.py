"""Main module exposing compute(a, b)."""

try:  # package-style import
    from src.helper import mean_values
except ImportError:  # src on sys.path
    from helper import mean_values


def compute(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Example:
        >>> compute(2, 3)
        2.5
    """
    return mean_values(a, b)


if __name__ == "__main__":
    print(compute(2, 3))
