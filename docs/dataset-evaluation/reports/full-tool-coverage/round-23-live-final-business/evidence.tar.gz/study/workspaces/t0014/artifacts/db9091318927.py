"""Core module for the compute feature."""


def compute(a, b):
    """Return the maximum of two finite numeric inputs.

    Supports zero, negative and fractional values. The larger of the two
    inputs is returned, preserving its original value/type.
    """
    return max(a, b)
