"""Core module providing the compute function."""


def compute(a, b):
    """Return the minimum of two finite numeric inputs.

    Supports integers, floats, zero, negative and fractional values.
    """
    return min(a, b)
