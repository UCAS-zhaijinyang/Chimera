"""Main module for the compute feature."""

import math


def _validate(value, name):
    """Validate that value is a finite numeric input."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a finite numeric value")
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError(f"{name} must be finite")
    return value


def compute(a, b):
    """Return the difference of two finite numeric inputs (a - b).

    Supports zero, negative and fractional values.

    Example:
        >>> compute(2, 3)
        -1
    """
    _validate(a, "a")
    _validate(b, "b")
    return a - b
