"""Helper utilities for numeric computations."""


def mean_values(a, b):
    """Return the arithmetic mean of two finite numeric inputs.

    Supports zero, negative and fractional values. True division is used
    so that integer inputs produce a float result.
    """
    return (a + b) / 2
