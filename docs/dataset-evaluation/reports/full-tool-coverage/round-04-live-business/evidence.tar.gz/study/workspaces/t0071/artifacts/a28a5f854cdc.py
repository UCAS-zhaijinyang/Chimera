"""Core numeric utilities for the compute feature."""

from __future__ import annotations

import math
from numbers import Real


def _validate(value, name):
    """Return value if it is a finite real number, else raise."""
    if isinstance(value, bool) or not isinstance(value, Real):
        raise TypeError(f"{name} must be a finite numeric value, got {type(value).__name__}")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite, got {value!r}")
    return value


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values, e.g. ``compute(2, 3) == 5``.
    """
    _validate(a, "a")
    _validate(b, "b")
    return a + b
