"""Restricted numeric helpers.

This module provides :func:`compute`, which returns the maximum of two
finite numeric inputs.
"""


def compute(a, b):
    """Return the maximum of the two finite numeric inputs ``a`` and ``b``.

    Supports zero, negative and fractional values.

    Examples:
        >>> compute(2, 3)
        3
        >>> compute(-4, -2)
        -2
        >>> compute(1.5, 1.25)
        1.5
    """
    return a if a >= b else b
