"""Core numeric feature module.

Provides :func:`compute`, which returns the product of two finite numeric
inputs.
"""

from __future__ import annotations

import math
from numbers import Real


def _is_finite_number(value: object) -> bool:
    """Return True if *value* is a finite real number (int/float/Decimal-like)."""
    if isinstance(value, bool):
        # bool is a subclass of int; treat it as a numeric value.
        return True
    if isinstance(value, Real):
        try:
            return math.isfinite(value)
        except (TypeError, ValueError):
            return False
    # Support Decimal / Fraction and other numeric types exposing is_finite.
    is_finite = getattr(value, "is_finite", None)
    if callable(is_finite):
        try:
            return bool(is_finite())
        except (TypeError, ValueError):
            return False
    return False


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative and fractional values.

    >>> compute(2, 3)
    6
    >>> compute(0, 5)
    0
    >>> compute(-2, 3)
    -6
    >>> compute(0.5, 4)
    2.0
    """
    if not _is_finite_number(a):
        raise TypeError(f"compute() requires a finite numeric input, got {a!r}")
    if not _is_finite_number(b):
        raise TypeError(f"compute() requires a finite numeric input, got {b!r}")
    return a * b
