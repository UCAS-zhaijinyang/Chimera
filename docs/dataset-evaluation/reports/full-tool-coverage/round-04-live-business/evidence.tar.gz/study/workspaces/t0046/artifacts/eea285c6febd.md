# Design: compute(a, b) arithmetic mean

## Goal
Provide `compute(a, b)` returning the arithmetic mean of two finite numeric inputs.

## Files
1. `src/helper.py`
   - `mean_values(a, b)`: validate both inputs are finite real numbers (int/float, not bool, not NaN/inf); return `(a + b) / 2`.
   - Raise `TypeError` for non-numeric inputs, `ValueError` for non-finite values.
2. `src/main.py`
   - `from helper import mean_values` (with fallback to relative import for package usage).
   - `compute(a, b)`: delegate to `mean_values(a, b)`.
3. `tests/test_compute.py`
   - `unittest.TestCase` with `test_compute_mean` asserting `compute(2, 3) == 2.5`.
   - Additional cases: zero, negatives, fractions.

## Behavior
- `compute(2, 3) == 2.5`
- `compute(0, 0) == 0.0`
- `compute(-2, 2) == 0.0`
- `compute(0.5, 1.5) == 1.0`

## Verification
- `python checks/public_check.py`
- `python -m compileall -q src`
