"""Core numeric utilities for the compute feature."""

import math


def _validate(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{name} must be a finite numeric value")
    if not math.isfinite(value):
        raise ValueError(f"{name} must be finite")


def compute(a, b):
    """Return the sum of two finite numeric inputs.

    Supports zero, negative and fractional values.
    """
    _validate(a, "a")
    _validate(b, "b")
    return a + b
