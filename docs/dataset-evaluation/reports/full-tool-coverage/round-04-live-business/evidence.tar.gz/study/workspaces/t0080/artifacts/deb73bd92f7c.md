# Design: compute(a, b) maximum of two finite numeric inputs

## Goal
Provide `compute(a, b)` in `src/restricted.py` that returns the maximum of two finite numeric inputs.

## Interface
- Module: `src/restricted.py`
- Function: `compute(a, b)`
- Returns: the larger of `a` and `b` (numeric).
- Example: `compute(2, 3) == 3`.

## Behavior requirements
1. Return the maximum of the two inputs.
2. Support zero: `compute(0, 0) == 0`, `compute(0, 5) == 5`.
3. Support negatives: `compute(-3, -7) == -3`.
4. Support fractional values: `compute(1.5, 2.25) == 2.25`.
5. Inputs are finite numeric values (int/float). No NaN/inf handling required.

## Implementation approach
Use Python's built-in `max(a, b)` which satisfies all cases including zero, negative and fractional values. Keep the module minimal and dependency-free.

```python
def compute(a, b):
    return max(a, b)
```

## Verification
- Public behavioral check: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python checks/public_check.py`
- Build: `/Users/ayang/Desktop/project_work/Chimera/.venv/bin/python -m compileall -q src`

## Risks
- None significant; `max` handles all required numeric cases.
