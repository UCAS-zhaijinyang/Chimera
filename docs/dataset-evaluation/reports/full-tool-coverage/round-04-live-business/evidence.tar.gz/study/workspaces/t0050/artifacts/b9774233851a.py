"""Compatibility shim exposing :func:`compute` from ``src.restricted``.

The public behavioral check imports ``compute`` from the top-level ``main``
module, so re-export the implementation here.
"""

from src.restricted import compute

__all__ = ["compute"]
