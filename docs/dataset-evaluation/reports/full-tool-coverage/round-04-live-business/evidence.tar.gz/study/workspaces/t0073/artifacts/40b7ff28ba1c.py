"""Core numeric utilities."""

import math


def compute(a, b):
    """Return the product of two finite numeric inputs.

    Supports zero, negative, and fractional values.

    Raises:
        TypeError: if either input is not a real number.
        ValueError: if either input is not finite (NaN or infinity).
    """
    for value in (a, b):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("compute() expects numeric inputs")
        if not math.isfinite(value):
            raise ValueError("compute() expects finite inputs")
    return a * b
